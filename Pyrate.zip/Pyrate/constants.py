"""
This file contains game constants for Pyrate
"""

# imports
import pygame
pygame.init()

# map (minimum values should be 5)
MAP_WIDTH  = 20
MAP_HEIGHT = 15


# sizes
TILE_WIDTH  = 32
TILE_HEIGHT = 32


# display
DISPLAY_WIDTH = TILE_WIDTH * MAP_WIDTH
DISPLAY_HEIGHT = TILE_HEIGHT * MAP_HEIGHT


# colors definitions (RGB)
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY  = (100, 100, 100)
COLOR_RED   = (255, 0, 0)
COLOR_GREEN = (0, 255, 0)
COLOR_BLUE  = (0, 0, 255)


# game colors
COLOR_BACKGROUND_DEFAULT = COLOR_GRAY


# fonts
FONT_DEBUG   = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 16)
FONT_MESSAGE = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 12)
FONT_CURSOR  = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", TILE_HEIGHT)


# FPS limit
GAME_FPS = 60

# LOS settings
LOS_LIGHT_RADIUS = 10
LOS_LIGHT_WALLS = True
LOS_ALGO = 0


# messages
NUM_MESSAGES = 4

