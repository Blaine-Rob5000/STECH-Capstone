"""
This file contains all the game constants for Pyrate
"""

# imports
import pygame
import libtcodpy as doryen

pygame.init()


# sizes
MAIN_WIDTH  = 800
MAIN_HEIGHT = 600
TILE_WIDTH  = 32
TILE_HEIGHT = 32


# colors definitions (RGB)
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY  = (100, 100, 100)


# game colors
COLOR_BACKGROUND_DEFAULT = COLOR_GRAY


# sprites
SPRITE_PLAYER     = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/playerSprite.png")
SPRITE_ENEMY      = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/enemy1Sprite.png")
SPRITE_FLOOR      = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/floorTile.jpg")
SPRITE_FLOOR_DARK = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/floorUnseenTile.png")
SPRITE_WALL       = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/wall2Tile.jpg")
SPRITE_WALL_DARK  = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/wall2Unseen1Tile.png")


# map
MAP_WIDTH  = 30
MAP_HEIGHT = 20


#LOS Settings
LOS_LIGHT_RADIUS = 10
LOS_LIGHT_WALLS = True
LOS_ALGO = doryen.FOV_BASIC


DISPLAY_WIDTH = TILE_WIDTH * MAP_WIDTH
DISPLAY_HEIGHT = TILE_HEIGHT * MAP_HEIGHT