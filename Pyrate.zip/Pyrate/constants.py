"""
This file contains game constants for Pyrate
"""


# map (minimum values should be 5)
MAP_WIDTH  = 20
MAP_HEIGHT = 15


# sizes
TILE_WIDTH  = 32
TILE_HEIGHT = 32


# display
DISPLAY_WIDTH = TILE_WIDTH * MAP_WIDTH
DISPLAY_HEIGHT = TILE_HEIGHT * MAP_HEIGHT


# colors definitions (RGB)
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY  = (100, 100, 100)
COLOR_RED   = (255, 0, 0)


# game colors
COLOR_BACKGROUND_DEFAULT = COLOR_GRAY


# FPS limit
GAME_FPS = 60

# LOS settings
LOS_LIGHT_RADIUS = 10
LOS_LIGHT_WALLS = True
LOS_ALGO = 0


# messages
NUM_MESSAGES = 4

