"""
This file contains game constants for Pyrate
"""

# imports
import pygame
pygame.init()

# map
MAP_WIDTH  = 50
MAP_HEIGHT = 50
MAP_MAX_ROOMS = 50


# rooms
ROOM_MIN_HEIGHT = 3
ROOM_MAX_HEIGHT = 7
ROOM_MIN_WIDTH = 3
ROOM_MAX_WIDTH = 7


# sizes
TILE_WIDTH  = 32
TILE_HEIGHT = 32

MINI_TILE_WIDTH  = TILE_WIDTH // 4
MINI_TILE_HEIGHT = TILE_HEIGHT // 4


# map surface
MAP_SURFACE_WIDTH = MAP_WIDTH * TILE_WIDTH
MAP_SURFACE_HEIGHT = MAP_HEIGHT * TILE_HEIGHT


# camera
CAMERA_RANGE = 12
CAMERA_WIDTH = (CAMERA_RANGE * 2 + 1) * TILE_WIDTH
CAMERA_HEIGHT = (CAMERA_RANGE * 2 + 1) * TILE_HEIGHT

CAMERA_LAG = 1		# must be 1 or higher; 1 = no lag, 10 = moderate lag, 100 = extreme lag


# display
MESSAGE_WIDTH = CAMERA_WIDTH // 2
DISPLAY_WIDTH = CAMERA_WIDTH + MESSAGE_WIDTH
DISPLAY_HEIGHT = CAMERA_HEIGHT


# colors definitions (RGB)
COLOR_BLACK  = (0, 0, 0)
COLOR_WHITE  = (255, 255, 255)
COLOR_GRAY   = (100, 100, 100)
COLOR_RED    = (255, 0, 0)
COLOR_GREEN  = (0, 255, 0)
COLOR_BLUE   = (0, 0, 255)
COLOR_PURPLE = (100, 0, 100)
COLOR_YELLOW = (255, 255, 0)
COLOR_ORANGE = (255, 128, 0)


# game color defaults
COLOR_BACKGROUND_DEFAULT = COLOR_BLACK
COLOR_MESSAGE_DEFAULT = COLOR_WHITE
COLOR_ATTACK = COLOR_WHITE
COLOR_DAMAGE = COLOR_RED
COLOR_DEATH = COLOR_RED
COLOR_SPELL = COLOR_ORANGE
COLOR_HEAL = COLOR_GREEN
COLOR_LEVEL_UP = COLOR_GREEN


# object depths
DEPTH_PLAYER   = 10
DEPTH_CREATURE = 20
DEPTH_FLY      = 30
DEPTH_GEAR	   = 40
DEPTH_ITEM     = 50
DEPTH_CORPSE   = 60
DEPTH_STAIRS   = 70


# fonts
FONT_DEFAULT = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 16)
FONT_MESSAGE = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 12)
FONT_CURSOR  = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", TILE_HEIGHT)


# Player Maximum Level
LEVEL_MAX = 15
INVENTORY_MAX = 10

# FPS limit
GAME_FPS = 60

# LOS settings
LOS_LIGHT_RADIUS = 8
LOS_LIGHT_WALLS = True
LOS_ALGO = 0


# messages
DEBUG = True
