"""
This file contains all the game constants for Pyrate
"""

# pygame
import pygame
pygame.init()


# sizes
MAIN_WIDTH  = 800
MAIN_HEIGHT = 600
TILE_WIDTH  = 32
TILE_HEIGHT = 32


# colors definitions (RGB)
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY  = (100, 100, 100)


# game colors
COLOR_BACKGROUND_DEFAULT = COLOR_GRAY


# sprites
SPRITE_PLAYER = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/playerSprite.png")
SPRITE_ENEMY  = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/enemy1Sprite.png")
SPRITE_FLOOR  = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/floorTile.jpg")
SPRITE_WALL   = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/wall1Tile.png")


# map
MAP_WIDTH  = 30
MAP_HEIGHT = 20


DISPLAY_WIDTH = TILE_WIDTH * MAP_WIDTH
DISPLAY_HEIGHT = TILE_HEIGHT * MAP_HEIGHT