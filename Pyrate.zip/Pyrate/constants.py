"""
This file contains all the game constants for Pyrate
"""

# imports
import pygame
import libtcodpy as doryen

pygame.init()


# sizes
TILE_WIDTH  = 32
TILE_HEIGHT = 32


# colors definitions (RGB)
COLOR_BLACK = (0, 0, 0)
COLOR_WHITE = (255, 255, 255)
COLOR_GRAY  = (100, 100, 100)
COLOR_RED   = (255, 0, 0)


# game colors
COLOR_BACKGROUND_DEFAULT = COLOR_GRAY


# FPS limit
GAME_FPS = 60


# sprites
# SPRITE_PLAYER     = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/Pyrate.png")
SPRITE_ENEMY      = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/Crab.png")
SPRITE_FLOOR      = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/floorTile.png")
SPRITE_FLOOR_DARK = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/floorTileDark.png")
SPRITE_WALL       = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/brickWall.png")
SPRITE_WALL_DARK  = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/brickWallDark.png")


# map
MAP_WIDTH  = 30
MAP_HEIGHT = 20


# LOS settings
LOS_LIGHT_RADIUS = 10
LOS_LIGHT_WALLS = True
LOS_ALGO = doryen.FOV_BASIC


# fonts
FONT_DEBUG = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 16)
FONT_MESSAGE = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 12)


# messages
NUM_MESSAGES = 6


# display
DISPLAY_WIDTH = TILE_WIDTH * MAP_WIDTH
DISPLAY_HEIGHT = TILE_HEIGHT * MAP_HEIGHT