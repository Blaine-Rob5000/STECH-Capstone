"""
This file contains game constants for Pyrate
"""

################################################################################
##
##  NOTES:  adjust save game to work on exit
##
################################################################################


# imports
import pygame
pygame.init()

# map
MAP_WIDTH     = 50  # 50 max
MAP_HEIGHT    = 50  # 50 max
MAP_MAX_ROOMS = 50  # 50


# rooms
ROOM_MIN_HEIGHT = 3  # 3 minimum
ROOM_MAX_HEIGHT = 7  # 7
ROOM_MIN_WIDTH  = 3  # 3 minimum
ROOM_MAX_WIDTH  = 7  # 7


# tile sizes
TILE_WIDTH  = 32
TILE_HEIGHT = 32

MINI_TILE_WIDTH  = TILE_WIDTH // 4
MINI_TILE_HEIGHT = TILE_HEIGHT // 4


# map surface
MAP_SURFACE_WIDTH = MAP_WIDTH * TILE_WIDTH
MAP_SURFACE_HEIGHT = MAP_HEIGHT * TILE_HEIGHT


# camera
CAMERA_RANGE = 12
CAMERA_WIDTH = (CAMERA_RANGE * 2 + 1) * TILE_WIDTH
CAMERA_HEIGHT = (CAMERA_RANGE * 2 + 1) * TILE_HEIGHT

CAMERA_LAG = 1		# must be 1 or higher; 1 = no lag, 10 = moderate lag, 100 = extreme lag


# display
MESSAGE_WIDTH = CAMERA_WIDTH // 2
DISPLAY_WIDTH = CAMERA_WIDTH + MESSAGE_WIDTH
DISPLAY_HEIGHT = CAMERA_HEIGHT


# colors definitions (RGB)
COLOR_BLACK  = (0, 0, 0)
COLOR_WHITE  = (255, 255, 255)
COLOR_GRAY   = (100, 100, 100)
COLOR_RED    = (255, 0, 0)
COLOR_GREEN  = (0, 255, 0)
COLOR_BLUE   = (0, 0, 255)
COLOR_PURPLE = (100, 0, 100)
COLOR_YELLOW = (255, 255, 0)
COLOR_ORANGE = (255, 128, 0)


# game color defaults
COLOR_BACKGROUND_DEFAULT = COLOR_BLACK
COLOR_MESSAGE_DEFAULT = COLOR_WHITE
COLOR_ATTACK = COLOR_WHITE
COLOR_DAMAGE = COLOR_RED
COLOR_DEATH = COLOR_RED
COLOR_SPELL = COLOR_ORANGE
COLOR_HEAL = COLOR_GREEN
COLOR_LEVEL_UP = COLOR_GREEN


# object depths
DEPTH_PLAYER   = 100
DEPTH_CREATURE = 200
DEPTH_FLY      = 300
DEPTH_GEAR	   = 400
DEPTH_ITEM     = 500
DEPTH_CORPSE   = 600
DEPTH_STAIRS   = 700

graphicPath = "graphicAssets/"
# fonts
FONT_TITLE   = pygame.font.Font(graphicPath + "Fonts/Joystick/Joystick.otf", 20)
FONT_DEATH   = pygame.font.Font(graphicPath + "Fonts/Joystick/Joystick.otf", 36)
FONT_DEFAULT = pygame.font.Font(graphicPath + "Fonts/Joystick/Joystick.otf", 16)
FONT_MESSAGE = pygame.font.Font(graphicPath + "Fonts/Joystick/Joystick.otf", 12)
FONT_CURSOR  = pygame.font.Font(graphicPath + "Fonts/Joystick/Joystick.otf", TILE_HEIGHT)


# Player
PLAYER_LEVEL_MAX = 15      # 15
PLAYER_INVENTORY_MAX = 10  # 10
PLAYER_BASE_ATTACK = 4     #  4
PLAYER_BASE_DEFENSE = 0    #  0
PLAYER_BASE_HP = 20        # 20


# percentage chance that a turtle will break the player's weapon or shield
BREAK_CHANCE = 5  # 5


# amulet of power stats
AMULET_DEFENSE = 3
AMULET_ATTACK = 3


# FPS limit
GAME_FPS = 60


# LOS settings
LOS_LIGHT_RADIUS = 8
LOS_LIGHT_WALLS = True
LOS_ALGO = 0


# display debug messages?
DEBUG = False
