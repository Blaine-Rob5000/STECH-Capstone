"""

Pyrate - (noun) an archaic spelling of 'pirate'

	Also:  a python roguelike by RG Blaine using pygame and the doryen library (libtcod)


''''''''''''''''''' @@@@@@@@@@@@@@@@@@@''''''''''''''''''''
'''''''''''''''''@@@@@@'''''''''''''@@@@@@@''''''''''''''''
''''''''''''''@@@@'''''''''''''''''''''''@@@@''''''''''''''
'''''''''''''@@@'''''''''''''''''''''''''''''@@''''''''''''
''''''''''''@@''''''''''''''''''''''''''''''''@@'''''''''''
'''''''''''@@'''''''''''''''''''''`'''''''''''@@'''''''''''
''''''''''@@'''''''''''''''''''''''''''''''''''@@''''''''''
''''''''''@@'@@'''''''''''''''''''''''''''''@@'@@''''''''''
''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''
''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''
''''''''''@@''@@''''''''''''''''''''''''''''@@'@@''''''''''
''''''''''@@''@@'''''''''''''''''''''''''''@@''@@''''''''''
'''''''''''@@'@@'''@@@@@@@@'''''@@@@@@@@'''@@'@@'''''''''''
''''''''''''@@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@@@'''''''''''
'''''''''''''@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@'''''''''''''
''''@@@'''''''@@''@@@@@@@@'''''''@@@@@@@@@''@@''''''@@@@'''
'''@@@@@'''''@@'''@@@@@@@'''@@@'''@@@@@@@'''@@'''''@@@@@@''
''@@'''@@''''@@'''''@@@''''@@@@@''''@@@'''''@@''''@@'''@@''
'@@@''''@@@@''@@''''''''''@@@@@@@''''''''''@@''@@@@''''@@@'
@@'''''''''@@@@@@@@'''''''@@@'@@@'''''''@@@@@@@@@''''''''@@
@@@@@@@@@'''''@@@@@@@@''''@@'''@@''''@@@@@@@@''''''@@@@@@@@
''@@@@'@@@@@''''''@@@@@''''''''''''''@@@'@@'''''@@@@@@'@@@'
''''''''''@@@@@@''@@@''@@'''''''''''@@''@@@''@@@@@@''''''''
''''''''''''''@@@@@@'@@'@@@@@@@@@@@'@@'@@@@@@''''''''''''''
''''''''''''''''''@@'@@'@'@'@'@'@'@'@'@'@@'''''''''''''''''
''''''''''''''''@@@@''@'@'@'@'@'@'@'@'''@@@@@''''''''''''''
''''''''''''@@@@@'@@'''@@@@@@@@@@@@@'''@@'@@@@@''''''''''''
''''@@@@@@@@@@'''''@@'''''''''''''''''@@''''''@@@@@@@@@''''
'''@@'''''''''''@@@@@@@'''''''''''''@@@@@@@@''''''''''@@'''
''''@@@'''''@@@@@'''''@@@@@@@@@@@@@@@'''''@@@@@'''''@@@''''
''''''@@'''@@@'''''''''''@@@@@@@@@'''''''''''@@@'''@@''''''
''''''@@''@@'''''''''''''''''''''''''''''''''''@@''@@''''''
'''''''@@@@'''''''''''''''''''''''''''''''''''''@@@@'''''''

"""


# module imports
import pygame
import libtcodpy as doryen


# game file imports
import constants


# test statement
print "\nHello World\n"



#######################################################################################################
#   _____   ___  ___  ___ _____
#  |  __ \ / _ \ |  \/  ||  ___|
#  | |  \// /_\ \| .  . || |__ 
#  | | __ |  _  || |\/| ||  __|
#  | |_\ \| | | || |  | || |___
#   \____/\_| |_/\_|  |_/\____/
#
#######################################################################################################

def gameInit():

	'''
	initializes the main game window and pygame module
	'''

	# variables
	global SURFACE_MAIN, GAME, CLOCK, LOS_CALC, PLAYER, ENEMY, Assets

	# initialize pygame
	pygame.init()
	pygame.key.set_repeat(200, 100)

	SURFACE_MAIN = pygame.display.set_mode( (constants.DISPLAY_WIDTH,constants.DISPLAY_HEIGHT) )

	GAME = objGame()

	CLOCK = pygame.time.Clock()

	LOS_CALC = True

	Assets = structAssets()

	creatureComp1 = compCreature("Kermit")
	containerComp1 = compContainer()
	PLAYER = objActor(1, 1, "frog", Assets.ANIM_PLAYER, creature = creatureComp1, container = containerComp1)

	creatureComp2 = compCreature("Krusty", deathFunction = deathMonster)
	aiComp2 = aiTest()
	itemComp2 = compItem(useFunction = castHeal, useValue = 5)
	ENEMY  = objActor(constants.MAP_WIDTH - 2, constants.MAP_HEIGHT - 2, "crab", Assets.ANIM_ENEMY,
		creature = creatureComp2, ai = aiComp2, item = itemComp2)

	creatureComp3 = compCreature("Pauly", deathFunction = deathMonster)
	aiComp3 = aiTest()
	itemComp3 = compItem(useFunction = castHeal, useValue = 3)
	ENEMY_2  = objActor(constants.MAP_WIDTH - 2, 1, "python", Assets.ANIM_ENEMY_2,
		creature = creatureComp3, ai = aiComp3, item = itemComp3)


	GAME._currentObjects = [PLAYER, ENEMY, ENEMY_2]


def gameMainLoop():

	'''
	the main game loop
	'''

	# define the player's action
	playerAction = "no-action"

	# flag to exit the game
	gameOver = False

	while not gameOver:
		# get input and process it
		playerAction = handleInput()

		mapCalcLOS()
		
		if playerAction == "QUIT":
			gameOver = True

		elif playerAction != "no-action":
			# gameMessage(playerAction)
			for obj in GAME._currentObjects:
				if obj.ai:
					obj.ai.takeTurn()

		# draw game
		drawGame()

		# update display
		pygame.display.flip()

		# tick the clock
		CLOCK.tick(constants.GAME_FPS)

	print "\nGoodbye World\n"
	pygame.quit()
	exit()


def handleInput():
	global LOS_CALC

	# get list of events
	eventList = pygame.event.get()

	# handle those events
	for event in eventList:
		# player clicks the window's X button
		if event.type == pygame.QUIT:
			return "QUIT"

		# player presses a key
		if event.type == pygame.KEYDOWN:

			# up arrow => move up
			if event.key == pygame.K_UP:
				PLAYER.creature.move(0, -1)
				LOS_CALC = True
				return "player-moved-north"

			# down arrow => move down
			if event.key == pygame.K_DOWN:
				PLAYER.creature.move(0, 1)
				LOS_CALC = True
				return "player-moved-south"

			# left arrow => move left
			if event.key == pygame.K_LEFT:
				PLAYER.creature.move(-1, 0)
				LOS_CALC = True
				return "player-moved-west"

			# right arrow => move right
			if event.key == pygame.K_RIGHT:
				PLAYER.creature.move(1, 0)
				LOS_CALC = True
				return "player-moved-east"

			# g key => pick up (get) items at the player's location
			if event.key == pygame.K_g:
				objectsAtPlayer = mapObjectsAtLocation(PLAYER._x, PLAYER._y)
				for obj in objectsAtPlayer:
					if obj.item:
						obj.item.pickUp(PLAYER)

			# d key => player takes 1
			if event.key == pygame.K_d:
			#	if len(PLAYER.container._inventory) > 0:
			#		PLAYER.container._inventory[-1].item.drop(PLAYER._x, PLAYER._y)
				PLAYER.creature.takeDamage(1)

			# p key => pause menu
			if event.key == pygame.K_p:
				menuPause()

			# i key => inventory menu
			if event.key == pygame.K_i:
				menuInventory()

			# l key => cast lightning
			if event.key == pygame.K_l:
				castLightning(10)


	# no action taken
	return "no-action"


def gameMessage(messageText, textColor = constants.COLOR_WHITE):

	'''
	adds the submitted text to the GAME._messageLog list as a tuple
	'''

	GAME._messageLog.append((messageText, textColor))



#######################################################################################################
#  ___  ___ _____ _   _ _   _ _____ 
#  |  \/  ||  ___| \ | | | | /  ___|
#  | .  . || |__ |  \| | | | \ `--. 
#  | |\/| ||  __|| . ` | | | |`--. \
#  | |  | || |___| |\  | |_| /\__/ /
#  \_|  |_/\____/\_| \_/\___/\____/ 
#
#######################################################################################################

def menuPause():

	'''
	pause game
	'''

	menuText = "PAUSED"
	menuFont = Assets.FONT_DEBUG

	xOffset = helperTextWidth(menuFont) * len(menuText) / 2
	yOffset = helperTextHeight(menuFont) / 2


	drawText(SURFACE_MAIN, menuText, (constants.DISPLAY_WIDTH/2 - xOffset, constants.DISPLAY_HEIGHT/2 - yOffset),
		menuFont, constants.COLOR_WHITE, constants.COLOR_BLACK)
	pygame.display.flip()

	while True:
		# tick the clock to avoid animation errors while paused
		CLOCK.tick(constants.GAME_FPS)

		eventList = pygame.event.get()
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_p:
					return


def menuInventory():

	'''
	displays the player's inventory
	'''

	menuFont = Assets.FONT_MESSAGE
	menuTextHeight = helperTextHeight(menuFont)

	menuHeight = 200
	menuWidth  = 200

	menuXPos = constants.DISPLAY_WIDTH/2 - menuWidth/2
	menuYPos = constants.DISPLAY_HEIGHT/2 - menuHeight/2

	menuSurface = pygame.Surface( (menuWidth, menuHeight) )

	while True:
		# populate the inventory list
		menuList = [obj._nameObject for obj in PLAYER.container._inventory]

		# clear menu
		menuSurface.fill(constants.COLOR_BLACK)

		# register changes
		eventList = pygame.event.get()

		mouseX, mouseY = pygame.mouse.get_pos()
		mouseMenuX = mouseX - menuXPos
		mouseMenuY = mouseY - menuYPos

		mouseInWindow = ((mouseMenuX in range(0, menuWidth)) and
						(mouseMenuY in range(0, menuHeight)))

		mouseMenuLine = -1
		if mouseInWindow:
			mouseMenuLine = mouseMenuY // menuTextHeight

		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_i:
					return
			if event.type == pygame.MOUSEBUTTONDOWN:
				if ((event.button == 1) and
					mouseInWindow and
					(mouseMenuLine < len(menuList))):
					# mouse button 1 to use selected item
					PLAYER.container._inventory[mouseMenuLine].item.use()
				if ((event.button == 3) and
					mouseInWindow and
					(mouseMenuLine < len(menuList))):
					# mouse button 2 to drop selected item
					PLAYER.container._inventory[mouseMenuLine].item.drop(PLAYER._x, PLAYER._y)

		# draw the menuList
		line = 0
		for inventoryItem in menuList:
			if line == mouseMenuLine:
				highlight = constants.COLOR_GRAY
			else:
				highlight = None
			drawText(menuSurface, str(line + 1) + ") " + inventoryItem, (0, line * menuTextHeight),
				menuFont, constants.COLOR_WHITE, highlight)
			line += 1

		# tick the clock
		CLOCK.tick(constants.GAME_FPS)

		# draw the game
		drawGame()

		# display menu
		SURFACE_MAIN.blit(menuSurface, (menuXPos, menuYPos))

		# refresh the display
		pygame.display.flip()


def menuTargetSelect():

	'''
	The player selects a tile to target.

	Pauses the game, produces an onscreen rectangle controlled by the mouse, when the LMB is clicked,
	returns the map coordinates.

	'''

	while True:

		# get mouse pos
		(mouseX, mouseY) = pygame.mouse.get_pos()
		mouseMapX = mouseX / constants.TILE_WIDTH
		mouseMapY = mouseY / constants.TILE_HEIGHT

		# get button click
		eventList = pygame.event.get()

		# return map coords when LMB is clicked
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_l:
					print("Cancelled")
					return None
			if event.type == pygame.MOUSEBUTTONDOWN:
				if (event.button == 1):
					# mouse button 1 to use select a tile to target, returns map tile coords
					return (mouseMapX, mouseMapY)

		# draw game
		drawGame()

		# draw rectangle at mouse pos
		drawTarget((mouseMapX, mouseMapY))

		# update display
		pygame.display.flip()

		# tick the clock
		CLOCK.tick(constants.GAME_FPS)




#######################################################################################################
#  ____________  ___  _    _ 
#  |  _  \ ___ \/ _ \| |  | |
#  | | | | |_/ / /_\ \ |  | |
#  | | | |    /|  _  | |/\| |
#  | |/ /| |\ \| | | \  /\  /
#  |___/ \_| \_\_| |_/\/  \/
#
#######################################################################################################

def drawGame():

	'''
	draws the game on the main surface
	'''

	# variables
	global SURFACE_MAIN

	# clear surface
	SURFACE_MAIN.fill(constants.COLOR_BACKGROUND_DEFAULT)

	# draw the map
	drawMap(GAME._currentMap)

	# draw all objects
	for obj in GAME._currentObjects:
		obj.draw()

	drawDebug()
	drawMessages()


def drawMap(map):

	'''
	draws the map
	'''

	global LOS_MAP

	# cycle through map cells and draw a wall or a floor tile
	for y in range(constants.MAP_HEIGHT):
		for x in range(constants.MAP_WIDTH):

			if doryen.map_is_in_fov(LOS_MAP, x, y):

				map[x][y]._explored = True

				if map[x][y]._impassable == True:
					# draw wall
					SURFACE_MAIN.blit(Assets.SPRITE_WALL, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))
				else:
					# draw floor
					SURFACE_MAIN.blit(Assets.SPRITE_FLOOR, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))

			elif map[x][y]._explored:
				if map[x][y]._impassable == True:
					# draw unlit wall
					SURFACE_MAIN.blit(Assets.SPRITE_WALL_DARK, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))
				else:
					# draw unlit floor
					SURFACE_MAIN.blit(Assets.SPRITE_FLOOR_DARK, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))


def drawText(displaySurface, textToDisplay, tupCoords, textFont, textColor, backgroundColor = None):

	'''
	displays submitted text on the referenced surface
	'''

	textSurface, textRect = helperTextObjects(textToDisplay, textFont, textColor, backgroundColor)

	textRect.topleft = tupCoords

	displaySurface.blit(textSurface, textRect)


def drawDebug():

	'''
	draws debug messages (FPS)
	'''

	drawText(SURFACE_MAIN, "fps: " + str(int(CLOCK.get_fps())), (0, 0),
		Assets.FONT_DEBUG, constants.COLOR_WHITE, constants.COLOR_BLACK)


def drawMessages():

	'''
	draws game messages
	'''

	if len(GAME._messageLog) < constants.NUM_MESSAGES:
		textToDraw = GAME._messageLog
	else:
		textToDraw = GAME._messageLog[-(constants.NUM_MESSAGES):]

	textHeight = helperTextHeight(Assets.FONT_MESSAGE)
	startY = constants.DISPLAY_HEIGHT - (constants.NUM_MESSAGES * textHeight)

	i = 0
	for message, color in textToDraw:
		drawText(SURFACE_MAIN, message, (0, startY + i), Assets.FONT_MESSAGE, color, constants.COLOR_BLACK)
		i += textHeight


def drawTarget(coords):

	'''

	'''

	mapX, mapY = coords
	mapX *= constants.TILE_WIDTH
	mapY *= constants.TILE_HEIGHT

	newSurface = pygame.Surface((constants.TILE_WIDTH, constants.TILE_HEIGHT))

	newSurface.fill(constants.COLOR_WHITE)
	newSurface.set_alpha(150)

	SURFACE_MAIN.blit(newSurface, (mapX, mapY))



#######################################################################################################
#   _   _  _____ _     ______ ___________  _____ 
#  | | | ||  ___| |    | ___ \  ___| ___ \/  ___|
#  | |_| || |__ | |    | |_/ / |__ | |_/ /\ `--. 
#  |  _  ||  __|| |    |  __/|  __||    /  `--. \
#  | | | || |___| |____| |   | |___| |\ \ /\__/ /
#  \_| |_/\____/\_____/\_|   \____/\_| \_|\____/
#
#######################################################################################################

def helperTextObjects(incText, incFont, incColor, incBackground):

	'''
	returns a text surface and rectangle
	'''

	if incBackground:
		surface = incFont.render(incText, False, incColor, incBackground)
	else:
		surface = incFont.render(incText, False, incColor)

	return surface, surface.get_rect()


def helperTextHeight(font):
	 
	'''
	returns the height (in pixels) of the submitted font
	'''

	fontObj = font.render('a', False, (0, 0, 0))
	fontRect = fontObj.get_rect()

	return fontRect.height


def helperTextWidth(font):

	'''
	returns the width (in pixels) of the submitted font
	'''

	fontObj = font.render('a', False, (0, 0, 0))
	fontRect = fontObj.get_rect()

	return fontRect.width



#######################################################################################################
#  ___  ___  ___  ______ 
#  |  \/  | / _ \ | ___ \
#  | .  . |/ /_\ \| |_/ /
#  | |\/| ||  _  ||  __/
#  | |  | || | | || |   
#  \_|  |_/\_| |_/\_|
#
#######################################################################################################

def mapMake():

	'''
	makes and returns a map as an array
	'''

	# create a blank map
	newMap = [[structTile(False) for y in range(constants.MAP_HEIGHT)] for x in range(constants.MAP_WIDTH)]

	# add random wall tiles to map
	numWalls = doryen.random_get_int(0, 5, 10)
	for i in range(numWalls):
		wallX = doryen.random_get_int(0, 2, constants.MAP_WIDTH - 3)
		wallY = doryen.random_get_int(0, 2, constants.MAP_HEIGHT - 3)
		newMap[wallX][wallY]._impassable = True

	for x in range(constants.MAP_WIDTH):
		newMap[x][0]._impassable = True
		newMap[x][constants.MAP_HEIGHT - 1]._impassable = True
	for y in range(constants.MAP_HEIGHT):
		newMap[0][y]._impassable = True
		newMap[constants.MAP_WIDTH - 1][y]._impassable = True

	mapMakeLOS(newMap)

	return newMap


def mapCheckForTarget(xPos, yPos, excludeObj = None):

	'''
	checks the submitted (x, y) location for a creature other than the excluded one and returns that object
	'''

	for obj in GAME._currentObjects:
		if ((obj is not excludeObj) and
			(obj._x == xPos) and
			(obj._y == yPos) and
			(obj.creature)):
			return obj
	return None


def mapMakeLOS(incomingMap):

	'''

	'''

	global LOS_MAP
	LOS_MAP = doryen.map_new(constants.MAP_WIDTH, constants.MAP_HEIGHT)

	for y in range(constants.MAP_HEIGHT):
		for x in range(constants.MAP_WIDTH):
			doryen.map_set_properties(LOS_MAP, x, y,
				not incomingMap[x][y]._impassable,
				not incomingMap[x][y]._impassable)


def mapCalcLOS():

	'''

	'''

	global LOS_CALC

	if LOS_CALC:
		LOS_CALC = False
		doryen.map_compute_fov(LOS_MAP, PLAYER._x, PLAYER._y,
			constants.LOS_LIGHT_RADIUS,
			constants.LOS_LIGHT_WALLS,
			constants.LOS_ALGO)


def mapObjectsAtLocation(xCoord, yCoord):

	'''

	'''

	objectList = [obj for obj in GAME._currentObjects if obj._x == xCoord and obj._y == yCoord]

	return objectList

def mapFindLine(coords1, coords2):
	
	'''
	Converts two sets of (x, y) map coords into a list of tiles that make up that line

	coords1 : (x1, y1)
	coords2 : (x2, y2)
	'''

	x1, y1 = coords1
	x2, y2 = coords2

	if (x1 == x2) and (y1 == y2):
		return [(x1, y1)]

	doryen.line_init(x1, y1, x2, y2)

	lineCoords = doryen.line_step()

	lineCoordsList = []

	while lineCoords != (None, None):
		lineCoordsList.append(lineCoords)
		lineCoords = doryen.line_step()

	return lineCoordsList


#######################################################################################################
#   _____ ___________ _   _ _____ _____ _   _______ _____ _____ 
#  /  ___|_   _| ___ \ | | /  __ \_   _| | | | ___ \  ___/  ___|
#  \ `--.  | | | |_/ / | | | /  \/ | | | | | | |_/ / |__ \ `--. 
#   `--. \ | | |    /| | | | |     | | | | | |    /|  __| `--. \
#  /\__/ / | | | |\ \| |_| | \__/\ | | | |_| | |\ \| |___/\__/ /
#  \____/  \_/ \_| \_|\___/ \____/ \_/  \___/\_| \_\____/\____/
#
#######################################################################################################

class structTile:

	'''
	map tiles
	'''

	def __init__(self, impassable):
		self._impassable = impassable
		self._explored = False


class structAssets:
	
	'''
	game assets
	'''

	def __init__(self):

		# sprite sheets
		tempSpriteSheet  = objSpriteSheet("C:\Users\Robin\Desktop\Pyrate\graphicAssets/TempSpriteSheet.png")
		tempSpriteSheet2 = objSpriteSheet("C:\Users\Robin\Desktop\Pyrate\graphicAssets/ReptileSpriteSheet.png")

		# animations
		self.ANIM_PLAYER = tempSpriteSheet.getAnimation('c', 6, 16, 16, 2, (32, 32))
		self.ANIM_ENEMY  = tempSpriteSheet.getAnimation('c', 1, 16, 16, 2, (32, 32))
		self.ANIM_ENEMY_2 = tempSpriteSheet2.getAnimation('m', 5, 16, 16, 2, (32, 32))

		# sprites
		self.SPRITE_FLOOR      = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/Floor.jpg")
		self.SPRITE_FLOOR_DARK = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/FloorDark.png")
		self.SPRITE_WALL       = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/Wall.jpg")
		self.SPRITE_WALL_DARK  = pygame.image.load("C:\Users\Robin\Desktop\Pyrate\graphicAssets/WallDark.png")

		# fonts
		self.FONT_DEBUG   = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 16)
		self.FONT_MESSAGE = pygame.font.Font("C:\Users\Robin\Desktop\Pyrate\graphicAssets\Fonts\Joystick/Joystick.otf", 12)

#######################################################################################################
#   ___________   ___ _____ _____ _____ _____ 
#  |  _  | ___ \ |_  |  ___/  __ \_   _/  ___|
#  | | | | |_/ /   | | |__ | /  \/ | | \ `--.
#  | | | | ___ \   | |  __|| |     | |  `--. \
#  \ \_/ / |_/ /\__/ / |___| \__/\ | | /\__/ /
#   \___/\____/\____/\____/ \____/ \_/ \____/ 
#
#######################################################################################################

class objActor:

	'''
	any game element that can move/interact with other elements
	'''

	global LOS_MAP

	def __init__(self, x, y, nameObject, animation, animationDuration = 1.0,
		creature = None, ai = None, container = None, item = None):

		# map address
		self._x = x
		self._y = y

		self._nameObject = nameObject

		# sprite
		self._animation = animation
		self._animationDuration = animationDuration / 1.0
		self._flickerSpeed = self._animationDuration / len(self._animation) # individual frame duration
		self._flickterTimer = 0.0
		self._spriteCounter = 0

		# creature
		self.creature = creature
		if self.creature:
			self.creature.owner = self

		self.ai = ai
		if self.ai:
			self.ai.owner = self

		self.container = container
		if self.container:
			self.container.owner = self

		self.item = item
		if self.item:
			self.item.owner = self


	def draw(self):
		if doryen.map_is_in_fov(LOS_MAP, self._x, self._y):
			SURFACE_MAIN.blit(self._animation[self._spriteCounter], (self._x * constants.TILE_WIDTH, self._y * constants.TILE_HEIGHT))
			if len(self._animation) > 1:
				if CLOCK.get_fps() > 0.0:
					self._flickterTimer += 1 / CLOCK.get_fps()
				if self._flickterTimer >= self._flickerSpeed:
					self._flickterTimer = 0.0
					if self._spriteCounter >= len(self._animation) - 1:
						self._spriteCounter = 0
					else:
						self._spriteCounter += 1




class objGame:

	'''

	'''

	def __init__(self):

		self._currentMap = mapMake()
		self._currentObjects = []

		self._messageLog = []


class objSpriteSheet:
	
	'''
	grab images from a spritesheet
	'''

	def __init__(self, fileName):
		# load spritesheet
		self._spriteSheet = pygame.image.load(fileName).convert()
		self._spriteDict = {'a':  1, 'b':  2, 'c':  3, 'd':  4, 'e':  5, 'f':  6, 'g':  7, 'h':  8,
							'i':  9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'o': 15, 'p': 16}


	def getAnimation(self, column, row, width = constants.TILE_WIDTH, height = constants.TILE_HEIGHT, numSprites = 1, scale = None):

		spriteList = []

		for i in range(numSprites):
			image = pygame.Surface([width, height]).convert()
			image.blit(self._spriteSheet, (0, 0), ((self._spriteDict[column] + i) * width, row * height, width, height))
			image.set_colorkey(constants.COLOR_BLACK)

			if scale:
				image = pygame.transform.scale(image, scale)

			spriteList.append(image)

		return spriteList


#######################################################################################################
#   _____ ________  _________ _____ _   _  _____ _   _ _____ _____
#  /  __ \  _  |  \/  || ___ \  _  | \ | ||  ___| \ | |_   _/  ___|
#  | /  \/ | | | .  . || |_/ / | | |  \| || |__ |  \| | | | \ `--.
#  | |   | | | | |\/| ||  __/| | | | . ` ||  __|| . ` | | |  `--. \
#  | \__/\ \_/ / |  | || |   \ \_/ / |\  || |___| |\  | | | /\__/ /
#   \____/\___/\_|  |_/\_|    \___/\_| \_/\____/\_| \_/ \_/ \____/
#
#######################################################################################################

class compCreature:

	'''
	have health and can die
	can damage other objects by attacking them
	'''

	def __init__(self, nameInstance, health = 10, deathFunction = None):
		self._nameInstance = nameInstance
		self._maxHealth = health
		self._health = health
		self.deathFunction = deathFunction

	def attack(self, target, damage):
		gameMessage((self.owner.creature._nameInstance + " attacks " + target.creature._nameInstance + " for " + str(damage) + " damage!"))
		target.creature.takeDamage(damage)

	def takeDamage(self, damage):
		self._health -= damage
		gameMessage((self._nameInstance + "'s health: " + str(self._health) + "/" + str(self._maxHealth)), constants.COLOR_RED)

		if (self._health <= 0) and (self.deathFunction):
			self.deathFunction(self.owner)

	def healDamage(self, value):
		if value > (self._maxHealth - self._health):
			value = (self._maxHealth - self._health)
		self._health += value
		gameMessage((self._nameInstance + " healed for " + str(value) + " hp!"))
		gameMessage((self._nameInstance + "'s health: " + str(self._health) + "/" + str(self._maxHealth)), constants.COLOR_RED)		

	def move(self, xDiff, yDiff):
		tileIsWall = GAME._currentMap[self.owner._x + xDiff][self.owner._y + yDiff]._impassable

		target = mapCheckForTarget(self.owner._x + xDiff, self.owner._y + yDiff, self.owner)

		if target:
			self.attack(target, doryen.random_get_int(0, 1, 6))

		if not tileIsWall and target == None:
			self.owner._x += xDiff
			self.owner._y += yDiff


class compItem:

	'''
	component that defines the properties of items
	'''

	def __init__(self, weight = 0.0, volume = 0.0, useFunction = None, useValue = None):

		self._weight = weight
		self._volume = volume
		self._useFunction = useFunction
		self._useValue = useValue


	# pick up item
	def pickUp(self, actor):

		'''
		Picks up the item
		'''

		if actor.container:
			if actor.container.getVolume() + self._volume > actor.container._maxVolume:
				gameMessage("Not enough room to pick up", constants.COLOR_RED)
			else:
				gameMessage("Item picked up")
				actor.container._inventory.append(self.owner)
				GAME._currentObjects.remove(self.owner)
				self.currentContainer = actor.container


	# drop item
	def drop(self, newX, newY):

		'''
		Drops the item
		'''

		GAME._currentObjects.append(self.owner)	
		self.currentContainer._inventory.remove(self.owner)
		self.owner._x = newX
		self.owner._y = newY
		gameMessage("Item dropped", constants.COLOR_RED)	


	# use item
	def use(self):

		'''
		Uses the item
		'''

		if self._useFunction:
			result = self._useFunction(self.owner.item.currentContainer.owner, self._useValue)

			if result is not None:
				print("useFunction failed")
			else:
				self.currentContainer._inventory.remove(self.owner)
				gameMessage("Item used", constants.COLOR_RED)




class compContainer:

	'''

	'''

	def __init__(self, volume = 10.0, inventory = []):
		self._maxVolume = volume
		self._inventory = inventory

	# get names of all items in inventory


	# get volume of all items held in container
	def getVolume(self):
		volume = 0.0
		for obj in self._inventory:
			if obj.item:
				volume += obj.item._volume
		return volume



	# get weight of all items held in container



#######################################################################################################
#  ___  ___  ___  _____ _____ _____ 
#  |  \/  | / _ \|  __ \_   _/  __ \
#  | .  . |/ /_\ \ |  \/ | | | /  \/
#  | |\/| ||  _  | | __  | | | |    
#  | |  | || | | | |_\ \_| |_| \__/\
#  \_|  |_/\_| |_/\____/\___/ \____/
#
#######################################################################################################


def castHeal(target, value):

	'''
	Item heals the targe when used
	'''

	targetName = target.creature._nameInstance + " the " + target._nameObject

	if (target.creature._health >= target.creature._maxHealth):
		print(targetName + " is already at full health.")
		return "cancelled"
	else:
		target.creature.healDamage(value)
	return None


def castLightning(damage):

	'''
	Casts a lightning bolt along the specified line
	'''

	# prompt the player for a tile
	targetCoords = menuTargetSelect()
	if targetCoords == None:
		return

	# convert that tile into a list of tiles (a line)
	lightningPathList = mapFindLine((PLAYER._x, PLAYER._y), targetCoords)

	# cycle through the list and damage everything found
	for i, (x, y) in enumerate(lightningPathList):
		target = mapCheckForTarget(x, y)
		if target and (i != 0):
			target.creature.takeDamage(damage)


#######################################################################################################
#    ___  _____ 
#   / _ \|_   _|
#  / /_\ \ | |  
#  |  _  | | |  
#  | | | |_| |_ 
#  \_| |_/\___/
#
#######################################################################################################

class aiTest:

	'''
	AI rules for creatures
	  act once per turn
	  move randomly
	'''

	def takeTurn(self):
		self.owner.creature.move(doryen.random_get_int(0, -1, 1), doryen.random_get_int(0, -1, 1))


def deathMonster(monster):
	
	'''
	defines what happens when a monster dies (they stop moving and are no longer a creature)
	'''

	gameMessage ((monster.creature._nameInstance + " is dead!"), constants.COLOR_GRAY)

	monster.creature = None
	monster.ai = None







#######################################################################################################
#   _      _____ _____   _____ _____  ______ _____ _____ _____ _   _   _ 
#  | |    |  ___|_   _| |_   _|_   _| | ___ \  ___|  __ \_   _| \ | | | |
#  | |    | |__   | |     | |   | |   | |_/ / |__ | |  \/ | | |  \| | | |
#  | |    |  __|  | |     | |   | |   | ___ \  __|| | __  | | | . ` | | |
#  | |____| |___  | |    _| |_  | |   | |_/ / |___| |_\ \_| |_| |\  | |_|
#  \_____/\____/  \_/    \___/  \_/   \____/\____/ \____/\___/\_| \_/ (_)
#
#######################################################################################################

gameInit()
gameMainLoop()


