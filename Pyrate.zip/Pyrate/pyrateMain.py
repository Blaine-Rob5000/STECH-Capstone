
"""

Pyrate - (noun) an archaic spelling of 'pirate'

	Also:  a roguelike game written in python (v 2.7.8) by RG Blaine using pygame and the doryen library (libtcod)


Credits:

	Graphics courtesy of DragonDePlatino and DawnBringer
		https://opengameart.org/content/dawnlike-16x16-universal-rogue-like-tileset-v181

	Music from Jukedeck - create your own at http://jukedeck.com

	Special thanks to Michael Coates, the self-proclaimed "Terrible Programmer" for his
		YouTube tutorial on pygame, the doryen library, and roguelike game programming

"""

#################################################################
#                                                               #
#  ''''''''''''''''''' @@@@@@@@@@@@@@@@@@@''''''''''''''''''''  #
#  '''''''''''''''''@@@@@@'''''''''''''@@@@@@@''''''''''''''''  #
#  ''''''''''''''@@@@'''''''''''''''''''''''@@@@''''''''''''''  #
#  '''''''''''''@@@'''''''''''''''''''''''''''''@@''''''''''''  #
#  ''''''''''''@@''''''''''''''''''''''''''''''''@@'''''''''''  #
#  '''''''''''@@'''''''''''''''''''''`'''''''''''@@'''''''''''  #
#  ''''''''''@@'''''''''''''''''''''''''''''''''''@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@''@@''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@''@@'''''''''''''''''''''''''''@@''@@''''''''''  #
#  '''''''''''@@'@@'''@@@@@@@@'''''@@@@@@@@'''@@'@@'''''''''''  #
#  ''''''''''''@@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@@@'''''''''''  #
#  '''''''''''''@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@'''''''''''''  #
#  ''''@@@'''''''@@''@@@@@@@@'''''''@@@@@@@@@''@@''''''@@@@'''  #
#  '''@@@@@'''''@@'''@@@@@@@'''@@@'''@@@@@@@'''@@'''''@@@@@@''  #
#  ''@@'''@@''''@@'''''@@@''''@@@@@''''@@@'''''@@''''@@'''@@''  #
#  '@@@''''@@@@''@@''''''''''@@@@@@@''''''''''@@''@@@@''''@@@'  #
#  @@'''''''''@@@@@@@@'''''''@@@'@@@'''''''@@@@@@@@@''''''''@@  #
#  @@@@@@@@@'''''@@@@@@@@''''@@'''@@''''@@@@@@@@''''''@@@@@@@@  #
#  ''@@@@'@@@@@''''''@@@@@''''''''''''''@@@'@@'''''@@@@@@'@@@'  #
#  ''''''''''@@@@@@''@@@''@@'''''''''''@@''@@@''@@@@@@''''''''  #
#  ''''''''''''''@@@@@@'@@'@@@@@@@@@@@'@@'@@@@@@''''''''''''''  #
#  ''''''''''''''''''@@'@@'@'@'@'@'@'@'@'@'@@'''''''''''''''''  #
#  ''''''''''''''''@@@@''@'@'@'@'@'@'@'@'''@@@@@''''''''''''''  #
#  ''''''''''''@@@@@'@@'''@@@@@@@@@@@@@'''@@'@@@@@''''''''''''  #
#  ''''@@@@@@@@@@'''''@@'''''''''''''''''@@''''''@@@@@@@@@''''  #
#  '''@@'''''''''''@@@@@@@'''''''''''''@@@@@@@@''''''''''@@'''  #
#  ''''@@@'''''@@@@@'''''@@@@@@@@@@@@@@@'''''@@@@@'''''@@@''''  #
#  ''''''@@'''@@@'''''''''''@@@@@@@@@'''''''''''@@@'''@@''''''  #
#  ''''''@@''@@'''''''''''''''''''''''''''''''''''@@''@@''''''  #
#  '''''''@@@@'''''''''''''''''''''''''''''''''''''@@@@'''''''  #
#                                                               #
#################################################################

## module imports ##
import pygame
import libtcodpy as doryen
import math
import pickle
import gzip
import datetime
import os

## game file imports ##
import constants as const


#######################################################################################################
#   _____   ___  ___  ___ _____
#  |  __ \ / _ \ |  \/  ||  ___|
#  | |  \// /_\ \| .  . || |__ 
#  | | __ |  _  || |\/| ||  __|
#  | |_\ \| | | || |  | || |___
#   \____/\_| |_/\_|  |_/\____/
#
#######################################################################################################

def gameInit():

	'''
	initializes the main game window, pygame module, and global vars
	'''

	# variables
	global ASSETS, CAMERA, CLOCK, GAME, LOS_CALC, PLAYER, SURFACE_MAIN, PREFERENCES, SURFACE_MAP

	# initialize pygame
	pygame.init()
	pygame.key.set_repeat(200, 100)

	PREFERENCES = structPreferences()

	nameInit()

	SURFACE_MAIN = pygame.display.set_mode((const.DISPLAY_WIDTH, const.DISPLAY_HEIGHT))

	SURFACE_MAP = pygame.Surface((const.MAP_SURFACE_WIDTH, const.MAP_SURFACE_HEIGHT))

	CAMERA = objCamera()

	CLOCK = pygame.time.Clock()

	LOS_CALC = True

	ASSETS = objAssets()

	GAME = objGame()

	PLAYER = genPlayer(GAME._roomsCurrent[0]._center)

####

def gameNew():

	'''
	starts a new game
	'''

	gameInit()

	mapPopulate(GAME._roomsCurrent)

	# give the player a few items to pick up on the first level (maybe!)

	genItem((PLAYER._x - 1, PLAYER._y - 1))
	randNum = doryen.random_get_int(0, 1, 100)
	if randNum > 25:
		genItem((PLAYER._x + 1, PLAYER._y - 1))
	if randNum > 50:
		genItem((PLAYER._x - 1, PLAYER._y + 1))
	if randNum > 75:
		genItem((PLAYER._x + 1, PLAYER._y + 1))
				
####

def gameMainLoop():

	'''
	the main game loop
	'''

	LOS_CALC = True

	gameMessage("Welcome to Pyrate!")
	gameMessage("Press H for help.")

	# define the player's action
	playerAction = "no-action"

	while True:
		mapCalcLOS()

		# get input and process it
		playerAction = handleInput()

		if playerAction == "main-menu":
			return

		elif playerAction == "QUIT":
			gameMessage("Saving Game...")
			drawGame()
			pygame.display.update()
			gameSave()
			gameMessage("Game Saved")
			gameMessage("Goodbye!")
			drawGame()
			pygame.display.update()
			pygame.time.wait(1000)
			gameExit()

		elif playerAction != "no-action":
			# gameMessage(playerAction)
			for obj in GAME._objectsCurrent:
				if obj.ai:
					obj.ai.takeTurn()

		if PLAYER._status == "STATUS_DEAD":
			return

		if GAME._gameWon:
			return

		# draw game
		drawGame()

		# update display
		pygame.display.update()

		# tick the clock
		CLOCK.tick(const.GAME_FPS)

####

def gameExit():

	'''

	'''

	gameMessage("Goodbye!")

	pygame.quit()
	exit()

####

def gameSave():

	'''

	'''

	for obj in GAME._objectsCurrent:
		obj.animDestroy()
		if obj.container:
			for item in obj.container._inventory:
				item.animDestroy()
	
	with gzip.open('SaveData/savegame', 'wb') as file:
		pickle.dump([GAME, PLAYER], file)

	for obj in GAME._objectsCurrent:
		obj.animInit()

####

def gameLoad():

	'''

	'''
	global GAME, PLAYER

	with gzip.open('SaveData/savegame', 'rb') as file:
		GAME, PLAYER = pickle.load(file)

	mapMakeLOS(GAME._mapCurrent)

	for obj in GAME._objectsCurrent:
		obj.animInit()
	
####

def gameWin():

	'''

	'''

	GAME._gameWon = True

	gameMessage("You have escaped the dungeon... YOU WIN!!!", const.COLOR_PURPLE)

	drawGame()

	pygame.display.update()

	#delete save file if it exists
	try:
		os.remove('SaveData/savegame')
	except:
		pass

	pygame.time.wait(3000)

	SURFACE_MAIN.fill(const.COLOR_PURPLE)

	screenCenter = (const.DISPLAY_WIDTH // 2, const.DISPLAY_HEIGHT //2)

	drawText(SURFACE_MAIN, "YOU HAVE ESCAPED... YOU WIN!!!", screenCenter,
		textFont = const.FONT_DEATH,
		textColor = const.COLOR_WHITE,
		backgroundColor = None,
		center = True)

	pygame.display.update()

	# create legacy file
	genVictoryFile()

	pygame.time.wait(3000)

	pygame.mixer.music.load(ASSETS.MUSIC_BG1)
	pygame.mixer.music.play()

####

def handleInput():
	global LOS_CALC

	# get list of events
	eventList = pygame.event.get()

	# handle those events
	for event in eventList:
		# player clicks the window's X button
		if event.type == pygame.QUIT:
			return "QUIT"

		# player presses a key
		if event.type == pygame.KEYDOWN:

			# up arrow => move up
			if event.key == pygame.K_UP:
				PLAYER.creature.move(0, -1)
				LOS_CALC = True
				return "player-moved-north"

			# down arrow => move down
			if event.key == pygame.K_DOWN:
				PLAYER.creature.move(0, 1)
				LOS_CALC = True
				return "player-moved-south"

			# left arrow => move left
			if event.key == pygame.K_LEFT:
				PLAYER.creature.move(-1, 0)
				LOS_CALC = True
				return "player-moved-west"

			# right arrow => move right
			if event.key == pygame.K_RIGHT:
				PLAYER.creature.move(1, 0)
				LOS_CALC = True
				return "player-moved-east"

			# g key => pick up (get) items at the player's location
			if event.key == pygame.K_g:
				objectsAtPlayer = mapObjectsAtLocation(PLAYER._x, PLAYER._y)
				for obj in objectsAtPlayer:
					if obj.item:
						obj.item.pickUp(PLAYER)
				return "get-items"

			# h key => help menu
			if event.key == pygame.K_h:
				menuHelp()

			# p key => pause menu
			if event.key == pygame.K_p:
				return menuPause()

			# i key => inventory menu
			if event.key == pygame.K_i:
				menuInventory()

			# z key => use stairs at player's location
			if event.key == pygame.K_z:
				objList = mapObjectsAtLocation(PLAYER._x, PLAYER._y)
				for obj in objList:
					if obj.stairs:
						obj.stairs.use()
				return "use-stairs"

			# SPACEBAR => pass
			if event.key == pygame.K_SPACE:
				gameMessage(PLAYER._displayName + " waits...")		
				return "pass"

	# no action taken
	return "no-action"

####

def gameMessage(messageText,
	textColor = const.COLOR_WHITE):

	'''
	adds the submitted text to the GAME._messageLog list as a tuple
	'''

	GAME._messageLog.append((messageText, textColor))


#######################################################################################################
#   _   _   ___ 
#  | | | | /   \
#  | | | |  | |
#  | | | |  | |
#  | |_| | _| |_
#   \___/  \___/ 
#
#######################################################################################################

class uiButton:

	'''
	creates a GUI button
	'''

	def __init__(self, surface, buttonText, size, centerCoords,
		colorBoxDefault    = const.COLOR_BLUE,
		colorBoxMouseover  = const.COLOR_PURPLE,
		colorTextDefault   = const.COLOR_PURPLE,
		colorTextMouseover = const.COLOR_BLUE,
		colorOutline       = const.COLOR_BLACK):

		self._surface      = surface
		self._buttonText   = buttonText
		self._size         = size
		self._centerCoords = centerCoords

		self._colorBoxDefault    = colorBoxDefault
		self._colorBoxMouseover  = colorBoxMouseover
		self._colorTextDefault   = colorTextDefault
		self._colorTextMouseover = colorTextMouseover

		self._colorCurrentBox    = colorBoxDefault
		self._colorCurrentText   = colorTextDefault

		self._rect = pygame.Rect((0, 0), size)
		self._rect.center = centerCoords

		self._rectOutline = pygame.Rect((0, 0), (size[0] + 10, size[1] + 10))
		self._rectOutline.center = centerCoords
		self._colorOutline = colorOutline


	def update(self, menuInput):

		localEventList, localMousePos = menuInput

		mouseX, mouseY = localMousePos

		mouseClick = False

		mouseOver = (mouseX >= self._rect.left
			and mouseX <= self._rect.right
			and mouseY >= self._rect.top
			and mouseY <= self._rect.bottom)

		# highlight button
		if mouseOver:
			self._colorCurrentBox = self._colorBoxMouseover
			self._colorCurrentText = self._colorTextMouseover
		else:
			self._colorCurrentBox = self._colorBoxDefault
			self._colorCurrentText = self._colorTextDefault

		# handle menu events
		for event in localEventList:
			if event.type == pygame.QUIT:
				pygame.quit()
				exit()

			if event.type == pygame.MOUSEBUTTONDOWN:
				if event.button == 1: mouseClick = True

		if mouseOver and mouseClick:
			return True

	def draw(self):

		pygame.draw.rect(self._surface, self._colorOutline, self._rectOutline)
		pygame.draw.rect(self._surface, self._colorCurrentBox, self._rect)
		drawText(self._surface,
			self._buttonText,
			self._centerCoords,
			const.FONT_DEFAULT,
			self._colorCurrentText,
			center = True)

####

class uiSlider:

	'''
	creates a GUI slider
	'''

	def __init__(self, surface, size, centerCoords,
		labelText = None,
		labelTextFont = const.FONT_DEFAULT,
		lableTextColor = const.COLOR_MESSAGE_DEFAULT,
		labelTextBGColor = None,
		labelAbove = True,
		showPercent = False,
		percentFont = const.FONT_DEFAULT,
		percentColor = const.COLOR_MESSAGE_DEFAULT,
		parameterValue  = 0.50,
		colorBackground = const.COLOR_PURPLE,
		colorForeground = const.COLOR_GREEN,
		colorGrip = const.COLOR_BLACK):

		self._surface      = surface
		self._size         = size
		self._centerCoords = centerCoords

		self._lableText = labelText
		self._labelFont = labelTextFont
		self._labelColor = lableTextColor
		self._labelBGColor = labelTextBGColor

		labelTextHeight = helperTextHeight(self._labelFont)
		labelX = self._centerCoords[0]
		labelY = self._centerCoords[1]
		if labelAbove:
			labelY -= ((self._size[1] + 10) //2 + labelTextHeight //2)
		else:
			labelY += ((self._size[1] + 10) //2 + labelTextHeight //2)
		self._labelCenter = (labelX, labelY)

		self._showPercent = showPercent
		self._percentFont = percentFont
		self._percentColor = percentColor

		self._currentValue = parameterValue

		self._colorBackground = colorBackground
		self._colorForeground = colorForeground

		self._rectBG = pygame.Rect((0, 0), size)
		self._rectBG.center = centerCoords

		self._rectFG = pygame.Rect((0, 0), (size[0] * self._currentValue, size[1] * 2 // 3))
		self._rectFG.left = self._rectBG.left
		self._rectFG.centery = self._rectBG.centery

		self._rectGrip = pygame.Rect((0, 0), (8, self._rectBG.h))
		self._rectGrip.center = (self._rectFG.right, self._rectFG.centery)
		self._gripColor = colorGrip

		self._rectBorder = pygame.Rect((0, 0), (self._rectBG.w + 8, self._rectBG.h + 8))
		self._rectBorder.center = centerCoords


	def update(self, menuInput):

		'''

		'''

		mouseButtonDown = pygame.mouse.get_pressed()[0] == 1

		localEventList, localMousePos = menuInput

		mouseX, mouseY = localMousePos

		mouseOver = (mouseX >= self._rectBG.left
			and mouseX <= self._rectBG.right
			and mouseY >= self._rectBG.top
			and mouseY <= self._rectBG.bottom)

		if mouseButtonDown and mouseOver:
			self._currentValue = (mouseX - self._rectBG.left) / float(self._rectBG.width)

			self._currentValue = int(self._currentValue * 100) / 100.0
			self._rectFG.width = self._rectBG.width * self._currentValue

			self._rectGrip.center = (self._rectFG.right, self._rectFG.centery)

		return self._currentValue

	def draw(self):

		'''

		'''

		if self._lableText:
			drawText(self._surface, self._lableText, self._labelCenter,
				textFont = self._labelFont,
				textColor = self._labelColor,
				backgroundColor = self._labelBGColor,
				center = True)

		pygame.draw.rect(self._surface, self._gripColor, self._rectBorder)
		pygame.draw.rect(self._surface, self._colorBackground, self._rectBG)
		pygame.draw.rect(self._surface, self._colorForeground, self._rectFG)
		pygame.draw.rect(self._surface, self._gripColor, self._rectGrip)

		if self._showPercent:

			percentString = str(int(self._currentValue * 100)) + "%"
			drawText(self._surface, percentString, self._centerCoords,
				textFont = self._percentFont,
				textColor = self._percentColor,
				backgroundColor = None,
				center = True)


#######################################################################################################
#  ___  ___ _____ _   _ _   _ _____ 
#  |  \/  ||  ___| \ | | | | /  ___|
#  | .  . || |__ |  \| | | | \ `--. 
#  | |\/| ||  __|| . ` | | | |`--. \
#  | |  | || |___| |\  | |_| /\__/ /
#  \_|  |_/\____/\_| \_/\___/\____/ 
#
#######################################################################################################

def menuMain():

	'''
	main menu
	'''

	gameInit()

	effectsVol = PREFERENCES._volumeSound
	musicVol = PREFERENCES._volumeMusic

	titleX = const.DISPLAY_WIDTH // 5
	titleY = const.DISPLAY_HEIGHT // 3
	titleText = "PYRATE - MAIN MENU"
	titleOffsetY = helperTextHeight(const.FONT_DEFAULT)
	
	# button addresses
	buttonYSpacing = 50
	buttonContinueGameY = titleY               + buttonYSpacing
	buttonNewGameY      = buttonContinueGameY  + buttonYSpacing
	buttonQuitGameY     = buttonNewGameY       + buttonYSpacing
	buttonOptionsMenuY  = buttonQuitGameY      + buttonYSpacing

	# credits text
	creditsText = ["Music by Jukedeck - create your own at http://jukedeck.com"]
	creditsText.append("")
	creditsText.append("Graphics courtesy of DragonDePlatino and DawnBringer")
	creditsText.append("https://opengameart.org/content/dawnlike-16x16-universal-rogue-like-tileset-v181")
	creditsText.append("")
	creditsText.append("Special thanks to Michael Coates")

	creditsX = const.DISPLAY_WIDTH // 2
	creditsYOffset = helperTextHeight(const.FONT_DEFAULT)
	creditsY = const.DISPLAY_HEIGHT - creditsYOffset * (len(creditsText) + 1)

	# create buttons
	buttonContinueGame = uiButton(SURFACE_MAIN, "Continue Game", (150, 35),
		(titleX, buttonContinueGameY))

	buttonNewGame = uiButton(SURFACE_MAIN, "New Game", (150, 35),
		(titleX, buttonNewGameY))

	buttonQuitGame = uiButton(SURFACE_MAIN, "Quit Game", (150, 35),
		(titleX, buttonQuitGameY))

	buttonOptionsMenu = uiButton(SURFACE_MAIN, "Options Menu", (150, 35),
		(titleX, buttonOptionsMenuY))

	pygame.mixer.music.load(ASSETS.MUSIC_BG1)
	pygame.mixer.music.play()

	while True:

		# draw menu
		SURFACE_MAIN.blit(ASSETS.MAIN_MENU_BG, (0,0))

		drawText(SURFACE_MAIN, titleText, (titleX, titleY),
			textFont = const.FONT_TITLE,
			textColor = const.COLOR_MESSAGE_DEFAULT,
			center = True)

		for i, line in enumerate(creditsText):
			drawText(SURFACE_MAIN, line, (creditsX, creditsY + i * creditsYOffset),
				textFont = const.FONT_DEFAULT,
				textColor = const.COLOR_MESSAGE_DEFAULT,
				center = True)

		eventList = pygame.event.get()
		mousePos = pygame.mouse.get_pos()

		menuInput = (eventList, mousePos)

		# button updates
		if buttonContinueGame.update(menuInput):
			pygame.mixer.music.stop()
			
			gameInit()
			
			# try to load saved game; start a new game if exception occurs
			try:
				gameLoad()
			except:
				if const.DEBUG:
					print("Load Failed")
				gameNew()
			gameMainLoop()

		if buttonNewGame.update(menuInput):
			pygame.mixer.music.stop()
			# start a new game
			gameNew()
			gameMainLoop()

		if buttonQuitGame.update(menuInput):
			pygame.mixer.music.stop()

			gameInit()

			# quit the game
			gameExit()

		if buttonOptionsMenu.update(menuInput):
			menuOptions()

		buttonContinueGame.draw()
		buttonNewGame.draw()
		buttonQuitGame.draw()
		buttonOptionsMenu.draw()

		# update surface
		pygame.display.update()

####

def menuOptions():

	'''

	'''

	optionsMenuWidth = const.DISPLAY_WIDTH // 2
	optionsMenuHeight = const.DISPLAY_HEIGHT // 2

	windowCenter = (const.DISPLAY_WIDTH * 2 // 3, const.DISPLAY_HEIGHT // 2)

	optionsMenuBGColor = const.COLOR_BLUE

	optionsMenuSurface = pygame.Surface((optionsMenuWidth, optionsMenuHeight))

	optionsMenuRect = pygame.Rect(0, 0, optionsMenuWidth, optionsMenuHeight)
	optionsMenuRect.center = windowCenter

	optionsMenuTitle = "Options Menu"
	effectsVolLabel  = "Effect Volume"
	musicVolLabel    = "Music Volume"

	sliderWidth = optionsMenuWidth * 3 // 4
	sliderHeight = optionsMenuHeight // 10

	sliderYOffset = optionsMenuHeight // 4

	optionsCenterX = windowCenter[0]

	optionsTitleY = windowCenter[1] - sliderYOffset * 1.5
	effectsVolY   = optionsTitleY   + sliderYOffset
	musicVolY     = effectsVolY     + sliderYOffset
	saveButtonY   = musicVolY       + sliderYOffset

	optionsMenuSurface.fill(optionsMenuBGColor)
	SURFACE_MAIN.blit(optionsMenuSurface, optionsMenuRect.topleft)

	
	drawText(SURFACE_MAIN, optionsMenuTitle, (optionsCenterX, optionsTitleY),
		textFont = const.FONT_TITLE,
		textColor = const.COLOR_MESSAGE_DEFAULT,
		center = True)

	sliderEffectsVol = uiSlider(SURFACE_MAIN, (sliderWidth, sliderHeight),
		(optionsCenterX, effectsVolY),
		labelText = effectsVolLabel,
		parameterValue = PREFERENCES._volumeSound,
		labelAbove = False,
		showPercent = True)

	sliderMusicVol = uiSlider(SURFACE_MAIN, (sliderWidth, sliderHeight),
		(optionsCenterX, musicVolY),
		labelText = musicVolLabel,
		parameterValue = PREFERENCES._volumeMusic,
		labelAbove = False,
		showPercent = True)

	buttonSavePref = uiButton(SURFACE_MAIN, "Save Preferences",
		(sliderWidth // 3, sliderHeight),
		(optionsCenterX, saveButtonY),
		colorBoxDefault = const.COLOR_PURPLE,
		colorBoxMouseover = const.COLOR_GREEN,
		colorTextDefault = const.COLOR_GREEN,
		colorTextMouseover = const.COLOR_PURPLE)

	currentVolumeSound = PREFERENCES._volumeSound
	currentVolumeMusic = PREFERENCES._volumeMusic

	while True:

		eventList = pygame.event.get()
		mousePos = pygame.mouse.get_pos()

		menuInput = (eventList, mousePos)

		for event in eventList:
			if event.type == pygame.QUIT:
				pygame.quit()
				exit()

			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					return


		currentVolumeSound = sliderEffectsVol.update(menuInput)
		currentVolumeMusic = sliderMusicVol.update(menuInput)

		if buttonSavePref.update(menuInput):
			prefSave()
			return

		if currentVolumeSound != PREFERENCES._volumeSound:
			PREFERENCES._volumeSound = currentVolumeSound
			ASSETS.volumeAdjust()
			hitSound = ASSETS.SFX_HIT_LIST[doryen.random_get_int(0, 0, len(ASSETS.SFX_HIT_LIST) - 1)]
			pygame.mixer.Sound.play(hitSound)

		if currentVolumeMusic != PREFERENCES._volumeMusic:
			PREFERENCES._volumeMusic = currentVolumeMusic
			ASSETS.volumeAdjust()

		sliderEffectsVol.draw()
		sliderMusicVol.draw()
		buttonSavePref.draw()

		pygame.display.update()

####

def prefSave():

	'''

	'''
	with gzip.open('SaveData/preferences', 'wb') as file:
		pickle.dump([PREFERENCES._volumeSound, PREFERENCES._volumeMusic], file)

	return

####

def prefLoad():

	'''

	'''

	try:
		with gzip.open('SaveData/preferences', 'rb') as file:
			volumeSound, volumeMusic = pickle.load(file)

	except:
		volumeSound = .5
		volumeMusic = .5

	return volumeSound, volumeMusic

####

def menuHelp():

	'''
	help screen
	'''

	menuFont = const.FONT_DEFAULT

	yOffset = helperTextHeight(menuFont)

	menuWidth = const.DISPLAY_WIDTH // 2
	menuHeight = const.DISPLAY_HEIGHT // 2
	menuSurface = pygame.Surface((menuWidth, menuHeight))

	centerX = const.DISPLAY_WIDTH // 2
	centerY = const.DISPLAY_HEIGHT // 2
	menuCenter = (centerX, centerY)

	menuSurface = pygame.Surface((menuWidth, menuHeight))
	menuSurface.fill(const.COLOR_BLUE)

	menuRect = pygame.Rect((0, 0), (menuWidth, menuHeight))
	menuRect.center = menuCenter

	SURFACE_MAIN.blit(menuSurface, menuRect.topleft)


	menuTextX = centerX
	menuTextY = centerY - menuHeight // 2 + yOffset

	menuTextString = ["Help Menu"]
	menuTextString.append("")
	menuTextString.append("Use arrow keys to move and attack")
	menuTextString.append("SPACE to wait")
	menuTextString.append("'G' to pick up items")
	menuTextString.append("'I' to open/close inventory")
	menuTextString.append("Left-click inventory items to use/equip them")
	menuTextString.append("Right-click inventory items to drop them")
	menuTextString.append("Inventory can hold a maximum of " + str(const.PLAYER_INVENTORY_MAX) + " items")
	menuTextString.append("Using a scroll will open a targetting menu")
	menuTextString.append("Equipping weapons and shields will make you stronger")
	menuTextString.append("")
	menuTextString.append("'Z' to use stairs")
	menuTextString.append("'P' to open the pause/quit menu")
	menuTextString.append("'H' to open/close this menu")
	menuTextString.append("")
	menuTextString.append("Kill flies then pick them up and eat them to recover health")
	menuTextString.append("Find the Amulet of Power and escape the dungeon to win")
	menuTextString.append("")
	menuTextString.append("(ESC will close most windows/menus)")

	for i, line in enumerate(menuTextString):
		drawText(SURFACE_MAIN, menuTextString[i],
			(menuTextX, menuTextY + yOffset * i),
			menuFont, const.COLOR_WHITE, center = True)
	
	pygame.display.update()

	while True:
		# tick the clock to avoid animation errors while paused
		CLOCK.tick(const.GAME_FPS)

		eventList = pygame.event.get()
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_h or (event.key == pygame.K_ESCAPE):
					return

####

def menuPause():

	'''
	pause / quit menu
	'''

	menuFont = const.FONT_DEFAULT

	yOffset = helperTextHeight(menuFont)

	menuWidth = const.DISPLAY_WIDTH // 3
	menuHeight = const.DISPLAY_HEIGHT // 8
	menuSurface = pygame.Surface((menuWidth, menuHeight))

	centerX = const.DISPLAY_WIDTH // 2
	centerY = const.DISPLAY_HEIGHT // 2
	menuCenter = (centerX, centerY)

	menuSurface = pygame.Surface((menuWidth, menuHeight))
	menuSurface.fill(const.COLOR_BLUE)

	menuRect = pygame.Rect((0, 0), (menuWidth, menuHeight))
	menuRect.center = menuCenter

	SURFACE_MAIN.blit(menuSurface, menuRect.topleft)

	menuTextX = centerX
	menuTextY = centerY - menuHeight // 2 + yOffset

	menuTextString = ["PAUSED"]
	menuTextString.append("")
	menuTextString.append("Press 'P' or ESCAPE to resume game")
	menuTextString.append("Press 'Q' to save and return to the main menu")

	for i, line in enumerate(menuTextString):
		drawText(SURFACE_MAIN, menuTextString[i],
			(menuTextX, menuTextY + yOffset * i),
			menuFont, const.COLOR_WHITE, center = True)
	
	pygame.display.update()

	while True:
		# tick the clock to avoid animation errors while paused
		CLOCK.tick(const.GAME_FPS)

		eventList = pygame.event.get()
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_p or event.key == pygame.K_ESCAPE:
					return "no-action"
				if event.key == pygame.K_q:
					gameSave()
					return "main-menu"


####

def menuInventory():

	'''
	displays the player's inventory
	'''

	menuFont = const.FONT_MESSAGE
	menuTextWidth = helperTextWidth(menuFont)
	menuTextHeight = helperTextHeight(menuFont)

	menuHeight = 200
	menuWidth  = 200

	menuXPos = const.CAMERA_WIDTH/2 - menuWidth/2
	menuYPos = const.CAMERA_HEIGHT/2 - menuHeight/2

	menuSurface = pygame.Surface((menuWidth, menuHeight))

	while True:
		# populate the inventory list
		menuList = [obj._displayName for obj in PLAYER.container._inventory]

		# clear menu
		menuSurface.fill(const.COLOR_BLUE)

		# register changes
		eventList = pygame.event.get()

		mouseX, mouseY = pygame.mouse.get_pos()
		mouseMenuX = mouseX - menuXPos
		mouseMenuY = mouseY - menuYPos

		mouseInWindow = ((mouseMenuX in range(0, menuWidth)) and
						(mouseMenuY in range(0, menuHeight)))

		mouseMenuLine = -1
		if mouseInWindow:
			mouseMenuLine = mouseMenuY // menuTextHeight

		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if (event.key == pygame.K_i) or (event.key == pygame.K_ESCAPE):
					return
			if event.type == pygame.MOUSEBUTTONDOWN:
				if ((event.button == 1) and
					mouseInWindow and
					(mouseMenuLine < len(menuList))):
					# mouse button 1 to use selected item
					clickedItem = PLAYER.container._inventory[mouseMenuLine]
					closeMenu = True  # close menu after using item?
					if clickedItem.equipment:
						closeMenu = False  # close menu after equipping/unequipping item?
					clickedItem.item.use()
					if closeMenu:
						return
				if ((event.button == 3) and
					mouseInWindow and
					(mouseMenuLine < len(menuList))):
					# mouse button 2 to drop selected item
					PLAYER.container._inventory[mouseMenuLine].item.drop(PLAYER._x, PLAYER._y)

		# draw the menuList
		line = 0
		for inventoryItem in menuList:
			inventoryItem = " " + inventoryItem + " "
			if line == mouseMenuLine:
				highlight = const.COLOR_PURPLE
			else:
				highlight = None
			drawText(menuSurface, inventoryItem, (0, line * menuTextHeight),
				menuFont, const.COLOR_WHITE, highlight)
			line += 1

		# tick the clock
		CLOCK.tick(const.GAME_FPS)

		# draw the game
		drawGame()

		# display menu
		SURFACE_MAIN.blit(menuSurface, (menuXPos, menuYPos))

		# refresh the display
		pygame.display.update()

####

def menuTargetSelect(originCoords = None,
	maxRange = None,
	line = False,
	passWall = True,
	passCreature = True,
	radius = None):

	'''
	The player selects a tile to target.

	Pauses the game, produces an onscreen rectangle controlled by the mouse, when the LMB is clicked,
	returns the map coordinates.

	'''

	if originCoords == None:
		originCoords = (PLAYER._x, PLAYER._y)

	while True:
		# get mouse pos
		(mouseX, mouseY) = pygame.mouse.get_pos()
		
		mapPixelX, mapPixelY = CAMERA.windowToMap((mouseX, mouseY))

		mouseMapX = mapPixelX / const.TILE_WIDTH
		mouseMapY = mapPixelY / const.TILE_HEIGHT

		# get button click
		eventList = pygame.event.get()

		tileList = [(mouseMapX, mouseMapY)]

		if originCoords:
			tileList = mapFindLine(originCoords, (mouseMapX, mouseMapY))

		# stop at max range?
		if maxRange and (maxRange < len(tileList)):
			del tileList[maxRange:]

		if not line:
			tileList = [tileList[-1]]

		if (len(tileList) > 1):
			for i, (x,y) in enumerate(tileList):
				# stop at wall?
				if (not passWall) and GAME._mapCurrent[x][y]._impassable:
					del tileList[i:]
					break
				# stop at creature?
				if (not passCreature) and mapCheckForCreature(x, y) and (i < len(tileList)):
					del tileList[i+1:]
					break

		# return map coords when LMB is clicked
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					return None
			if event.type == pygame.MOUSEBUTTONDOWN:
				if (event.button == 1):
					# mouse button 1 to use select a tile to target, returns map tile coords
					if len(tileList) < 1:
						tileList = [(mouseMapX, mouseMapY)]
					return tileList[-1]

		# draw game objects
		drawGameObjects()

		# draw targetting line to mouse pos
		for mapCoords in tileList:
			if mapCoords == tileList[-1]:
				drawTarget(mapCoords, mark = "x")
			else:
				drawTarget(mapCoords)

		# draw radius, if any
		if radius:
			if tileList == []:
				tileList = [(PLAYER._x, PLAYER._y)]
			areaOfEffect = mapFindRadius(tileList[-1], radius)
			for (mapCoords) in areaOfEffect:
				drawTarget(mapCoords, tileColor = const.COLOR_RED)

		SURFACE_MAIN.blit(SURFACE_MAP, (0, 0), CAMERA.rectangle)

		if const.DEBUG:
			drawDebug()
	
		drawMessages()

		# update display
		pygame.display.update()

		# tick the clock
		CLOCK.tick(const.GAME_FPS)


#######################################################################################################
#  ____________  ___  _    _ 
#  |  _  \ ___ \/ _ \| |  | |
#  | | | | |_/ / /_\ \ |  | |
#  | | | |    /|  _  | |/\| |
#  | |/ /| |\ \| | | \  /\  /
#  |___/ \_| \_\_| |_/\/  \/
#
#######################################################################################################

def drawGame():

	'''
	draws the game on the main surface
	'''

	drawGameObjects()

	SURFACE_MAIN.blit(SURFACE_MAP, (0, 0), CAMERA.rectangle)

	if const.DEBUG:
		drawDebug()
	
	drawPlayerStats()
	drawMiniMap(GAME._mapCurrent)
	drawMessages()

####

def drawGameObjects():

	# clear surface
	SURFACE_MAIN.fill(const.COLOR_BACKGROUND_DEFAULT)
	SURFACE_MAP.fill(const.COLOR_BACKGROUND_DEFAULT)

	CAMERA.update()

	# draw the map
	drawMap(GAME._mapCurrent)

	# sort object list for depth
	GAME._objectsCurrent.sort(key=lambda x: x._depth, reverse=True)

	# draw all objects
	for obj in GAME._objectsCurrent:
			obj.draw()

####

def drawMap(map):

	'''
	draws the map
	'''

	global LOS_MAP

	camX, camY = CAMERA.mapAddress

	renderX1 = max((camX - const.CAMERA_RANGE), 0)
	renderX2 = min((camX + const.CAMERA_RANGE) + 1, const.MAP_WIDTH)
	renderY1 = max((camY - const.CAMERA_RANGE), 0)
	renderY2 = min((camY + const.CAMERA_RANGE) + 1, const.MAP_HEIGHT)

	# cycle through map cells and draw a wall or a floor tile
	for y in range(renderY1, renderY2):
		for x in range(renderX1, renderX2):

			if doryen.map_is_in_fov(LOS_MAP, x, y):

				map[x][y]._explored = True

				if map[x][y]._impassable == True:
					# draw wall
					SURFACE_MAP.blit(ASSETS.SPR_WALL, (x * const.TILE_WIDTH, y * const.TILE_HEIGHT))
				else:
					# draw floor
					SURFACE_MAP.blit(ASSETS.SPR_FLOOR, (x * const.TILE_WIDTH, y * const.TILE_HEIGHT))

			elif map[x][y]._explored:
				if map[x][y]._impassable == True:
					# draw unlit wall
					SURFACE_MAP.blit(ASSETS.SPR_WALL_DARK, (x * const.TILE_WIDTH, y * const.TILE_HEIGHT))
				else:
					# draw unlit floor
					SURFACE_MAP.blit(ASSETS.SPR_FLOOR_DARK, (x * const.TILE_WIDTH, y * const.TILE_HEIGHT))

####

def drawMiniMap(map):

	'''
	draws the mini-map
	'''

	global LOS_MAP

	messageHeight = helperTextHeight(const.FONT_DEFAULT)

	xOffset = const.CAMERA_WIDTH
	yOffset = int(messageHeight * 3)

	# cycle through map cells and draw a wall or a floor tile
	for y in range(0, const.MAP_HEIGHT):
		for x in range(0, const.MAP_WIDTH):
			
			if doryen.map_is_in_fov(LOS_MAP, x, y):
				if map[x][y]._impassable == True:
					# draw mini wall
					SURFACE_MAIN.blit(ASSETS.SPR_MM_WALL,
						(x * const.MINI_TILE_WIDTH + xOffset, y * const.MINI_TILE_HEIGHT + yOffset))
				else:
					# draw mini floor
					SURFACE_MAIN.blit(ASSETS.SPR_MM_FLOOR,
						(x * const.MINI_TILE_WIDTH + xOffset, y * const.MINI_TILE_HEIGHT + yOffset))

			elif map[x][y]._explored:
				if map[x][y]._impassable == True:
					# draw mini wall dark
					SURFACE_MAIN.blit(ASSETS.SPR_MM_WALL_DARK,
						(x * const.MINI_TILE_WIDTH + xOffset, y * const.MINI_TILE_HEIGHT + yOffset))
				else:
					# draw mini floor dark
					SURFACE_MAIN.blit(ASSETS.SPR_MM_FLOOR_DARK,
						(x * const.MINI_TILE_WIDTH + xOffset, y * const.MINI_TILE_HEIGHT + yOffset))

####

def drawText(displaySurface, textToDisplay, tupCoords,
	textFont = const.FONT_MESSAGE,
	textColor = const.COLOR_MESSAGE_DEFAULT,
	backgroundColor = None,
	center = False):

	'''
	displays submitted text on the referenced surface
	'''

	textSurface, textRect = helperTextObjects(textToDisplay, textFont, textColor, backgroundColor)

	if center:
		textRect.center = tupCoords
	else:
		textRect.topleft = tupCoords

	displaySurface.blit(textSurface, textRect)

####

def drawDebug():

	'''
	draws debug messages (FPS)
	'''

	drawText(SURFACE_MAIN, "fps: " + str(int(CLOCK.get_fps())), (0, 0),
		const.FONT_DEFAULT, const.COLOR_WHITE, const.COLOR_BLACK)

####

def drawPlayerStats():

	'''
	draws the players stats
	'''

	x = const.CAMERA_WIDTH + const.MESSAGE_WIDTH // 2
	messageHeight = helperTextHeight(const.FONT_DEFAULT)

	# health
	message = " HP: " + str(PLAYER.creature._health) + " / " + str(PLAYER.creature._maxHealth) + " "
	# messageWidth = helperTextWidth(const.FONT_DEFAULT) * len(message)


	y = messageHeight // 2

	drawText(SURFACE_MAIN, message, (x, y),
		const.FONT_DEFAULT, const.COLOR_WHITE, const.COLOR_BLACK, center = True)

	# level and xp
	message = "Level: " + str(PLAYER.creature._levelCurrent) + "   "
	message += "XP: " + str(PLAYER.creature._xpCurrent) + " / " + str(PLAYER.creature._xpNextLevel)

	if PLAYER.creature._levelCurrent == const.PLAYER_LEVEL_MAX:
		message = "Level: MAX"

	if PLAYER.creature._levelCurrent > const.PLAYER_LEVEL_MAX:
		message = "Level: ERROR"

	y = int(messageHeight * 1.5)

	drawText(SURFACE_MAIN, message, (x, y),
		const.FONT_DEFAULT, const.COLOR_WHITE, const.COLOR_BLACK, center = True)

	# dungeon
	message = "Dungeon Floor: " + str(GAME._mapLevel)

	y = int(messageHeight * 2.5)

	drawText(SURFACE_MAIN, message, (x, y),
		const.FONT_DEFAULT, const.COLOR_WHITE, const.COLOR_BLACK, center = True)

####

def drawMessages():

	'''
	draws game messages
	'''

	textWidth = helperTextWidth(const.FONT_MESSAGE)
	textHeight = helperTextHeight(const.FONT_MESSAGE)

	numMessages = (const.DISPLAY_HEIGHT / textHeight) // 3

	if len(GAME._messageLog) < numMessages:
		textToDraw = GAME._messageLog
	else:
		textToDraw = GAME._messageLog[-(numMessages):]

	messageX = const.CAMERA_WIDTH + textWidth
	messageY = const.DISPLAY_HEIGHT * 2 // 3

	i = 0
	for message, color in textToDraw:
		drawText(SURFACE_MAIN, message, (messageX, messageY + i),
			const.FONT_MESSAGE, color, const.COLOR_BACKGROUND_DEFAULT)
		i += textHeight

####

def drawTarget(coords,
	tileColor = const.COLOR_WHITE,
	tileAlpha = 150,
	mark = None):

	'''

	'''

	mapX, mapY = coords
	mapX *= const.TILE_WIDTH
	mapY *= const.TILE_HEIGHT

	newSurface = pygame.Surface((const.TILE_WIDTH, const.TILE_HEIGHT))

	newSurface.fill(tileColor)
	newSurface.set_alpha(tileAlpha)

	if mark:
		drawText(newSurface, mark, (const.TILE_WIDTH/2, const.TILE_HEIGHT/2), const.FONT_CURSOR,
			const.COLOR_BLACK, center = True)

	SURFACE_MAP.blit(newSurface, (mapX, mapY))


#######################################################################################################
#   _____  _____ _   _  ___________  ___ _____ ___________  _____ 
#  |  __ \|  ___| \ | ||  ___| ___ \/ _ \_   _|  _  | ___ \/  ___|
#  | |  \/| |__ |  \| || |__ | |_/ / /_\ \| | | | | | |_/ /\ `--. 
#  | | __ |  __|| . ` ||  __||    /|  _  || | | | | |    /  `--. \
#  | |_\ \| |___| |\  || |___| |\ \| | | || | \ \_/ / |\ \ /\__/ /
#   \____/\____/\_| \_/\____/\_| \_\_| |_/\_/  \___/\_| \_|\____/
#
#######################################################################################################

## PLAYER ###

def genPlayer(coords):

	'''

	'''
	
	x, y = coords

	attack = const.PLAYER_BASE_ATTACK
	defense = const.PLAYER_BASE_DEFENSE
	hp = const.PLAYER_BASE_HP

	name = "Player"
	crType = "frog"

	animKey = "ANIM_FROG"

	creatureComp = compCreature(name, baseAttack = attack, baseDefense = defense, health = hp,
		deathFunction = deathPlayer, deathAnimKey = 'SPR_CORPSE_PLAYER')
	containerComp = compContainer()
	player = objActor(x, y, crType, animKey, creature = creatureComp, container = containerComp,
		depth = const.DEPTH_PLAYER, status = None)

	return player

## SPECIAL ##

def genStairs(coords,
	downwards = True):

	'''

	'''

	x, y = coords

	if downwards:
		animKey = "SPR_STAIRS_DOWN"
	else:
		animKey = "SPR_STAIRS_UP"

	stairsComp = compStairs(downwards)
	stairs = objActor(x, y, "stairs", animKey, stairs = stairsComp, depth = const.DEPTH_STAIRS)

	return stairs

####

def genWinPortal(coords):

	'''

	'''

	x, y = coords

	animKey = "SPR_WIN_PORTAL"

	stairsComp = compStairs()
	portal = objActor(x, y, "win_portal", animKey, stairs = stairsComp, depth = const.DEPTH_STAIRS)

	return portal

## ITEMS ##

def genItem(coords):

	'''

	'''

	randNum = doryen.random_get_int(0, 1, 100)

	if randNum <= 25:
		newItem = genScrollLightning(coords)
	elif randNum <= 50:
		newItem = genScrollFireball(coords)
	elif randNum <= 75:
		newItem = genScrollConfusion(coords)
	elif randNum <= 90:
		newItem = genWeaponSword(coords)
	else:
		newItem = genArmorShield(coords)

	GAME._objectsCurrent.append(newItem)

####

def genScrollLightning(coords):

	'''

	'''

	x, y = coords

	lvlMod = genLvlMod()

	damage = doryen.random_get_int(0, 2, 8) + lvlMod

	name = "Level " + str(lvlMod + 1) + " lightning scroll"

	animKey = "SPR_SCROLL_1"

	itemComp = compItem(useFunction = castLightning, useValue = damage)
	scroll  = objActor(x, y, name, animKey, item = itemComp, depth = const.DEPTH_ITEM)

	return scroll

####

def genScrollFireball(coords):

	'''

	'''

	x, y = coords

	lvlMod = genLvlMod()

	damage = doryen.random_get_int(0, 3, 7) + lvlMod

	name = "Level " + str(lvlMod + 1) + " fireball scroll"

	animKey = "SPR_SCROLL_2"

	itemComp = compItem(useFunction = castFireball, useValue = damage)
	scroll  = objActor(x, y, name, animKey, item = itemComp, depth = const.DEPTH_ITEM)

	return scroll

####

def genScrollConfusion(coords):

	'''

	'''

	x, y = coords

	lvlMod = genLvlMod()

	duration = doryen.random_get_int(0, 3, 6) + lvlMod

	name = "Level " + str(lvlMod + 1) + " confusion scroll"

	animKey = "SPR_SCROLL_3"

	itemComp = compItem(useFunction = castConfusion, useValue = duration)
	scroll  = objActor(x, y, name, animKey, item = itemComp, depth = const.DEPTH_ITEM)

	return scroll

####

def genWeaponSword(coords):

	'''

	'''

	x, y = coords

	randNum = doryen.random_get_int(0, 1, 4)

	attack = genLvlMod()

	if randNum == 1:
		attack += 1
	elif randNum == 2:
		attack += 2
	elif randNum == 3:
		attack += 2
	else:
		attack += 3

	name = "Cutlass +" + str(attack)

	animKey = "SPR_SWORD"

	equipmentComp = compEquipment(attackBonus = attack, slot = "main hand")
	sword = objActor(x, y, name, animKey, equipment = equipmentComp, depth = const.DEPTH_GEAR)

	return sword

####

def genArmorShield(coords):

	'''

	'''

	x, y = coords

	defense = int(genLvlMod() * 2 // 3)

	randNum = doryen.random_get_int(0, 1, 4)

	if randNum == 4:
		defense += 2
	else:
		defense += 1

	name = "Buckler +" + str(defense)

	animKey = "SPR_SHIELD"

	equipmentComp = compEquipment(defenseBonus = defense, slot = "off hand")
	shield = objActor(x, y, name, animKey, equipment = equipmentComp, depth = const.DEPTH_GEAR)

	return shield

####

def genAmulet(coords):

	'''

	'''

	x, y = coords

	name = "Amulet of Power"

	animKey = "SPR_AMULET"

	equipmentComp = compEquipment(defenseBonus = const.AMULET_DEFENSE, attackBonus = const.AMULET_ATTACK,
		slot = "neck")
	amulet = objActor(x, y, name, animKey, equipment = equipmentComp, depth = const.DEPTH_GEAR)

	return amulet

## ENEMIES ##

def genEnemy(coords):

	'''

	'''

	randNum = doryen.random_get_int(0, 1, 100)

	if randNum <= 33:
		newEnemy = genAquaticCrab(coords)
	elif randNum <= 66:
		newEnemy = genReptilePython(coords)
	else:
		newEnemy = genAvianRaven(coords)
	
	GAME._objectsCurrent.append(newEnemy)

####

def genAquaticCrab(coords):

	'''

	'''

	x, y = coords

	attack = doryen.random_get_int(0, 1, 3) + genLvlMod()
	defense = 1
	hp = doryen.random_get_int(0, 5, 10) + genLvlMod() + genLvlMod()

	xp = calcXPVal(attack, defense, hp)

	name = genName()

	animKey = "ANIM_CRAB"

	creatureComp = compCreature(name, baseAttack = attack, baseDefense = defense, health = hp,
		deathFunction = deathMonster, deathAnimKey = "SPR_CORPSE_BONES")
	aiComp = aiPursue()
	monster  = objActor(x, y, "crab", animKey, creature = creatureComp, ai = aiComp, item = None,
		xpVal = xp, depth = const.DEPTH_CREATURE)

	return monster

####

def genReptilePython(coords):

	'''

	'''

	x, y = coords

	attack = doryen.random_get_int(0, 3, 5) + genLvlMod()
	defense = 0
	hp = doryen.random_get_int(0, 4, 8) + genLvlMod() + genLvlMod()

	xp = calcXPVal(attack, defense, hp)

	name = genName()

	animKey = "ANIM_PYTHON"

	creatureComp = compCreature(name, baseAttack = attack, baseDefense = defense, health = hp,
		deathFunction = deathMonster, deathAnimKey = "SPR_CORPSE_BONES")
	aiComp = aiPursue()
	monster  = objActor(x, y, "python", animKey, creature = creatureComp, ai = aiComp, item = None,
		xpVal = xp, depth = const.DEPTH_CREATURE)

	return monster

####

def genAvianRaven(coords):

	'''

	'''

	x, y = coords

	attack = doryen.random_get_int(0, 2, 4) + genLvlMod()
	defense = 0
	hp = doryen.random_get_int(0, 5, 10) + genLvlMod() + genLvlMod()

	xp = calcXPVal(attack, defense, hp)

	name = genName()

	animKey = "ANIM_RAVEN"

	creatureComp = compCreature(name, baseAttack = attack, baseDefense = defense, health = hp,
		deathFunction = deathMonster, deathAnimKey = "SPR_CORPSE_BONES")
	aiComp = aiPursue()
	monster  = objActor(x, y, "raven", animKey, creature = creatureComp, ai = aiComp, item = None,
		xpVal = xp, depth = const.DEPTH_CREATURE)

	return monster

####

def genMiscTurtle(coords):

	'''

	'''

	x, y = coords

	attack = doryen.random_get_int(0, 3, 6) + doryen.random_get_int(0, 3, 6)
	defense = doryen.random_get_int(0, 1, 2) + doryen.random_get_int(0, 1, 2)
	hp = doryen.random_get_int(0, 5, 10) + doryen.random_get_int(0, 5, 10)

	xp = calcXPVal(attack, defense, hp) + const.BREAK_CHANCE

	name = "Ur'" + genName()

	animKey = "ANIM_TURTLE"

	creatureComp = compCreature(name, baseAttack = attack, baseDefense = defense, health = hp,
		deathFunction = deathMonster, deathAnimKey = "SPR_CORPSE_SKULL")
	aiComp = aiPursue()
	monster  = objActor(x, y, "turtle", animKey, creature = creatureComp, ai = aiComp, item = None,
		xpVal = xp, depth = const.DEPTH_CREATURE)

	return monster

####

def genPestFly(coords):

	'''

	'''

	x, y = coords

	attack = 0
	defense = 0
	hp = 1

	healVal = doryen.random_get_int(0, 1, 3) + doryen.random_get_int(0, 1, 3)

	name = "buzzy"

	animKey = "ANIM_FLY"

	creatureComp = compCreature(name, baseAttack = attack, baseDefense = defense, health = hp,
		deathFunction = deathFly, deathAnimKey = "SPR_CORPSE_FLY")
	aiComp = aiFly()
	itemComp = compItem(useFunction = castHeal, useValue = healVal)
	fly  = objActor(x, y, "fly", animKey, creature = creatureComp, ai = aiComp, item = itemComp,
		xpVal = 1, depth = const.DEPTH_FLY)

	return fly

####

def genLvlMod():

	'''

	'''

	lvlModMin = GAME._mapLevel // 3
	lvlModMax = GAME._mapLevel // 2
	lvlMod = doryen.random_get_int(0, lvlModMin, lvlModMax)

	return lvlMod

####

def calcXPVal(attack, defense, health):

	return attack * 2 + defense * 3 + health

## NAMES ##

def nameInit():
    global ACCENT, VOWELS, CONSONANTS, SYLLABLES
    ACCENT = [" ", "'", "-"]
    VOWELS = ["a", "e", "i", "o", "u", "y"]
    CONSONANTS = ["b", "c", "d", "f", "g", "h", "j", "k", "l", "m", "n",
                  "p", "q", "r", "s", "t", "v", "w", "x", "y", "z"]
    SYLLABLES = []

    for letter1 in VOWELS:
        for letter2 in VOWELS:
            if not ("yy" in (letter1 + letter2)):
                SYLLABLES.append(letter1.upper() + letter2)

    for letter1 in VOWELS:
        for letter2 in CONSONANTS:
            if not ("yy" in (letter1 + letter2)):
                SYLLABLES.append(letter1.upper() + letter2)

    for letter1 in CONSONANTS:
        for letter2 in VOWELS:
            if not ("yy" in (letter1 + letter2)):
                SYLLABLES.append(letter1.upper() + letter2)

    for letter1 in VOWELS:
        for letter2 in VOWELS:
            for letter3 in CONSONANTS:
                if not ("yy" in (letter1 + letter2 + letter3)):
                    SYLLABLES.append(letter1.upper() + letter2 + letter3)

    for letter1 in VOWELS:
        for letter2 in CONSONANTS:
            for letter3 in VOWELS:
                if not ("yy" in (letter1 + letter2 + letter3)):
                    SYLLABLES.append(letter1.upper() + letter2 + letter3)

    for letter1 in VOWELS:
        for letter2 in CONSONANTS:
            for letter3 in CONSONANTS:
                if not ("yy" in (letter1 + letter2 + letter3)):
                    SYLLABLES.append(letter1.upper() + letter2 + letter3)

    for letter1 in CONSONANTS:
        for letter2 in VOWELS:
            for letter3 in VOWELS:
                if not ("yy" in (letter1 + letter2 + letter3)):
                    SYLLABLES.append(letter1.upper() + letter2 + letter3)

    for letter1 in CONSONANTS:
        for letter2 in VOWELS:
            for letter3 in CONSONANTS:
                if not ("yy" in (letter1 + letter2 + letter3)):
                    SYLLABLES.append(letter1.upper() + letter2 + letter3)

    for letter1 in CONSONANTS:
        for letter2 in CONSONANTS:
            for letter3 in VOWELS:
                if not ("yy" in (letter1 + letter2 + letter3)):
                    SYLLABLES.append(letter1.upper() + letter2 + letter3)

####

def genName():

    '''
    The name generator.

    returns:  string (representing the random name)
    '''

    name = SYLLABLES[doryen.random_get_int(0, 0, len(SYLLABLES) -1)]
    
    if doryen.random_get_int(0, 1, 100) <= 10:
        name += ACCENT[doryen.random_get_int(0, 0, len(ACCENT) -1)]
        
    if doryen.random_get_int(0, 1, 100) <= 50:
        syllable = SYLLABLES[doryen.random_get_int(0, 0, len(SYLLABLES) -1)]

        checkThis = (name[-2:] + syllable[:2])
        while threeSame(checkThis):
            syllable = SYLLABLES[doryen.random_get_int(0, 0, len(SYLLABLES) -1)]
            checkThis = (name[-2:] + syllable[:2])
            
        if (name[-1] not in ACCENT) and (doryen.random_get_int(0, 1, 100) <= 90):
            syllable = syllable.lower()

        name += syllable
        
        if doryen.random_get_int(0, 1, 100) <= 10:
            name += ACCENT[doryen.random_get_int(0, 0, len(ACCENT) -1)]
            
    syllable = SYLLABLES[doryen.random_get_int(0, 0, len(SYLLABLES) -1)]
    
    checkThis = (name[-2:] + syllable[:2])
    while threeSame(checkThis):
        syllable = SYLLABLES[doryen.random_get_int(0, 0, len(SYLLABLES) -1)]
        checkThis = (name[-2:] + syllable[:2])
        
    if (name[-1] not in ACCENT) and (doryen.random_get_int(0, 1, 100) <= 90):
        syllable = syllable.lower()

    name += syllable

    return name

####

def threeSame(stringToCheck):
    '''
    checks for all vowels or all consonants
    '''
    if threeConsonants(stringToCheck) or threeVowels(stringToCheck):
        return True
    return False

####

def threeConsonants(stringToCheck):
    '''
    checks the string to see if it contains 3 consecutive consonants
    '''
    stringToCheck = stringToCheck.lower()
    counter = 0
    flag = False
    for letter in stringToCheck:
        if (letter in CONSONANTS) and (letter != 'y'):
            counter += 1
            if counter > 2:
                flag = True
        else:
            counter = 0
    return flag

####

def threeVowels(stringToCheck):
    '''
    checks the string to see if it contains 3 consecutive vowels
    '''
    stringToCheck = stringToCheck.lower()
    counter = 0
    flag = False
    for letter in stringToCheck:
        if (letter in VOWELS) and (letter != 'y'):
            counter += 1
            if counter > 2:
                flag = True
        else:
            counter = 0
    return flag

####

def genLegacyFile():

	'''

	'''

	fileName = "legacy_files/" + PLAYER.creature._nameInstance + "_legacy."
	fileName += datetime.date.today().strftime("%Y_%B_%d")

	legacyFile = open(fileName, 'a+')

	legacyFile.write("########## a new story begins ##########\n")	

	for message, color in GAME._messageLog:
		legacyFile.write(message + "\n")

	playerString = PLAYER._displayName + " (level " + str(PLAYER.creature._levelCurrent) + ")"
	dateString = datetime.date.today().strftime("%d %B, %Y")
	dungeonLevelString = str(GAME._mapLevel)
	legacyFile.write("\nR.I.P. " + playerString + "\n")
	legacyFile.write("... Died on dungeon level " + dungeonLevelString + "\n")
	legacyFile.write("... On " + dateString + "\n")
	legacyFile.write("############# end of story #############\n\n")

####

def genVictoryFile():

	'''

	'''

	fileName = "legacy_files/" + PLAYER.creature._nameInstance + "_victory."
	fileName += datetime.date.today().strftime("%Y_%B_%d")

	victoryFile = open(fileName, 'a+')

	victoryFile.write("########## a new story begins ##########\n")	

	for message, color in GAME._messageLog:
		victoryFile.write(message + "\n")

	playerString = PLAYER._displayName + " (level " + str(PLAYER.creature._levelCurrent) + ")"
	dateString = datetime.date.today().strftime("%d %B, %Y")
	victoryFile.write("\n" + playerString + "\n")
	victoryFile.write("defeated the dungeon on " + dateString + "\n")
	victoryFile.write("############# end of story #############\n\n")


#######################################################################################################
#   _   _  _____ _     ______ ___________  _____ 
#  | | | ||  ___| |    | ___ \  ___| ___ \/  ___|
#  | |_| || |__ | |    | |_/ / |__ | |_/ /\ `--. 
#  |  _  ||  __|| |    |  __/|  __||    /  `--. \
#  | | | || |___| |____| |   | |___| |\ \ /\__/ /
#  \_| |_/\____/\_____/\_|   \____/\_| \_|\____/
#
#######################################################################################################

def helperTextObjects(incText, incFont, incColor, incBackground):

	'''
	returns a text surface and rectangle
	'''

	if incBackground:
		surface = incFont.render(incText, False, incColor, incBackground)
	else:
		surface = incFont.render(incText, False, incColor)

	return surface, surface.get_rect()

####

def helperTextHeight(font):
	 
	'''
	returns the height (in pixels) of the submitted font
	'''

	fontObj = font.render('a', False, (0, 0, 0))
	fontRect = fontObj.get_rect()

	return fontRect.height

####

def helperTextWidth(font):

	'''
	returns the width (in pixels) of the submitted font
	'''

	fontObj = font.render('a', False, (0, 0, 0))
	fontRect = fontObj.get_rect()

	return fontRect.width


#######################################################################################################
#  ___  ___  ___  ______ 
#  |  \/  | / _ \ | ___ \
#  | .  . |/ /_\ \| |_/ /
#  | |\/| ||  _  ||  __/
#  | |  | || | | || |   
#  \_|  |_/\_| |_/\_|
#
#######################################################################################################

def mapMake():

	'''
	makes and returns a map as a 2-dimensional list (x and y coords)
	'''

	# create a blank map
	newMap = [[structTile(True) for y in range(const.MAP_HEIGHT)] for x in range(const.MAP_WIDTH)]

	roomList = []

	# make rooms
	for i in range(const.MAP_MAX_ROOMS):
	
		w = doryen.random_get_int(0, const.ROOM_MIN_WIDTH, const.ROOM_MAX_WIDTH)
		h = doryen.random_get_int(0, const.ROOM_MIN_HEIGHT, const.ROOM_MAX_HEIGHT)

		x = doryen.random_get_int(0, 1, const.MAP_WIDTH - 2 - w)
		y = doryen.random_get_int(0, 1, const.MAP_HEIGHT - 2 - h)
	
		newRoom = objRoom((x, y), (w, h))

		# check for room overlap
		validRoom = True

		for otherRoom in roomList:
			if newRoom.overlap(otherRoom):
				validRoom = False
				break

		# place room
		if validRoom:
			# open room tiles on map
			newMap = mapDigRoom(newMap, newRoom)

			# tunnel to previous room
			if len(roomList) > 0:
				newMap = mapDigTunnel(newMap, newRoom, roomList[-1])

			roomList.append(newRoom)

	# create LOS_MAP
	mapMakeLOS(newMap)

	# debug trace
	if const.DEBUG:
		mapPrint(newMap)

	# return map
	return (newMap, roomList)

####

def mapPrint(mapList):

	'''

	'''
	
	mapImage = []

	index = 0
	for y in range(const.MAP_HEIGHT):
		mapImage.append("")
		for x in range(const.MAP_WIDTH):
			if mapList[x][y]._impassable:
				mapImage[index] += "##"
			else:
				mapImage[index] += ("  ")
		index += 1

	if const.DEBUG:
		print("map trace")
		for line in mapImage:
			print(line)
		print("")

####

def mapDigRoom(mapList, room):

	'''

	'''

	for y in range(room._y1, room._y2):
		for x in range(room._x1, room._x2):
			mapList[x][y]._impassable = False	

	return mapList

####

def mapDigTunnel(mapList, room1, room2):

	'''

	'''

	x1, y1 = room1._center
	x2, y2 = room2._center

	xStep, yStep = 1, 1

	if x1 > x2:
		xStep = -1

	if y1 > y2:
		yStep = -1

	stopDigging = False

	coinFlip = doryen.random_get_int(0, 0, 1)

	if coinFlip == 0:
		for tunnelX in range(x1, (x2 + xStep), xStep):
			if mapList[tunnelX][y1]._impassable:
				stopDigging = True
				mapList[tunnelX][y1]._impassable = False
			elif (mapList[tunnelX][y1]._impassable == False) and stopDigging:
				return mapList

		stopDigging = False

		for tunnelY in range(y1, (y2 + yStep), yStep):
			if mapList[x2][tunnelY]._impassable:
				stopDigging = True
				mapList[x2][tunnelY]._impassable = False
			elif (mapList[x2][tunnelY]._impassable == False) and stopDigging:
				return mapList

	else:
		for tunnelY in range(y1, (y2 + yStep), yStep):
			if mapList[x1][tunnelY]._impassable:
				stopDigging = True
				mapList[x1][tunnelY]._impassable = False
			elif (mapList[x1][tunnelY]._impassable == False) and stopDigging:
				return mapList

		stopDigging = False

		for tunnelX in range(x1, (x2 + xStep), xStep):
			if mapList[tunnelX][y2]._impassable:
				stopDigging = True
				mapList[tunnelX][y2]._impassable = False
			elif (mapList[tunnelX][y2]._impassable == False) and stopDigging:
				return mapList

	return mapList

####

def mapPopulate(roomList):

	'''

	'''
	# create player
	PLAYER._x, PLAYER._y = roomList[0]._center
	GAME._objectsCurrent.append(PLAYER)

	firstMap = (len(GAME._mapsPrevious) == 0)
	lastMap = (len(GAME._mapsPrevious) == (const.LAST_LEVEL - 1))

	# populate rooms
	for room in roomList:

		firstRoom = (room == roomList[0])
		lastRoom = (room == roomList[-1])

		if firstRoom and not firstMap:
			GAME._objectsCurrent.append(genStairs((PLAYER._x, PLAYER._y), downwards = False))

		if lastRoom and not lastMap:
			GAME._objectsCurrent.append(genStairs(room._center))

		if not firstRoom and (doryen.random_get_int(0, 1, 100) <= 70):
			x = doryen.random_get_int(0, room._x1, (room._x2 - 1))
			y = doryen.random_get_int(0, room._y1, (room._y2 - 1))
			genEnemy((x, y))

		if not firstRoom and (doryen.random_get_int(0, 1, 100) <= 35):
			x = doryen.random_get_int(0, room._x1, (room._x2 - 1))
			y = doryen.random_get_int(0, room._y1, (room._y2 - 1))
			genItem((x, y))

		if not firstRoom and (doryen.random_get_int(0, 1, 100) <= 50):
			x = doryen.random_get_int(0, room._x1, (room._x2 - 1))
			y = doryen.random_get_int(0, room._y1, (room._y2 - 1))
			GAME._objectsCurrent.append(genPestFly((x, y)))

		if lastRoom and lastMap:
			GAME._objectsCurrent.append(genAmulet(room._center))

	### debug trace ###
	if const.DEBUG:
		print("Debug Trace:")
		for obj in GAME._objectsCurrent:
			print(obj._displayName, "(" + str(obj._x) + ", " + str(obj._y) + ")")

####

def mapRePopulate():

	'''

	'''

	for map in GAME._mapsPrevious:

		firstMap = (map == GAME._mapsPrevious[0])
	
		roomList = map[3]
		for room in roomList:

			firstRoom = (room == roomList[0])

			if firstRoom and firstMap:
				map[-1].append(genWinPortal(room._center))

			elif doryen.random_get_int(0, 1, 100) <= 25:
				x = doryen.random_get_int(0, room._x1, (room._x2 - 1))
				y = doryen.random_get_int(0, room._y1, (room._y2 - 1))
				map[-1].append(genMiscTurtle((x, y)))

			if doryen.random_get_int(0, 1, 100) <= 25:
				x = doryen.random_get_int(0, room._x1, (room._x2 - 1))
				y = doryen.random_get_int(0, room._y1, (room._y2 - 1))
				map[-1].append(genPestFly((x, y)))

####

def mapCheckForCreature(xPos, yPos,
	excludeObj = None):

	'''
	checks the submitted (x, y) location for a creature other than the excluded one and returns that object
	'''

	for obj in GAME._objectsCurrent:
		if ((obj is not excludeObj) and
			(obj._x == xPos) and
			(obj._y == yPos) and
			(obj.creature)):
			return obj
	return None

####

def mapMakeLOS(incomingMap):

	'''

	'''

	global LOS_MAP

	LOS_MAP = doryen.map_new(const.MAP_WIDTH, const.MAP_HEIGHT)

	for y in range(const.MAP_HEIGHT):
		for x in range(const.MAP_WIDTH):
			doryen.map_set_properties(LOS_MAP, x, y,
				not incomingMap[x][y]._impassable,
				not incomingMap[x][y]._impassable)

####

def mapCalcLOS():

	'''

	'''

	global LOS_CALC

	if LOS_CALC:
		LOS_CALC = False
		doryen.map_compute_fov(LOS_MAP, PLAYER._x, PLAYER._y,
			const.LOS_LIGHT_RADIUS,
			const.LOS_LIGHT_WALLS,
			const.LOS_ALGO)

####

def mapObjectsAtLocation(xCoord, yCoord):

	'''

	'''

	objectList = [obj for obj in GAME._objectsCurrent if obj._x == xCoord and obj._y == yCoord]

	return objectList

####

def mapFindLine(coords1, coords2):
	
	'''
	Converts two sets of (x, y) map coords into a list of tiles that make up that line

	coords1 : (x1, y1)
	coords2 : (x2, y2)
	'''

	x1, y1 = coords1
	x2, y2 = coords2

	if (x1 == x2) and (y1 == y2):
		return [(x1, y1)]

	doryen.line_init(x1, y1, x2, y2)

	lineCoords = doryen.line_step()

	lineCoordsList = []

	while lineCoords != (None, None):
		lineCoordsList.append(lineCoords)
		lineCoords = doryen.line_step()

	return lineCoordsList

####

def mapFindRadius(coords, radius):

	'''

	'''

	centerX, centerY = coords

	startX = centerX - radius
	if startX < 0:
		startX = 0

	endX   = centerX + radius
	if endX > const.MAP_WIDTH:
		endX = const.MAP_WIDTH

	startY = centerY - radius
	if startY < 0:
		startY = 0

	endY   = centerY + radius
	if endY > const.MAP_HEIGHT:
		endY = const.MAP_HEIGHT

	radiusCoordsList = []

	for y in range(startY, endY + 1):
		for x in range (startX, endX + 1):
			radiusCoordsList.append((x, y))

	return radiusCoordsList


#######################################################################################################
#   _____ ___________ _   _ _____ _____ _   _______ _____ _____ 
#  /  ___|_   _| ___ \ | | /  __ \_   _| | | | ___ \  ___/  ___|
#  \ `--.  | | | |_/ / | | | /  \/ | | | | | | |_/ / |__ \ `--. 
#   `--. \ | | |    /| | | | |     | | | | | |    /|  __| `--. \
#  /\__/ / | | | |\ \| |_| | \__/\ | | | |_| | |\ \| |___/\__/ /
#  \____/  \_/ \_| \_|\___/ \____/ \_/  \___/\_| \_\____/\____/
#
#######################################################################################################

class structTile:

	'''
	map tiles
	'''

	def __init__(self, impassable):
		self._impassable = impassable
		self._explored = False

####

class structPreferences:

	def __init__(self):

		self._volumeSound, self._volumeMusic = prefLoad()


#######################################################################################################
#   ___________   ___ _____ _____ _____ _____ 
#  |  _  | ___ \ |_  |  ___/  __ \_   _/  ___|
#  | | | | |_/ /   | | |__ | /  \/ | | \ `--.
#  | | | | ___ \   | |  __|| |     | |  `--. \
#  \ \_/ / |_/ /\__/ / |___| \__/\ | | /\__/ /
#   \___/\____/\____/\____/ \____/ \_/ \____/ 
#
#######################################################################################################

class objAssets:
	
	'''
	game assets
	'''

	def __init__(self):

		self.masterSoundList = []

		self.loadAssets()
		self.volumeAdjust()


	def loadAssets(self):

		 #########
		##  ART  ##
		 #########

		graphicPath = "graphicAssets/"

		# sprite sheets
		self.reptileSpriteSheet  = objSpriteSheet(graphicPath + "Characters/Reptile.png")
		self.aquaticSpriteSheet  = objSpriteSheet(graphicPath + "Characters/Aquatic.png")
		self.avianSpriteSheet    = objSpriteSheet(graphicPath + "Characters/Avian.png")
		self.shortWepSpriteSheet = objSpriteSheet(graphicPath + "Items/ShortWep.png")
		self.shieldSpriteSheet   = objSpriteSheet(graphicPath + "Items/Shield.png")
		self.wallSpriteSheet     = objSpriteSheet(graphicPath + "Objects/Wall.png")
		self.floorSpriteSheet    = objSpriteSheet(graphicPath + "Objects/Floor.png")
		self.scrollSpriteSheet   = objSpriteSheet(graphicPath + "Items/Scroll.png")
		self.fleshSpriteSheet    = objSpriteSheet(graphicPath + "Items/Flesh.png")
		self.miscSpriteSheet     = objSpriteSheet(graphicPath + "Characters/Misc.png")
		self.decorSpriteSheet    = objSpriteSheet(graphicPath + "Objects/Decor.png")
		self.tileSpriteSheet     = objSpriteSheet(graphicPath + "Objects/Tile.png")
		self.pestSpriteSheet     = objSpriteSheet(graphicPath + "Characters/Pest.png")
		self.amuletSpriteSheet   = objSpriteSheet(graphicPath + "Items/Amulet.png")
		self.doorSpriteSheet    = objSpriteSheet(graphicPath + "Objects/Door.png")

		# creature animations
		self.ANIM_FROG   = self.aquaticSpriteSheet.getAnimation('c', 6, 16, 16, 2, (32, 32))
		self.ANIM_CRAB   = self.aquaticSpriteSheet.getAnimation('c', 1, 16, 16, 2, (32, 32))
		self.ANIM_PYTHON = self.reptileSpriteSheet.getAnimation('m', 5, 16, 16, 2, (32, 32))
		self.ANIM_RAVEN  = self.avianSpriteSheet.getAnimation('c', 2, 16, 16, 2, (32, 32))
		self.ANIM_TURTLE  = self.miscSpriteSheet.getAnimation('a', 8, 16, 16, 2, (32, 32))
		self.ANIM_FLY    = self.pestSpriteSheet.getAnimation('c', 2, 16, 16, 2, (32, 32))

		# map tiles
		self.SPR_FLOOR       = self.floorSpriteSheet.getImage('p', 8, 16, 16, (32, 32))
		self.SPR_FLOOR_DARK  = self.floorSpriteSheet.getImage('p', 14, 16, 16, (32, 32))
		self.SPR_WALL        = self.wallSpriteSheet.getImage('d', 7, 16, 16, (32, 32))
		self.SPR_WALL_DARK   = self.wallSpriteSheet.getImage('d', 13, 16, 16, (32, 32))

		# mini-map tiles
		self.SPR_MM_FLOOR       = self.floorSpriteSheet.getImage('p', 8, 16, 16, (8, 8))
		self.SPR_MM_FLOOR_DARK  = self.floorSpriteSheet.getImage('p', 14, 16, 16, (8, 8))
		self.SPR_MM_WALL        = self.wallSpriteSheet.getImage('d', 7, 16, 16, (8, 8))
		self.SPR_MM_WALL_DARK   = self.wallSpriteSheet.getImage('d', 13, 16, 16, (8, 8))

		# items
		self.SPR_SWORD    = self.shortWepSpriteSheet.getAnimation('b', 2, 16, 16, 1, (32, 32))
		self.SPR_SHIELD   = self.shieldSpriteSheet.getAnimation('a', 1, 16, 16, 1, (32, 32))
		self.SPR_SCROLL_1 = self.scrollSpriteSheet.getAnimation('e', 2, 16, 16, 1, (32, 32))
		self.SPR_SCROLL_2 = self.scrollSpriteSheet.getAnimation('c', 2, 16, 16, 1, (32, 32))
		self.SPR_SCROLL_3 = self.scrollSpriteSheet.getAnimation('g', 2, 16, 16, 1, (32, 32))
		self.SPR_AMULET   = self.amuletSpriteSheet.getAnimation('g', 1, 16, 16, 1, (32, 32))

		# special
		self.SPR_STAIRS_DOWN = self.tileSpriteSheet.getAnimation('b', 2, 16, 16, 1, (32, 32))
		self.SPR_STAIRS_UP   = self.tileSpriteSheet.getAnimation('a', 2, 16, 16, 1, (32, 32))
		self.SPR_WIN_PORTAL  = self.doorSpriteSheet.getAnimation('c', 6, 16, 16, 2, (32, 32))

		# title screen image
		self.MAIN_MENU_BG = pygame.image.load(graphicPath + "/Backgrounds/background1.jpg")
		self.MAIN_MENU_BG = pygame.transform.scale(self.MAIN_MENU_BG,
			(const.DISPLAY_WIDTH, const.DISPLAY_HEIGHT))

		# corpses
		self.SPR_CORPSE_RAVEN  = self.fleshSpriteSheet.getAnimation('a', 1, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_CRAB   = self.fleshSpriteSheet.getAnimation('d', 2, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_PYTHON = self.fleshSpriteSheet.getAnimation('h', 2, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_TURTLE  = self.fleshSpriteSheet.getAnimation('g', 1, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_FROG   = self.fleshSpriteSheet.getAnimation('d', 1, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_PLAYER = self.decorSpriteSheet.getAnimation('a', 18, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_SKULL  = self.decorSpriteSheet.getAnimation('a', 13, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_BONES  = self.decorSpriteSheet.getAnimation('g', 14, 16, 16, 1, (32, 32))
		self.SPR_CORPSE_FLY    = self.fleshSpriteSheet.getAnimation('a', 4, 16, 16, 1, (32, 32))

		# animation dictionary
		self.animDict = {

			# creature animations
			'ANIM_FROG'   : self.ANIM_FROG,
			'ANIM_CRAB'   : self.ANIM_CRAB,
			'ANIM_PYTHON' : self.ANIM_PYTHON,
			'ANIM_RAVEN'  : self.ANIM_RAVEN,
			'ANIM_TURTLE'  : self.ANIM_TURTLE,
			'ANIM_FLY'    : self.ANIM_FLY,

			# items
			'SPR_SWORD'      : self.SPR_SWORD,
			'SPR_SHIELD'     : self.SPR_SHIELD,
			'SPR_SCROLL_1'   : self.SPR_SCROLL_1,
			'SPR_SCROLL_2'   : self.SPR_SCROLL_2,
			'SPR_SCROLL_3'   : self.SPR_SCROLL_3,
			'SPR_AMULET'     : self.SPR_AMULET,

			# corpses
			'SPR_CORPSE_RAVEN'  : self.SPR_CORPSE_RAVEN,
			'SPR_CORPSE_CRAB'   : self.SPR_CORPSE_CRAB,
			'SPR_CORPSE_PYTHON' : self.SPR_CORPSE_PYTHON,
			'SPR_CORPSE_TURTLE'  : self.SPR_CORPSE_TURTLE,
			'SPR_CORPSE_FROG'   : self.SPR_CORPSE_FROG,
			'SPR_CORPSE_PLAYER' : self.SPR_CORPSE_PLAYER,
			'SPR_CORPSE_BONES'  : self.SPR_CORPSE_BONES,
			'SPR_CORPSE_SKULL'  : self.SPR_CORPSE_SKULL,
			'SPR_CORPSE_FLY'    : self.SPR_CORPSE_FLY,

			# special
			'SPR_STAIRS_DOWN' : self.SPR_STAIRS_DOWN,
			'SPR_STAIRS_UP'   : self.SPR_STAIRS_UP,
			'SPR_WIN_PORTAL'  : self.SPR_WIN_PORTAL
			
		}


		 ###########
		##  SOUND  ##
		 ###########

		musicPath = "soundAssets/Music/"
		sfxPath = "soundAssets/SFX/"

		self.MUSIC_BG1 = musicPath + "DangerousLife.mp3"
		self.MUSIC_BG2 = musicPath + "EpicExistence.mp3"

		self.SFX_HIT01 = self.soundAdd(sfxPath + "hit01.wav")
		self.SFX_HIT02 = self.soundAdd(sfxPath + "hit02.wav")
		self.SFX_HIT03 = self.soundAdd(sfxPath + "hit03.wav")
		self.SFX_HIT04 = self.soundAdd(sfxPath + "hit04.wav")
		self.SFX_HIT05 = self.soundAdd(sfxPath + "hit05.wav")
		self.SFX_HIT06 = self.soundAdd(sfxPath + "hit06.wav")

		self.SFX_HIT_LIST = [

			self.SFX_HIT01,
			self.SFX_HIT02,
			self.SFX_HIT03,
			self.SFX_HIT04,
			self.SFX_HIT05,
			self.SFX_HIT06

		]

	def soundAdd(self, fileAddress):

		'''

		'''

		newSound = pygame.mixer.Sound(fileAddress)

		self.masterSoundList.append(newSound)

		return newSound


	def volumeAdjust(self):
		 
		'''

		'''

		for sound in self.masterSoundList:
		 	sound.set_volume(PREFERENCES._volumeSound)

		pygame.mixer.music.set_volume(PREFERENCES._volumeMusic)

####

class objActor:

	'''
	any game element that can move/interact with other elements
	'''

	global LOS_MAP

	def __init__(self, x, y, nameObject, animationKey,
		animationDuration = 1.0,
		xpVal = 0,
		depth = 0,
		status = None,

		creature = None,
		ai = None,
		container = None,
		item = None,
		equipment = None,
		stairs = None):

		# map address
		self._x = x
		self._y = y

		self._xpValue = xpVal
		self._depth = depth
		self._status = status

		self._nameObject = nameObject

		# sprite
		self._animationKey = animationKey
		self._animation = ASSETS.animDict[self._animationKey]
		self._animationDuration = animationDuration / 1.0
		self._flickerSpeed = self._animationDuration / len(self._animation) # individual frame duration
		self._flickterTimer = 0.0
		self._spriteCounter = 0

		# creature component
		self.creature = creature
		if self.creature:
			self.creature.owner = self

		# ai component
		self.ai = ai
		if self.ai:
			self.ai.owner = self

		# container component
		self.container = container
		if self.container:
			self.container.owner = self

		# item component
		self.item = item
		if self.item:
			self.item.owner = self

		# equipment component
		self.equipment = equipment
		if self.equipment:
			self.equipment.owner = self

			self.item = compItem()
			self.item.owner = self

		# stairs component
		self.stairs = stairs
		if self.stairs:
			self.stairs.owner = self

	@property
	def _displayName(self):
		if self == PLAYER:
			return "Player"


		if self.creature and self._nameObject != "fly":
			return (self.creature._nameInstance + " the " + self._nameObject)
		
		if self.item:
			if self.equipment and self.equipment._equipped:
				return (self._nameObject + " (" + self.equipment._slot + ")")
			else:
				return (self._nameObject)


	def draw(self):
		if doryen.map_is_in_fov(LOS_MAP, self._x, self._y):
			SURFACE_MAP.blit(self._animation[self._spriteCounter], (self._x * const.TILE_WIDTH, self._y * const.TILE_HEIGHT))
			if len(self._animation) > 1:
				if CLOCK.get_fps() > 0.0:
					self._flickterTimer += 1 / CLOCK.get_fps()
				if self._flickterTimer >= self._flickerSpeed:
					self._flickterTimer = 0.0
					if self._spriteCounter >= len(self._animation) - 1:
						self._spriteCounter = 0
					else:
						self._spriteCounter += 1


	def distanceFrom(self, other):

		'''
		returns the distance between self and other calculated via pythagorean theorem
		'''

		diffX = other._x - self._x
		diffY = other._y - self._y

		return math.sqrt(diffX ** 2 + diffY ** 2)

	def moveTowards(self, other):

		'''

		'''

		diffX = other._x - self._x
		diffY = other._y - self._y

		moveX = 0
		moveY = 0

		if diffX != 0:
			moveX = diffX / abs(diffX)

		if diffY != 0:
			moveY = diffY / abs(diffY)

		self.creature.move(moveX, moveY)


	def moveAwayFrom(self, other):

		'''

		'''

		diffX = -(other._x - self._x)
		diffY = -(other._y - self._y)

		moveX = 0
		moveY = 0

		if diffX != 0:
			moveX = diffX / abs(diffX)

		if diffY != 0:
			moveY = diffY / abs(diffY)

		self.creature.move(moveX, moveY)

	def animDestroy(self):

		'''

		'''

		self._animation = None

	def animInit(self):

		'''

		'''

		self._animation = ASSETS.animDict[self._animationKey]

####

class objGame:

	'''

	'''

	def __init__(self):

		self._mapCurrent, self._roomsCurrent = mapMake()
		self._mapsPrevious = []
		self._mapsNext = []
		self._objectsCurrent = []
		self._messageLog = []
		self._escapePhase = False
		self._gameWon = False


	@property
	def _mapLevel(self):

		return len(self._mapsPrevious) + 1

	def transitNext(self):

		global LOS_CALC
		LOS_CALC = True

		for obj in self._objectsCurrent:
			obj.animDestroy()
		
		self._mapsPrevious.append((PLAYER._x, PLAYER._y, self._mapCurrent, self._roomsCurrent,
			self._objectsCurrent))

		if len(self._mapsNext) == 0:
			self._mapCurrent, self._roomsCurrent = mapMake()
			self._objectsCurrent = []
			mapPopulate(self._roomsCurrent)
		else:
			(PLAYER._x, PLAYER._y, self._mapCurrent, self._roomsCurrent,
			self._objectsCurrent) = self._mapsNext[-1]
			
			mapMakeLOS(self._mapCurrent)
			LOS_CALC = True

			del self._mapsNext[-1]

		for obj in self._objectsCurrent:
			obj.animInit()
		

	def transitPrev(self):

		if len(self._mapsPrevious) == 0:
			return

		global LOS_CALC

		for obj in self._objectsCurrent:
			obj.animDestroy()
		
		self._mapsNext.append((PLAYER._x, PLAYER._y, self._mapCurrent, self._roomsCurrent,
			self._objectsCurrent))

		(PLAYER._x, PLAYER._y, self._mapCurrent, self._roomsCurrent,
			self._objectsCurrent) = self._mapsPrevious[-1]

		for obj in self._objectsCurrent:
			obj.animInit()
		
		del self._mapsPrevious[-1]

		mapMakeLOS(self._mapCurrent)
		LOS_CALC = True

####

class objSpriteSheet:
	
	'''
	grab images from a spritesheet
	'''

	def __init__(self, fileName):
		# load spritesheet
		self._spriteSheet = pygame.image.load(fileName).convert()
		self._spriteDict = {'a':  1, 'b':  2, 'c':  3, 'd':  4, 'e':  5, 'f':  6, 'g':  7, 'h':  8,
							'i':  9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'o': 15, 'p': 16}


	def getAnimation(self, column, row, width = const.TILE_WIDTH, height = const.TILE_HEIGHT, numSprites = 1, scale = None):

		spriteList = []

		for i in range(numSprites):
			image = pygame.Surface([width, height]).convert()
			image.blit(self._spriteSheet, (0, 0), ((self._spriteDict[column] + i) * width, row * height, width, height))
			image.set_colorkey(const.COLOR_BLACK)

			if scale:
				image = pygame.transform.scale(image, scale)

			spriteList.append(image)

		return spriteList

	def getImage(self, column, row, width = const.TILE_WIDTH, height = const.TILE_HEIGHT, scale = None):

		image = pygame.Surface([width, height]).convert()
		image.blit(self._spriteSheet, (0, 0), ((self._spriteDict[column]) * width, row * height, width, height))
		image.set_colorkey(const.COLOR_BLACK)

		if scale:
			image = pygame.transform.scale(image, scale)

		return image

####

class objRoom:

	'''
	A rectangular room that lives on the map
	'''

	def __init__(self, coords, size):

		self._x1, self._y1 = coords
		self._width, self._height = size

		self._x2 = self._x1 + self._width
		self._y2 = self._y1 + self._height

	@property
	def _center(self):

		centerX = (self._x1 + self._x2) // 2
		centerY = (self._y1 + self._y2) // 2

		return (centerX, centerY)

	def overlap(self, other):

		'''
		Returns true if the room overlaps the other room
		''' 

		return (self._x1 <= other._x2 and self._x2 >= other._x1 and self._y1 <= other._y2 and self._y2 >= other._y1)

####

class objCamera:

	'''

	'''

	def __init__(self):

		self._width = const.CAMERA_WIDTH
		self._height = const.CAMERA_HEIGHT
		self._x, self._y = (0, 0)


	def update(self):

		targetX = PLAYER._x * const.TILE_WIDTH + const.TILE_WIDTH // 2
		targetY = PLAYER._y * const.TILE_HEIGHT + const.TILE_HEIGHT // 2

		distanceX, distanceY = self.mapDistance((targetX, targetY))

		self._x += distanceX // const.CAMERA_LAG
		self._y += distanceY // const.CAMERA_LAG


	def windowToMap(self, coords):

		targetX, targetY = coords

		cameraDiffX, cameraDiffY = self.cameraDistance((targetX, targetY))

		mapPixelX = self._x + cameraDiffX
		mapPixelY = self._y + cameraDiffY

		return (mapPixelX, mapPixelY)


	def mapDistance(self, coords):

		targX, targY = coords

		diffX = targX - self._x
		diffY = targY - self._y

		return (diffX, diffY)


	def cameraDistance(self, coords):

		windowX, windowY = coords

		diffX = windowX - self._width // 2
		diffY = windowY - self._height // 2

		return (diffX, diffY)


	@property
	def rectangle(self):

		cameraRect = pygame.Rect((0, 0), (const.CAMERA_WIDTH, const.CAMERA_HEIGHT))
		cameraRect.center = (self._x, self._y)

		return cameraRect


	@property
	def mapAddress(self):

		mapX = self._x / const.TILE_WIDTH
		mapY = self._y / const.TILE_HEIGHT

		return (mapX, mapY)


#######################################################################################################
#   _____ ________  _________ _____ _   _  _____ _   _ _____ _____
#  /  __ \  _  |  \/  || ___ \  _  | \ | ||  ___| \ | |_   _/  ___|
#  | /  \/ | | | .  . || |_/ / | | |  \| || |__ |  \| | | | \ `--.
#  | |   | | | | |\/| ||  __/| | | | . ` ||  __|| . ` | | |  `--. \
#  | \__/\ \_/ / |  | || |   \ \_/ / |\  || |___| |\  | | | /\__/ /
#   \____/\___/\_|  |_/\_|    \___/\_| \_/\____/\_| \_/ \_/ \____/
#
#######################################################################################################

class compCreature:

	'''
	have health and can die
	can damage other objects by attacking them
	'''

	def __init__(self, nameInstance,
		baseAttack = 3,
		baseDefense = 0,
		health = 10,
		deathFunction = None,
		deathAnimKey = "SPR_CORPSE_RAVEN",
		levelCurrent = 1,
		xpCurrent = None):

		self._nameInstance = nameInstance

		self._baseAttack = baseAttack
		self._baseDefense = baseDefense

		self._maxHealth = health
		self._health = health

		self.deathFunction = deathFunction
		self._deathAnimKey = deathAnimKey

		self._levelCurrent = levelCurrent

		if xpCurrent:
			self._xpCurrent = xpCurrent
		else:
			self._xpCurrent = self._levelCurrent * (self._levelCurrent - 1) * 50

		self._xpNextLevel = self._levelCurrent * (self._levelCurrent + 1) * 50

	def attack(self, target):

		damage = self._power

		gameMessage(self.owner._displayName + " attacks " + target._displayName + "!",
			const.COLOR_ATTACK)

		# if the target is a turtle, chance to break player's weapon
		if self.owner == PLAYER and target._nameObject == "turtle" and doryen.random_get_int(0, 1, 100) <= const.BREAK_CHANCE:

			allEquippedItems = self.owner.container._equippedItems
			if allEquippedItems:
				for item in allEquippedItems:
					if item.equipment._slot  == 'main hand':
						gameMessage("Your sword broke!", const.COLOR_RED)
						self.owner.container._inventory.remove(item)

		# if the attacker is a turtle, chance to break player's shield
		if self.owner._nameObject == "turtle" and target == PLAYER and doryen.random_get_int(0, 1, 100) <= const.BREAK_CHANCE:

			allEquippedItems = target.container._equippedItems

			if allEquippedItems:
				for item in allEquippedItems:
					if item.equipment._slot  == 'off hand':
						gameMessage("Your shield broke!", const.COLOR_RED)
						target.container._inventory.remove(item)

		target.creature.takeDamage(damage)

		if damage > 0 and self.owner is PLAYER:
			hitSound = ASSETS.SFX_HIT_LIST[doryen.random_get_int(0, 0, len(ASSETS.SFX_HIT_LIST) - 1)]
			pygame.mixer.Sound.play(hitSound)

		# if the creature died, gain xp
		if target.creature == None:
			self._xpCurrent += target._xpValue
			# if enough xp, level up
			if self._xpCurrent >= self._xpNextLevel and self._levelCurrent < const.PLAYER_LEVEL_MAX:
				self.levelUp()


	def takeDamage(self, damage):
		damageTaken = max(1, damage - self._defense)
		gameMessage(self.owner._displayName + " takes " + str(damageTaken) + " damage!",
			const.COLOR_DAMAGE)
		self._health -= damageTaken

		if (self._health <= 0) and (self.deathFunction):
			self.deathFunction(self.owner, self._deathAnimKey)

	def healDamage(self, value):
		if value > (self._maxHealth - self._health):
			value = (self._maxHealth - self._health)
		self._health += value
		gameMessage(self.owner._displayName + " is healed for " + str(value) + " points",
			const.COLOR_HEAL)

	def move(self, xDiff, yDiff):
		tileIsWall = GAME._mapCurrent[self.owner._x + xDiff][self.owner._y + yDiff]._impassable

		target = mapCheckForCreature(self.owner._x + xDiff, self.owner._y + yDiff, self.owner)

		if target and target is not self.owner:
			self.attack(target)

		if not tileIsWall and target == None:
			self.owner._x += xDiff
			self.owner._y += yDiff

	def levelUp(self):
		self._levelCurrent += 1
		self._xpNextLevel += self._levelCurrent * 100
		self._maxHealth += doryen.random_get_int(0, 1, const.LVL_UP_HP_MAX)
		self._health = self._maxHealth
		if self._levelCurrent % 3 == 0:
			self._baseAttack += 1
		if self._levelCurrent % 5 == 0:
			self._baseDefense += 1
		gameMessage(self.owner._displayName + " is now level " + str(self._levelCurrent) +"!",
			const.COLOR_LEVEL_UP)

	@property
	def _power(self):

		equipmentBonusList = []
		if self.owner.container:
			equipmentBonusList = [obj.equipment._attackBonus for obj in self.owner.container._equippedItems]

		equipmentBonusTotal = 0
		for bonus in equipmentBonusList:
			equipmentBonusTotal += bonus

		totalDamage = self._baseAttack + equipmentBonusTotal

		return totalDamage

	@property
	def _defense(self):

		equipmentBonusList = []
		if self.owner.container:
			equipmentBonusList = [obj.equipment._defenseBonus for obj in self.owner.container._equippedItems]

		equipmentBonusTotal = 0
		for bonus in equipmentBonusList:
			equipmentBonusTotal += bonus

		totalDefense = self._baseDefense + equipmentBonusTotal
		return totalDefense

####

class compItem:

	'''
	component that defines the properties of items
	'''

	def __init__(self, weight = 0.0, volume = 0.0, useFunction = None, useValue = None, target = None):

		self._weight = weight
		self._volume = volume
		self._useFunction = useFunction
		self._useValue = useValue
		self._target = target


	# pick up item
	def pickUp(self, actor):

		'''
		Picks up the item
		'''

		if actor.container:
			if len(actor.container._inventory) >= const.PLAYER_INVENTORY_MAX:
				gameMessage("Inventory full - cannot pick up", const.COLOR_RED)
			else:
				gameMessage(actor._displayName + " picked up " + self.owner._displayName)
				actor.container._inventory.append(self.owner)
				GAME._objectsCurrent.remove(self.owner)
				self.currentContainer = actor.container
				self.owner.animDestroy()

				if self.owner._nameObject == "Amulet of Power" and not GAME._escapePhase:
					GAME._escapePhase = True
					gameMessage("You found the Amulet of Power!", const.COLOR_PURPLE)
					gameMessage("Find the exit portal on the first level...", const.COLOR_PURPLE)
					mapRePopulate()
					pygame.mixer.music.load(ASSETS.MUSIC_BG2)
					pygame.mixer.music.play()


	# drop item
	def drop(self, newX, newY):

		'''
		Drops the item
		'''

		if self.owner._nameObject == "Amulet of Power":
			gameMessage("You cannot drop the Amulet of Power!", const.COLOR_PURPLE)
			return

		if self.owner.equipment:
			if self.owner.equipment._equipped:
				gameMessage("Item is equipped, cannot drop", const.COLOR_RED)
				return

		GAME._objectsCurrent.insert(0, self.owner)	
		self.currentContainer._inventory.remove(self.owner)
		self.owner.animInit()
		self.owner._x = newX
		self.owner._y = newY
		gameMessage(self.currentContainer.owner._displayName + " dropped " + self.owner._displayName, const.COLOR_RED)	


	# use item
	def use(self):

		'''
		Uses the item
		'''

		if self.owner.equipment:
			self.owner.equipment.toggleEquip()
			return

		if self._useFunction:
			result = self._useFunction(useValue = self._useValue, caster = self.owner.item.currentContainer.owner)

			if result is not None:
				gameMessage("Use " + self.owner._displayName + ": " + result, const.COLOR_RED)
			else:
				gameMessage(self.currentContainer.owner._displayName + " used " + self.owner._displayName, const.COLOR_RED)
				self.currentContainer._inventory.remove(self.owner)

####

class compContainer:

	'''

	'''

	def __init__(self, volume = 10.0, inventory = []):
		self._maxVolume = volume
		self._inventory = inventory

	# get names of all items in inventory


	# get volume of all items held in container
	def getVolume(self):
		volume = 0.0
		for obj in self._inventory:
			if obj.item:
				volume += obj.item._volume
		return volume

	@property
	def _equippedItems(self):
		return [obj for obj in self._inventory if (obj.equipment and obj.equipment._equipped)]

	@property
	def _volume(self):
		return 0.0

	@property
	def _weight(self):
		return 0.0

####

class compEquipment:

	'''

	'''

	def __init__(self, attackBonus = 0, defenseBonus = 0, slot = None):

		self._attackBonus = attackBonus
		self._defenseBonus = defenseBonus
		self._slot = slot
		self._equipped = False

	def toggleEquip(self):

		if self._equipped:
			self.unequip()
		else:
			self.equip()

	def equip(self):

		allEquippedItems = self.owner.item.currentContainer._equippedItems

		if allEquippedItems:
			for item in allEquippedItems:
				if item.equipment._slot and (item.equipment._slot == self._slot):
					gameMessage(self._slot + " slot is occupied", const.COLOR_RED)
					return

		self._equipped = True
		gameMessage(self.owner._nameObject + " equipped")


	def unequip(self):

		if self.owner._nameObject == "Amulet of Power":
			gameMessage("You cannot unequip the Amulet of Power!", const.COLOR_PURPLE)
			return

		self._equipped = False

		gameMessage(self.owner._nameObject + " unequipped")

####

class compStairs:

	'''

	'''

	def __init__(self, downwards = True):

		self._downwards = downwards


	def use(self):

		nextLevel = str(len(GAME._mapsPrevious) + 2)
		prevLevel = str(len(GAME._mapsPrevious))

		if self.owner._nameObject == "win_portal":
			gameWin()

		if self._downwards:
			gameMessage("Entering level " + nextLevel)
			GAME.transitNext()
		else:
			gameMessage("Entering level " + prevLevel)
			GAME.transitPrev()


#######################################################################################################
#  ___  ___  ___  _____ _____ _____ 
#  |  \/  | / _ \|  __ \_   _/  __ \
#  | .  . |/ /_\ \ |  \/ | | | /  \/
#  | |\/| ||  _  | | __  | | | |    
#  | |  | || | | | |_\ \_| |_| \__/\
#  \_|  |_/\_| |_/\____/\___/ \____/
#
#######################################################################################################

def castHeal(useValue = 5,
	caster = None,
	target = None):

	'''
	Item heals the targe when used
	'''

	if caster == None:
		caster = PLAYER

	casterName = caster._displayName
	casterLocation = (caster._x, caster._y)

	if (caster.creature._health >= caster.creature._maxHealth):
		gameMessage(casterName + " is already at full health", const.COLOR_RED)
		return "cancelled"
	else:
		caster.creature.healDamage(useValue)

####

def castLightning(useValue = 5,
	caster = None):

	'''
	Casts a lightning bolt along the specified line
	'''

	spellDamage = useValue
	spellRange = 7
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	# prompt the player for a tile
	targetTile = menuTargetSelect(originCoords = casterLocation, line = True, maxRange = spellRange,
		passWall = False)
	if targetTile == None:
		return "cancelled"

	if casterName:
		gameMessage(casterName + " casts lightning", const.COLOR_SPELL)

	lightningPathList = mapFindLine(casterLocation, targetTile)

	# cycle through the list and damage everything found
	for (x, y) in lightningPathList:
		target = mapCheckForCreature(x, y)
		if target:
			gameMessage(target._displayName + " convulses from the shock", const.COLOR_SPELL)
			target.creature.takeDamage(spellDamage)

	return None

####

def castFireball(useValue = 5,
	caster = None):

	'''

	'''

	spellDamage = useValue
	spellRadius = 1
	spellRange = 5
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	# get target tile
	targetTile = menuTargetSelect(originCoords = casterLocation, line = True, maxRange = spellRange,
		passWall = False, passCreature = False, radius = spellRadius)

	if targetTile == None:
		return "cancelled"

	if casterName:
		gameMessage(casterName + " casts fireball", const.COLOR_SPELL)

	# get sequence of tiles
	fireballArea = mapFindRadius(targetTile, spellRadius)

	# damage all creatures in sequence of tiles
	for (x, y) in fireballArea:
		target = mapCheckForCreature(x, y)
		if target:
			if target is not PLAYER:
				gameMessage(target._displayName + "'s flesh sizzles", const.COLOR_SPELL)
			target.creature.takeDamage(spellDamage)

	return None

####

def castConfusion(useValue = 3,
	caster = None):

	'''

	'''

	spellRange = 7
	spellDuration = useValue
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	# select tile
	targetTile = menuTargetSelect(maxRange = spellRange)

	if targetTile == None:
		return "cancelled"

	# get target from tile
	x, y = targetTile
	target = mapCheckForCreature(x, y)

	# temporarily replace target's ai with confused ai
	if target:
		if casterName:
			gameMessage(casterName + " casts confusion", const.COLOR_SPELL)
		oldAI = target.ai
		target.ai = aiConfused(oldAI = oldAI, duration = spellDuration)
		target.ai.owner = target
		gameMessage(target._displayName + "'s eye glaze over.", const.COLOR_SPELL)

	return None

####

def castTerror(useValue = 3,
	caster = None):

	'''

	'''

	spellRadius = 2
	spellDuration = useValue

	for target in GAME._objectsCurrent:
		if target.creature and (target is not caster) and (target.distanceFrom(caster) <= spellRadius):
			# temporarily replace target's ai with afraid ai
			oldAI = target.ai
			target.ai = aiAfraid(oldAI = oldAI, duration = spellDuration)
			target.ai.owner = target
			gameMessage(target._displayName + " flees in terror", const.COLOR_BLUE)


#######################################################################################################
#    ___  _____ 
#   / _ \|_   _|
#  / /_\ \ | |  
#  |  _  | | |  
#  | | | |_| |_ 
#  \_| |_/\___/
#
#######################################################################################################

class aiConfused:

	'''
	AI rules for confused creatures
	  act once per turn
	  move randomly
	'''

	def __init__(self, oldAI, duration):
		self.oldAI = oldAI
		self.duration = duration

	def takeTurn(self):
		if self.duration > 0:
			self.owner.creature.move(doryen.random_get_int(0, -1, 1), doryen.random_get_int(0, -1, 1))
			self.duration -= 1
		else:
			self.owner.ai = self.oldAI
			gameMessage(self.owner._displayName + "'s eyes return to normal", const.COLOR_SPELL)

####

class aiAfraid:

	'''
	AI rules for confused creatures
	  act once per turn
	  move away from the player
	'''

	def __init__(self, oldAI, duration):
		self.oldAI = oldAI
		self.duration = duration

	def takeTurn(self):
		if self.duration > 0:
			if doryen.map_is_in_fov(LOS_MAP, self.owner._x, self.owner._y):
				self.owner.moveAwayFrom(PLAYER)
			self.duration -= 1
		else:
			self.owner.ai = self.oldAI
			gameMessage(self.owner._displayName + "'s courage returns", const.COLOR_BLUE)

####

class aiPursue:

	'''
	Chases and attacks the player
	'''

	def takeTurn(self):

		monster = self.owner

		if doryen.map_is_in_fov(LOS_MAP, monster._x, monster._y):
			monster.moveTowards(PLAYER)
		
####

class aiFly:

	'''
	50/50 flees the player or moves randomly
	'''

	def takeTurn(self):

		fly = self.owner

		if doryen.map_is_in_fov(LOS_MAP, fly._x, fly._y):
			if doryen.random_get_int(0, 1, 100) <= 67:
				fly.moveAwayFrom(PLAYER)
			else:
				fly.creature.move(doryen.random_get_int(0, -1, 1), doryen.random_get_int(0, -1, 1))


#######################################################################################################
#  ______ _____  ___ _____ _   _ 
#  |  _  \  ___|/ _ \_   _| | | |
#  | | | | |__ / /_\ \| | | |_| |
#  | | | |  __||  _  || | |  _  |
#  | |/ /| |___| | | || | | | | |
#  |___/ \____/\_| |_/\_/ \_| |_/
#
#######################################################################################################
 
def deathMonster(monster,
	deathAnimKey = "SPR_CORPSE_BONES"):
	
	'''
	defines what happens when a monster dies (they stop moving and are no longer a creature)
	'''

	gameMessage ((monster._displayName + " is dead!"), const.COLOR_DEATH)

	monster._nameObject = "corpse of " + monster._displayName
	monster._animationKey = deathAnimKey
	monster._spriteCounter = 0
	monster.animInit()
	monster._depth = const.DEPTH_CORPSE

	monster.creature = None
	monster.ai = None

####

def deathFly(fly,
	deathAnimKey = "SPR_CORPSE_FLY"):
	
	'''
	defines what happens when a fly dies (they stop moving and are no longer a creature)
	'''

	gameMessage (("The fly is dead!  It looks yummy..."), const.COLOR_GREEN)

	fly._nameObject = "juicy dead fly"
	fly._animationKey = deathAnimKey
	fly._spriteCounter = 0
	fly.animInit()
	fly._depth = const.DEPTH_ITEM


	fly.creature = None
	fly.ai = None

####

def deathPlayer(player,
	deathAnimKey = 'SPR_CORPSE_PLAYER'):

	'''

	'''

	player._status = "STATUS_DEAD"
	gameMessage("You have died!")

	#delete save file if it exists
	try:
		os.remove('SaveData/savegame')
	except:
		pass

	player._animationKey = deathAnimKey
	player._spriteCounter = 0
	player.animInit()

	drawGame()

	pygame.display.update()

	pygame.time.wait(3000)

	SURFACE_MAIN.fill(const.COLOR_BLACK)

	screenCenter = (const.DISPLAY_WIDTH // 2, const.DISPLAY_HEIGHT //2)

	drawText(SURFACE_MAIN, "YOU HAVE DIED!!!", screenCenter,
		textFont = const.FONT_DEATH,
		textColor = const.COLOR_RED,
		backgroundColor = None,
		center = True)

	pygame.display.update()

	# create legacy file
	genLegacyFile()

	pygame.time.wait(3000)

	pygame.mixer.music.load(ASSETS.MUSIC_BG1)
	pygame.mixer.music.play()


#######################################################################################################
#   _      _____ _____   _____ _____  ______ _____ _____ _____ _   _   _ 
#  | |    |  ___|_   _| |_   _|_   _| | ___ \  ___|  __ \_   _| \ | | | |
#  | |    | |__   | |     | |   | |   | |_/ / |__ | |  \/ | | |  \| | | |
#  | |    |  __|  | |     | |   | |   | ___ \  __|| | __  | | | . ` | | |
#  | |____| |___  | |    _| |_  | |   | |_/ / |___| |_\ \_| |_| |\  | |_|
#  \_____/\____/  \_/    \___/  \_/   \____/\____/ \____/\___/\_| \_/ (_)
#
#######################################################################################################

if __name__ == "__main__":
	menuMain()


#################################################################
#                                                               #
#  ''''''''''''''''''' @@@@@@@@@@@@@@@@@@@''''''''''''''''''''  #
#  '''''''''''''''''@@@@@@'''''''''''''@@@@@@@''''''''''''''''  #
#  ''''''''''''''@@@@'''''''''''''''''''''''@@@@''''''''''''''  #
#  '''''''''''''@@@'''''''''''''''''''''''''''''@@''''''''''''  #
#  ''''''''''''@@''''''''''''''''''''''''''''''''@@'''''''''''  #
#  '''''''''''@@'''''''''''''''''''''`'''''''''''@@'''''''''''  #
#  ''''''''''@@'''''''''''''''''''''''''''''''''''@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@''@@''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@''@@'''''''''''''''''''''''''''@@''@@''''''''''  #
#  '''''''''''@@'@@'''@@@@@@@@'''''@@@@@@@@'''@@'@@'''''''''''  #
#  ''''''''''''@@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@@@'''''''''''  #
#  '''''''''''''@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@'''''''''''''  #
#  ''''@@@'''''''@@''@@@@@@@@'''''''@@@@@@@@@''@@''''''@@@@'''  #
#  '''@@@@@'''''@@'''@@@@@@@'''@@@'''@@@@@@@'''@@'''''@@@@@@''  #
#  ''@@'''@@''''@@'''''@@@''''@@@@@''''@@@'''''@@''''@@'''@@''  #
#  '@@@''''@@@@''@@''''''''''@@@@@@@''''''''''@@''@@@@''''@@@'  #
#  @@'''''''''@@@@@@@@'''''''@@@'@@@'''''''@@@@@@@@@''''''''@@  #
#  @@@@@@@@@'''''@@@@@@@@''''@@'''@@''''@@@@@@@@''''''@@@@@@@@  #
#  ''@@@@'@@@@@''''''@@@@@''''''''''''''@@@'@@'''''@@@@@@'@@@'  #
#  ''''''''''@@@@@@''@@@''@@'''''''''''@@''@@@''@@@@@@''''''''  #
#  ''''''''''''''@@@@@@'@@'@@@@@@@@@@@'@@'@@@@@@''''''''''''''  #
#  ''''''''''''''''''@@'@@'@'@'@'@'@'@'@'@'@@'''''''''''''''''  #
#  ''''''''''''''''@@@@''@'@'@'@'@'@'@'@'''@@@@@''''''''''''''  #
#  ''''''''''''@@@@@'@@'''@@@@@@@@@@@@@'''@@'@@@@@''''''''''''  #
#  ''''@@@@@@@@@@'''''@@'''''''''''''''''@@''''''@@@@@@@@@''''  #
#  '''@@'''''''''''@@@@@@@'''''''''''''@@@@@@@@''''''''''@@'''  #
#  ''''@@@'''''@@@@@'''''@@@@@@@@@@@@@@@'''''@@@@@'''''@@@''''  #
#  ''''''@@'''@@@'''''''''''@@@@@@@@@'''''''''''@@@'''@@''''''  #
#  ''''''@@''@@'''''''''''''''''''''''''''''''''''@@''@@''''''  #
#  '''''''@@@@'''''''''''''''''''''''''''''''''''''@@@@'''''''  #
#                                                               #
#################################################################

