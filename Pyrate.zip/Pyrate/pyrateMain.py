"""

Pyrate - (noun) an archaic spelling of 'pirate'

	Also:  a python roguelike by RG Blaine using pygame and the doryen library (libtcod)

"""

#################################################################
#                                                               #
#  ''''''''''''''''''' @@@@@@@@@@@@@@@@@@@''''''''''''''''''''  #
#  '''''''''''''''''@@@@@@'''''''''''''@@@@@@@''''''''''''''''  #
#  ''''''''''''''@@@@'''''''''''''''''''''''@@@@''''''''''''''  #
#  '''''''''''''@@@'''''''''''''''''''''''''''''@@''''''''''''  #
#  ''''''''''''@@''''''''''''''''''''''''''''''''@@'''''''''''  #
#  '''''''''''@@'''''''''''''''''''''`'''''''''''@@'''''''''''  #
#  ''''''''''@@'''''''''''''''''''''''''''''''''''@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@''@@''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@''@@'''''''''''''''''''''''''''@@''@@''''''''''  #
#  '''''''''''@@'@@'''@@@@@@@@'''''@@@@@@@@'''@@'@@'''''''''''  #
#  ''''''''''''@@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@@@'''''''''''  #
#  '''''''''''''@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@'''''''''''''  #
#  ''''@@@'''''''@@''@@@@@@@@'''''''@@@@@@@@@''@@''''''@@@@'''  #
#  '''@@@@@'''''@@'''@@@@@@@'''@@@'''@@@@@@@'''@@'''''@@@@@@''  #
#  ''@@'''@@''''@@'''''@@@''''@@@@@''''@@@'''''@@''''@@'''@@''  #
#  '@@@''''@@@@''@@''''''''''@@@@@@@''''''''''@@''@@@@''''@@@'  #
#  @@'''''''''@@@@@@@@'''''''@@@'@@@'''''''@@@@@@@@@''''''''@@  #
#  @@@@@@@@@'''''@@@@@@@@''''@@'''@@''''@@@@@@@@''''''@@@@@@@@  #
#  ''@@@@'@@@@@''''''@@@@@''''''''''''''@@@'@@'''''@@@@@@'@@@'  #
#  ''''''''''@@@@@@''@@@''@@'''''''''''@@''@@@''@@@@@@''''''''  #
#  ''''''''''''''@@@@@@'@@'@@@@@@@@@@@'@@'@@@@@@''''''''''''''  #
#  ''''''''''''''''''@@'@@'@'@'@'@'@'@'@'@'@@'''''''''''''''''  #
#  ''''''''''''''''@@@@''@'@'@'@'@'@'@'@'''@@@@@''''''''''''''  #
#  ''''''''''''@@@@@'@@'''@@@@@@@@@@@@@'''@@'@@@@@''''''''''''  #
#  ''''@@@@@@@@@@'''''@@'''''''''''''''''@@''''''@@@@@@@@@''''  #
#  '''@@'''''''''''@@@@@@@'''''''''''''@@@@@@@@''''''''''@@'''  #
#  ''''@@@'''''@@@@@'''''@@@@@@@@@@@@@@@'''''@@@@@'''''@@@''''  #
#  ''''''@@'''@@@'''''''''''@@@@@@@@@'''''''''''@@@'''@@''''''  #
#  ''''''@@''@@'''''''''''''''''''''''''''''''''''@@''@@''''''  #
#  '''''''@@@@'''''''''''''''''''''''''''''''''''''@@@@'''''''  #
#                                                               #
#################################################################


# module imports
import pygame
import libtcodpy as doryen
import math


# game file imports
import constants


# test statement
print "\nHello World\n"



#######################################################################################################
#   _____   ___  ___  ___ _____
#  |  __ \ / _ \ |  \/  ||  ___|
#  | |  \// /_\ \| .  . || |__ 
#  | | __ |  _  || |\/| ||  __|
#  | |_\ \| | | || |  | || |___
#   \____/\_| |_/\_|  |_/\____/
#
#######################################################################################################

def gameInit():

	'''
	initializes the main game window and pygame module
	'''

	# variables
	global SURFACE_MAIN, GAME, CLOCK, LOS_CALC, PLAYER, ENEMY, Assets

	# initialize pygame
	pygame.init()
	pygame.key.set_repeat(200, 100)

	SURFACE_MAIN = pygame.display.set_mode( (constants.DISPLAY_WIDTH,constants.DISPLAY_HEIGHT) )

	GAME = objGame()

	CLOCK = pygame.time.Clock()

	LOS_CALC = True

	Assets = structAssets()

	creatureComp1 = compCreature("Kermit", health = 20)
	containerComp1 = compContainer()
	PLAYER = objActor(1, 1, "frog", Assets.ANIM_FROG, creature = creatureComp1, container = containerComp1)

	creatureComp2 = compCreature("Krusty", baseDefense = 1, health = 15, deathFunction = deathMonster)
	aiComp2 = aiDefault()
	itemComp2 = compItem(useFunction = castHeal, useValue = 5, target = PLAYER)
	ENEMY  = objActor(constants.MAP_WIDTH - 2, constants.MAP_HEIGHT - 2, "crab", Assets.ANIM_CRAB,
		creature = creatureComp2, ai = aiComp2, item = itemComp2)

	creatureComp3 = compCreature("Monty", baseAttack = 5, deathFunction = deathMonster)
	aiComp3 = aiDefault()
	itemComp3 = compItem(useFunction = castHeal, useValue = 3, target = PLAYER)
	ENEMY_2  = objActor(constants.MAP_WIDTH - 2, 1, "python", Assets.ANIM_PYTHON,
		creature = creatureComp3, ai = aiComp3, item = itemComp3)

	# actor list
	GAME._currentObjects = [PLAYER, ENEMY, ENEMY_2]

	# create items
	genItem((1,2))
	genItem((1,3))
	genItem((1,4))
	genItem((2,1))
	genItem((3,1))
	genItem((4,1))

def gameMainLoop():

	'''
	the main game loop
	'''

	# define the player's action
	playerAction = "no-action"

	# flag to exit the game
	gameOver = False

	while not gameOver:
		# get input and process it
		playerAction = handleInput()

		mapCalcLOS()
		
		if playerAction == "QUIT":
			gameOver = True

		elif playerAction != "no-action":
			# gameMessage(playerAction)
			for obj in GAME._currentObjects:
				if obj.ai:
					obj.ai.takeTurn()

		# draw game
		drawGame()

		# update display
		pygame.display.flip()

		# tick the clock
		CLOCK.tick(constants.GAME_FPS)

	print "\nGoodbye World\n"
	pygame.quit()
	exit()


def handleInput():
	global LOS_CALC

	# get list of events
	eventList = pygame.event.get()

	# handle those events
	for event in eventList:
		# player clicks the window's X button
		if event.type == pygame.QUIT:
			return "QUIT"

		# player presses a key
		if event.type == pygame.KEYDOWN:

			# up arrow => move up
			if event.key == pygame.K_UP:
				PLAYER.creature.move(0, -1)
				LOS_CALC = True
				return "player-moved-north"

			# down arrow => move down
			if event.key == pygame.K_DOWN:
				PLAYER.creature.move(0, 1)
				LOS_CALC = True
				return "player-moved-south"

			# left arrow => move left
			if event.key == pygame.K_LEFT:
				PLAYER.creature.move(-1, 0)
				LOS_CALC = True
				return "player-moved-west"

			# right arrow => move right
			if event.key == pygame.K_RIGHT:
				PLAYER.creature.move(1, 0)
				LOS_CALC = True
				return "player-moved-east"

			# g key => pick up (get) items at the player's location
			if event.key == pygame.K_g:
				objectsAtPlayer = mapObjectsAtLocation(PLAYER._x, PLAYER._y)
				for obj in objectsAtPlayer:
					if obj.item:
						obj.item.pickUp(PLAYER)

			# d key => player takes 1
			if event.key == pygame.K_d:
			#	if len(PLAYER.container._inventory) > 0:
			#		PLAYER.container._inventory[-1].item.drop(PLAYER._x, PLAYER._y)
				PLAYER.creature.takeDamage(1)

			# p key => pause menu
			if event.key == pygame.K_p:
				menuPause()

			# i key => inventory menu
			if event.key == pygame.K_i:
				menuInventory()

			# l key => cast lightning
			if event.key == pygame.K_l:
				castLightning(caster = PLAYER)

			# f key => cast fireball
			if event.key == pygame.K_f:
				castFireball(caster = PLAYER)

			# c key => cast confusion
			if event.key == pygame.K_c:
				castConfusion(caster = PLAYER)

			# t key => cast terror
			#if event.key == pygame.K_t:
			#	castTerror(PLAYER)


	# no action taken
	return "no-action"


def gameMessage(messageText, textColor = constants.COLOR_WHITE):

	'''
	adds the submitted text to the GAME._messageLog list as a tuple
	'''

	GAME._messageLog.append((messageText, textColor))



#######################################################################################################
#  ___  ___ _____ _   _ _   _ _____ 
#  |  \/  ||  ___| \ | | | | /  ___|
#  | .  . || |__ |  \| | | | \ `--. 
#  | |\/| ||  __|| . ` | | | |`--. \
#  | |  | || |___| |\  | |_| /\__/ /
#  \_|  |_/\____/\_| \_/\___/\____/ 
#
#######################################################################################################

def menuPause():

	'''
	pause game
	'''

	menuText = "PAUSED"
	menuFont = Assets.FONT_DEBUG

	xOffset = helperTextWidth(menuFont) * len(menuText) / 2
	yOffset = helperTextHeight(menuFont) / 2


	drawText(SURFACE_MAIN, menuText, (constants.DISPLAY_WIDTH/2 - xOffset, constants.DISPLAY_HEIGHT/2 - yOffset),
		menuFont, constants.COLOR_WHITE, constants.COLOR_BLACK)
	pygame.display.flip()

	while True:
		# tick the clock to avoid animation errors while paused
		CLOCK.tick(constants.GAME_FPS)

		eventList = pygame.event.get()
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_p or (event.key == pygame.K_ESCAPE):
					return


def menuInventory():

	'''
	displays the player's inventory
	'''

	menuFont = Assets.FONT_MESSAGE
	menuTextHeight = helperTextHeight(menuFont)

	menuHeight = 200
	menuWidth  = 200

	menuXPos = constants.DISPLAY_WIDTH/2 - menuWidth/2
	menuYPos = constants.DISPLAY_HEIGHT/2 - menuHeight/2

	menuSurface = pygame.Surface( (menuWidth, menuHeight) )

	while True:
		# populate the inventory list
		menuList = [obj._displayName for obj in PLAYER.container._inventory]

		# clear menu
		menuSurface.fill(constants.COLOR_BLACK)

		# register changes
		eventList = pygame.event.get()

		mouseX, mouseY = pygame.mouse.get_pos()
		mouseMenuX = mouseX - menuXPos
		mouseMenuY = mouseY - menuYPos

		mouseInWindow = ((mouseMenuX in range(0, menuWidth)) and
						(mouseMenuY in range(0, menuHeight)))

		mouseMenuLine = -1
		if mouseInWindow:
			mouseMenuLine = mouseMenuY // menuTextHeight

		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if (event.key == pygame.K_i) or (event.key == pygame.K_ESCAPE):
					return
			if event.type == pygame.MOUSEBUTTONDOWN:
				if ((event.button == 1) and
					mouseInWindow and
					(mouseMenuLine < len(menuList))):
					# mouse button 1 to use selected item
					clickedItem = PLAYER.container._inventory[mouseMenuLine]
					closeMenu = True
					if clickedItem.equipment:
						closeMenu = False
					clickedItem.item.use()
					if closeMenu:
						return
				if ((event.button == 3) and
					mouseInWindow and
					(mouseMenuLine < len(menuList))):
					# mouse button 2 to drop selected item
					PLAYER.container._inventory[mouseMenuLine].item.drop(PLAYER._x, PLAYER._y)

		# draw the menuList
		line = 0
		for inventoryItem in menuList:
			if line == mouseMenuLine:
				highlight = constants.COLOR_GRAY
			else:
				highlight = None
			drawText(menuSurface, inventoryItem, (0, line * menuTextHeight),
				menuFont, constants.COLOR_WHITE, highlight)
			line += 1

		# tick the clock
		CLOCK.tick(constants.GAME_FPS)

		# draw the game
		drawGame()

		# display menu
		SURFACE_MAIN.blit(menuSurface, (menuXPos, menuYPos))

		# refresh the display
		pygame.display.flip()


def menuTargetSelect(originCoords = None, maxRange = None, passWall = True, passCreature = True, radius = None):

	'''
	The player selects a tile to target.

	Pauses the game, produces an onscreen rectangle controlled by the mouse, when the LMB is clicked,
	returns the map coordinates.

	'''

	while True:
		# get mouse pos
		(mouseX, mouseY) = pygame.mouse.get_pos()
		mouseMapX = mouseX / constants.TILE_WIDTH
		mouseMapY = mouseY / constants.TILE_HEIGHT

		# get button click
		eventList = pygame.event.get()

		if originCoords:
			tileList = mapFindLine(originCoords, (mouseMapX, mouseMapY))
		else:
			tileList = [(mouseMapX, mouseMapY)]

		# stop at max range?
		if maxRange and (maxRange < len(tileList)):
			del tileList[maxRange:]

		if (len(tileList) > 1):
			for i, (x,y) in enumerate(tileList):
				# stop at wall?
				if (not passWall) and GAME._currentMap[x][y]._impassable:
					del tileList[i:]
					break
				# stop at creature?
				if (not passCreature) and mapCheckForCreature(x, y) and (i < len(tileList)):
					del tileList[i+1:]
					break

		# return map coords when LMB is clicked
		for event in eventList:
			if event.type == pygame.KEYDOWN:
				if event.key == pygame.K_ESCAPE:
					return None
			if event.type == pygame.MOUSEBUTTONDOWN:
				if (event.button == 1):
					# mouse button 1 to use select a tile to target, returns map tile coords
					return tileList[-1]

		# draw game
		drawGame()

		# draw targetting line to mouse pos
		for mapCoords in tileList:
			if mapCoords == tileList[-1]:
				drawTarget(mapCoords, mark = "x")
			else:
				drawTarget(mapCoords)

		# draw radius, if any
		if radius:
			areaOfEffect = mapFindRadius(tileList[-1], radius)
			for (mapCoords) in areaOfEffect:
				drawTarget(mapCoords, tileColor = constants.COLOR_RED)

		# update display
		pygame.display.flip()

		# tick the clock
		CLOCK.tick(constants.GAME_FPS)



#######################################################################################################
#  ____________  ___  _    _ 
#  |  _  \ ___ \/ _ \| |  | |
#  | | | | |_/ / /_\ \ |  | |
#  | | | |    /|  _  | |/\| |
#  | |/ /| |\ \| | | \  /\  /
#  |___/ \_| \_\_| |_/\/  \/
#
#######################################################################################################

def drawGame():

	'''
	draws the game on the main surface
	'''

	# variables
	global SURFACE_MAIN

	# clear surface
	SURFACE_MAIN.fill(constants.COLOR_BACKGROUND_DEFAULT)

	# draw the map
	drawMap(GAME._currentMap)

	# draw all objects
	for obj in GAME._currentObjects:
		obj.draw()

	drawDebug()
	drawMessages()


def drawMap(map):

	'''
	draws the map
	'''

	global LOS_MAP

	# cycle through map cells and draw a wall or a floor tile
	for y in range(constants.MAP_HEIGHT):
		for x in range(constants.MAP_WIDTH):

			if doryen.map_is_in_fov(LOS_MAP, x, y):

				map[x][y]._explored = True

				if map[x][y]._impassable == True:
					# draw wall
					SURFACE_MAIN.blit(Assets.SPRITE_WALL, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))
				else:
					# draw floor
					SURFACE_MAIN.blit(Assets.SPRITE_FLOOR, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))

			elif map[x][y]._explored:
				if map[x][y]._impassable == True:
					# draw unlit wall
					SURFACE_MAIN.blit(Assets.SPRITE_WALL_DARK, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))
				else:
					# draw unlit floor
					SURFACE_MAIN.blit(Assets.SPRITE_FLOOR_DARK, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))


def drawText(displaySurface, textToDisplay, tupCoords, textFont, textColor, backgroundColor = None, center = False):

	'''
	displays submitted text on the referenced surface
	'''

	textSurface, textRect = helperTextObjects(textToDisplay, textFont, textColor, backgroundColor)

	if center:
		textRect.center = tupCoords
	else:
		textRect.topleft = tupCoords

	displaySurface.blit(textSurface, textRect)


def drawDebug():

	'''
	draws debug messages (FPS)
	'''

	drawText(SURFACE_MAIN, "fps: " + str(int(CLOCK.get_fps())), (0, 0),
		Assets.FONT_DEBUG, constants.COLOR_WHITE, constants.COLOR_BLACK)


def drawMessages():

	'''
	draws game messages
	'''

	if len(GAME._messageLog) < constants.NUM_MESSAGES:
		textToDraw = GAME._messageLog
	else:
		textToDraw = GAME._messageLog[-(constants.NUM_MESSAGES):]

	textHeight = helperTextHeight(Assets.FONT_MESSAGE)
	startY = constants.DISPLAY_HEIGHT - (constants.NUM_MESSAGES * textHeight)

	i = 0
	for message, color in textToDraw:
		drawText(SURFACE_MAIN, message, (0, startY + i), Assets.FONT_MESSAGE, color, constants.COLOR_BLACK)
		i += textHeight


def drawTarget(coords, tileColor = constants.COLOR_WHITE, tileAlpha = 150, mark = None):

	'''

	'''

	mapX, mapY = coords
	mapX *= constants.TILE_WIDTH
	mapY *= constants.TILE_HEIGHT

	newSurface = pygame.Surface((constants.TILE_WIDTH, constants.TILE_HEIGHT))

	newSurface.fill(tileColor)
	newSurface.set_alpha(tileAlpha)

	if mark:
		drawText(newSurface, mark, (constants.TILE_WIDTH/2, constants.TILE_HEIGHT/2), constants.FONT_CURSOR,
			constants.COLOR_BLACK, center = True)

	SURFACE_MAIN.blit(newSurface, (mapX, mapY))



#######################################################################################################
#   _____  _____ _   _  ___________  ___ _____ ___________  _____ 
#  |  __ \|  ___| \ | ||  ___| ___ \/ _ \_   _|  _  | ___ \/  ___|
#  | |  \/| |__ |  \| || |__ | |_/ / /_\ \| | | | | | |_/ /\ `--. 
#  | | __ |  __|| . ` ||  __||    /|  _  || | | | | |    /  `--. \
#  | |_\ \| |___| |\  || |___| |\ \| | | || | \ \_/ / |\ \ /\__/ /
#   \____/\____/\_| \_/\____/\_| \_\_| |_/\_/  \___/\_| \_|\____/
#
#######################################################################################################

def genItem(coords):

	'''

	'''

	randNum = doryen.random_get_int(0, 1, 5)

	if randNum == 1:
		newItem = genScrollLightning(coords)
	elif randNum == 2:
		newItem = genScrollFireball(coords)
	elif randNum == 3:
		newItem = genScrollConfusion(coords)
	elif randNum == 4:
		newItem = genWeaponSword(coords)
	elif randNum == 5:
		newItem = genArmorShield(coords)

	GAME._currentObjects.append(newItem)


def genScrollLightning(coords):

	'''

	'''

	x, y = coords

	damage = doryen.random_get_int(0, 2, 8)

	itemComp = compItem(useFunction = castLightning, useValue = damage)
	scroll  = objActor(x, y, "lightning scroll", Assets.SPRITE_SCROLL_1, item = itemComp)

	return scroll


def genScrollFireball(coords):

	'''

	'''

	x, y = coords

	damage = doryen.random_get_int(0, 3, 7)

	itemComp = compItem(useFunction = castFireball, useValue = damage)
	scroll  = objActor(x, y, "fireball scroll", Assets.SPRITE_SCROLL_2, item = itemComp)

	return scroll


def genScrollConfusion(coords):

	'''

	'''

	x, y = coords

	duration = doryen.random_get_int(0, 4, 6)

	itemComp = compItem(useFunction = castConfusion, useValue = duration)
	scroll  = objActor(x, y, "confusion scroll", Assets.SPRITE_SCROLL_3, item = itemComp)

	return scroll


def genWeaponSword(coords):

	'''

	'''

	x, y = coords

	attack = doryen.random_get_int(0, 1, 3)

	equipmentComp = compEquipment(attackBonus = attack, slot = "main hand")
	sword = objActor(x, y, "Cutlass +" + str(attack), Assets.SPRITE_SWORD, equipment = equipmentComp)

	return sword


def genArmorShield(coords):

	'''

	'''

	x, y = coords

	defense = doryen.random_get_int(0, 1, 2)

	equipmentComp = compEquipment(defenseBonus = defense, slot = "off hand")
	shield = objActor(x, y, "Buckler +" + str(defense), Assets.SPRITE_SHIELD, equipment = equipmentComp)

	return shield


#######################################################################################################
#   _   _  _____ _     ______ ___________  _____ 
#  | | | ||  ___| |    | ___ \  ___| ___ \/  ___|
#  | |_| || |__ | |    | |_/ / |__ | |_/ /\ `--. 
#  |  _  ||  __|| |    |  __/|  __||    /  `--. \
#  | | | || |___| |____| |   | |___| |\ \ /\__/ /
#  \_| |_/\____/\_____/\_|   \____/\_| \_|\____/
#
#######################################################################################################

def helperTextObjects(incText, incFont, incColor, incBackground):

	'''
	returns a text surface and rectangle
	'''

	if incBackground:
		surface = incFont.render(incText, False, incColor, incBackground)
	else:
		surface = incFont.render(incText, False, incColor)

	return surface, surface.get_rect()


def helperTextHeight(font):
	 
	'''
	returns the height (in pixels) of the submitted font
	'''

	fontObj = font.render('a', False, (0, 0, 0))
	fontRect = fontObj.get_rect()

	return fontRect.height


def helperTextWidth(font):

	'''
	returns the width (in pixels) of the submitted font
	'''

	fontObj = font.render('a', False, (0, 0, 0))
	fontRect = fontObj.get_rect()

	return fontRect.width



#######################################################################################################
#  ___  ___  ___  ______ 
#  |  \/  | / _ \ | ___ \
#  | .  . |/ /_\ \| |_/ /
#  | |\/| ||  _  ||  __/
#  | |  | || | | || |   
#  \_|  |_/\_| |_/\_|
#
#######################################################################################################

def mapMake():

	'''
	makes and returns a map as an array
	'''

	# create a blank map
	newMap = [[structTile(False) for y in range(constants.MAP_HEIGHT)] for x in range(constants.MAP_WIDTH)]

	# add random wall tiles to map
	maxWalls = (constants.MAP_WIDTH - 4) * (constants.MAP_HEIGHT - 4) // 10
	minWalls = maxWalls // 2
	numWalls = doryen.random_get_int(0, minWalls, maxWalls)

	for i in range(numWalls):
		wallX = doryen.random_get_int(0, 2, constants.MAP_WIDTH - 3)
		wallY = doryen.random_get_int(0, 2, constants.MAP_HEIGHT - 3)
		newMap[wallX][wallY]._impassable = True

	for x in range(constants.MAP_WIDTH):
		newMap[x][0]._impassable = True
		newMap[x][constants.MAP_HEIGHT - 1]._impassable = True
	for y in range(constants.MAP_HEIGHT):
		newMap[0][y]._impassable = True
		newMap[constants.MAP_WIDTH - 1][y]._impassable = True

	mapMakeLOS(newMap)

	return newMap


def mapCheckForCreature(xPos, yPos, excludeObj = None):

	'''
	checks the submitted (x, y) location for a creature other than the excluded one and returns that object
	'''

	for obj in GAME._currentObjects:
		if ((obj is not excludeObj) and
			(obj._x == xPos) and
			(obj._y == yPos) and
			(obj.creature)):
			return obj
	return None


def mapMakeLOS(incomingMap):

	'''

	'''

	global LOS_MAP
	LOS_MAP = doryen.map_new(constants.MAP_WIDTH, constants.MAP_HEIGHT)

	for y in range(constants.MAP_HEIGHT):
		for x in range(constants.MAP_WIDTH):
			doryen.map_set_properties(LOS_MAP, x, y,
				not incomingMap[x][y]._impassable,
				not incomingMap[x][y]._impassable)


def mapCalcLOS():

	'''

	'''

	global LOS_CALC

	if LOS_CALC:
		LOS_CALC = False
		doryen.map_compute_fov(LOS_MAP, PLAYER._x, PLAYER._y,
			constants.LOS_LIGHT_RADIUS,
			constants.LOS_LIGHT_WALLS,
			constants.LOS_ALGO)


def mapObjectsAtLocation(xCoord, yCoord):

	'''

	'''

	objectList = [obj for obj in GAME._currentObjects if obj._x == xCoord and obj._y == yCoord]

	return objectList


def mapFindLine(coords1, coords2):
	
	'''
	Converts two sets of (x, y) map coords into a list of tiles that make up that line

	coords1 : (x1, y1)
	coords2 : (x2, y2)
	'''

	x1, y1 = coords1
	x2, y2 = coords2

	if (x1 == x2) and (y1 == y2):
		return [(x1, y1)]

	doryen.line_init(x1, y1, x2, y2)

	lineCoords = doryen.line_step()

	lineCoordsList = []

	while lineCoords != (None, None):
		lineCoordsList.append(lineCoords)
		lineCoords = doryen.line_step()

	return lineCoordsList


def mapFindRadius(coords, radius):

	'''

	'''

	centerX, centerY = coords

	startX = centerX - radius
	if startX < 0:
		startX = 0

	endX   = centerX + radius
	if endX > constants.MAP_WIDTH:
		endX = constants.MAP_WIDTH

	startY = centerY - radius
	if startY < 0:
		startY = 0

	endY   = centerY + radius
	if endY > constants.MAP_HEIGHT:
		endY = constants.MAP_HEIGHT

	radiusCoordsList = []

	for y in range(startY, endY + 1):
		for x in range (startX, endX + 1):
			radiusCoordsList.append((x, y))

	return radiusCoordsList


#######################################################################################################
#   _____ ___________ _   _ _____ _____ _   _______ _____ _____ 
#  /  ___|_   _| ___ \ | | /  __ \_   _| | | | ___ \  ___/  ___|
#  \ `--.  | | | |_/ / | | | /  \/ | | | | | | |_/ / |__ \ `--. 
#   `--. \ | | |    /| | | | |     | | | | | |    /|  __| `--. \
#  /\__/ / | | | |\ \| |_| | \__/\ | | | |_| | |\ \| |___/\__/ /
#  \____/  \_/ \_| \_|\___/ \____/ \_/  \___/\_| \_\____/\____/
#
#######################################################################################################

class structTile:

	'''
	map tiles
	'''

	def __init__(self, impassable):
		self._impassable = impassable
		self._explored = False


class structAssets:
	
	'''
	game assets
	'''

	def __init__(self):

		path = "C:/Users/Robin/Desktop/Pyrate/graphicAssets/"

		# sprite sheets
		self.reptileSpriteSheet  = objSpriteSheet(path + "Characters/Reptile.png")
		self.aquaticSpriteSheet = objSpriteSheet(path + "Characters/Aquatic.png")
		self.shortWepSpriteSheet = objSpriteSheet(path + "Items/ShortWep.png")
		self.shieldSpriteSheet = objSpriteSheet(path + "Items/Shield.png")
		self.wallSpriteSheet = objSpriteSheet(path + "Objects/Wall.png")
		self.floorSpriteSheet = objSpriteSheet(path + "Objects/Floor.png")
		self.scrollSpriteSheet =  objSpriteSheet(path + "Items/Scroll.png")

		# creature animations
		self.ANIM_FROG   = self.aquaticSpriteSheet.getAnimation('c', 6, 16, 16, 2, (32, 32))
		self.ANIM_CRAB   = self.aquaticSpriteSheet.getAnimation('c', 1, 16, 16, 2, (32, 32))
		self.ANIM_PYTHON = self.reptileSpriteSheet.getAnimation('m', 5, 16, 16, 2, (32, 32))

		# map tiles
		self.SPRITE_FLOOR       = self.floorSpriteSheet.getImage('b', 8, 16, 16, (32, 32))
		self.SPRITE_FLOOR_DARK  = self.floorSpriteSheet.getImage('b', 14, 16, 16, (32, 32))
		self.SPRITE_WALL        = self.wallSpriteSheet.getImage('d', 7, 16, 16, (32, 32))
		self.SPRITE_WALL_DARK   = self.wallSpriteSheet.getImage('d', 13, 16, 16, (32, 32))

		#items
		self.SPRITE_SWORD = self.shortWepSpriteSheet.getAnimation('b', 2, 16, 16, 1, (32, 32))
		self.SPRITE_SHIELD = self.shieldSpriteSheet.getAnimation('a', 1, 16, 16, 1, (32, 32))
		self.SPRITE_SCROLL_1 = self.scrollSpriteSheet.getAnimation('e', 2, 16, 16, 1, (32, 32))
		self.SPRITE_SCROLL_2 = self.scrollSpriteSheet.getAnimation('c', 2, 16, 16, 1, (32, 32))
		self.SPRITE_SCROLL_3 = self.scrollSpriteSheet.getAnimation('g', 2, 16, 16, 1, (32, 32))

		# fonts
		self.FONT_DEBUG   = pygame.font.Font(path + "Fonts/Joystick/Joystick.otf", 16)
		self.FONT_DEBUG   = pygame.font.Font(path + "Fonts/Joystick/Joystick.otf", 16)
		self.FONT_MESSAGE = pygame.font.Font(path + "Fonts/Joystick/Joystick.otf", 12)
		self.FONT_CURSOR  = pygame.font.Font(path + "Fonts/Joystick/Joystick.otf", constants.TILE_HEIGHT)



#######################################################################################################
#   ___________   ___ _____ _____ _____ _____ 
#  |  _  | ___ \ |_  |  ___/  __ \_   _/  ___|
#  | | | | |_/ /   | | |__ | /  \/ | | \ `--.
#  | | | | ___ \   | |  __|| |     | |  `--. \
#  \ \_/ / |_/ /\__/ / |___| \__/\ | | /\__/ /
#   \___/\____/\____/\____/ \____/ \_/ \____/ 
#
#######################################################################################################

class objActor:

	'''
	any game element that can move/interact with other elements
	'''

	global LOS_MAP

	def __init__(self, x, y, nameObject, animation, animationDuration = 1.0,
		creature = None, ai = None, container = None, item = None, equipment = None):

		# map address
		self._x = x
		self._y = y

		self._nameObject = nameObject

		# sprite
		self._animation = animation
		self._animationDuration = animationDuration / 1.0
		self._flickerSpeed = self._animationDuration / len(self._animation) # individual frame duration
		self._flickterTimer = 0.0
		self._spriteCounter = 0

		# creature
		self.creature = creature
		if self.creature:
			self.creature.owner = self

		self.ai = ai
		if self.ai:
			self.ai.owner = self

		self.container = container
		if self.container:
			self.container.owner = self

		self.item = item
		if self.item:
			self.item.owner = self

		self.equipment = equipment
		if self.equipment:
			self.equipment.owner = self

			self.item = compItem()
			self.item.owner = self

	@property
	def _displayName(self):
		if self.creature:
			return (self.creature._nameInstance + " the " + self._nameObject)
		
		if self.item:
			if self.equipment and self.equipment._equipped:
				return (self._nameObject + " (" + self.equipment._slot + ")")
			else:
				return (self._nameObject)


	def draw(self):
		if doryen.map_is_in_fov(LOS_MAP, self._x, self._y):
			SURFACE_MAIN.blit(self._animation[self._spriteCounter], (self._x * constants.TILE_WIDTH, self._y * constants.TILE_HEIGHT))
			if len(self._animation) > 1:
				if CLOCK.get_fps() > 0.0:
					self._flickterTimer += 1 / CLOCK.get_fps()
				if self._flickterTimer >= self._flickerSpeed:
					self._flickterTimer = 0.0
					if self._spriteCounter >= len(self._animation) - 1:
						self._spriteCounter = 0
					else:
						self._spriteCounter += 1


	def distanceFrom(self, other):

		'''
		returns the distance between self and other calculated via pythagorean theorem
		'''

		diffX = other._x - self._x
		diffY = other._y - self._y

		return math.sqrt(diffX ** 2 + diffY ** 2)

	def moveTowards(self, other):

		'''

		'''

		diffX = other._x - self._x
		diffY = other._y - self._y

		moveX = 0
		moveY = 0

		if diffX != 0:
			moveX = diffX / abs(diffX)

		if diffY != 0:
			moveY = diffY / abs(diffY)

		self.creature.move(moveX, moveY)


	def moveAwayFrom(self, other):

		'''

		'''

		diffX = -(other._x - self._x)
		diffY = -(other._y - self._y)

		moveX = 0
		moveY = 0

		if diffX != 0:
			moveX = diffX / abs(diffX)

		if diffY != 0:
			moveY = diffY / abs(diffY)

		self.creature.move(moveX, moveY)


class objGame:

	'''

	'''

	def __init__(self):

		self._currentMap = mapMake()
		self._currentObjects = []

		self._messageLog = []


class objSpriteSheet:
	
	'''
	grab images from a spritesheet
	'''

	def __init__(self, fileName):
		# load spritesheet
		self._spriteSheet = pygame.image.load(fileName).convert()
		self._spriteDict = {'a':  1, 'b':  2, 'c':  3, 'd':  4, 'e':  5, 'f':  6, 'g':  7, 'h':  8,
							'i':  9, 'j': 10, 'k': 11, 'l': 12, 'm': 13, 'n': 14, 'o': 15, 'p': 16}


	def getAnimation(self, column, row, width = constants.TILE_WIDTH, height = constants.TILE_HEIGHT, numSprites = 1, scale = None):

		spriteList = []

		for i in range(numSprites):
			image = pygame.Surface([width, height]).convert()
			image.blit(self._spriteSheet, (0, 0), ((self._spriteDict[column] + i) * width, row * height, width, height))
			image.set_colorkey(constants.COLOR_BLACK)

			if scale:
				image = pygame.transform.scale(image, scale)

			spriteList.append(image)

		return spriteList

	def getImage(self, column, row, width = constants.TILE_WIDTH, height = constants.TILE_HEIGHT, scale = None):

		image = pygame.Surface([width, height]).convert()
		image.blit(self._spriteSheet, (0, 0), ((self._spriteDict[column]) * width, row * height, width, height))
		image.set_colorkey(constants.COLOR_BLACK)

		if scale:
			image = pygame.transform.scale(image, scale)

		return image


#######################################################################################################
#   _____ ________  _________ _____ _   _  _____ _   _ _____ _____
#  /  __ \  _  |  \/  || ___ \  _  | \ | ||  ___| \ | |_   _/  ___|
#  | /  \/ | | | .  . || |_/ / | | |  \| || |__ |  \| | | | \ `--.
#  | |   | | | | |\/| ||  __/| | | | . ` ||  __|| . ` | | |  `--. \
#  | \__/\ \_/ / |  | || |   \ \_/ / |\  || |___| |\  | | | /\__/ /
#   \____/\___/\_|  |_/\_|    \___/\_| \_/\____/\_| \_/ \_/ \____/
#
#######################################################################################################

class compCreature:

	'''
	have health and can die
	can damage other objects by attacking them
	'''

	def __init__(self, nameInstance, baseAttack = 3, baseDefense = 0, health = 10, deathFunction = None):
		self._nameInstance = nameInstance
		self._baseAttack = baseAttack
		self._baseDefense = baseDefense
		self._maxHealth = health
		self._health = health
		self.deathFunction = deathFunction

	def attack(self, target):

		damage = self._power - target.creature._defense
		if damage < 1:
			damage = 1

		gameMessage((self.owner._displayName + " attacks " + target.creature._nameInstance +
			" for " + str(damage) + " damage!"))
		target.creature.takeDamage(damage)

	def takeDamage(self, damage):
		self._health -= damage
		gameMessage(self.owner._displayName + " takes " + str(damage) + " damage", constants.COLOR_RED)
		gameMessage(self.owner._displayName + "'s health: " + str(self._health) + "/" + str(self._maxHealth), constants.COLOR_RED)

		if (self._health <= 0) and (self.deathFunction):
			self.deathFunction(self.owner)

	def healDamage(self, value):
		if value > (self._maxHealth - self._health):
			value = (self._maxHealth - self._health)
		self._health += value
		gameMessage((self.owner._displayName + " healed for " + str(value) + " health"))
		gameMessage((self.owner._displayName + "'s health: " + str(self._health) + "/" + str(self._maxHealth)), constants.COLOR_RED)		

	def move(self, xDiff, yDiff):
		tileIsWall = GAME._currentMap[self.owner._x + xDiff][self.owner._y + yDiff]._impassable

		target = mapCheckForCreature(self.owner._x + xDiff, self.owner._y + yDiff, self.owner)

		if target:
			self.attack(target)

		if not tileIsWall and target == None:
			self.owner._x += xDiff
			self.owner._y += yDiff

	@property
	def _power(self):

		equipmentBonusList = []
		if self.owner.container:
			equipmentBonusList = [obj.equipment._attackBonus for obj in self.owner.container._equippedItems]

		equipmentBonusTotal = 0
		for bonus in equipmentBonusList:
			equipmentBonusTotal += bonus

		totalDamage = self._baseAttack + equipmentBonusTotal

		return totalDamage

	@property
	def _defense(self):

		equipmentBonusList = []
		if self.owner.container:
			equipmentBonusList = [obj.equipment._defenseBonus for obj in self.owner.container._equippedItems]

		equipmentBonusTotal = 0
		for bonus in equipmentBonusList:
			equipmentBonusTotal += bonus

		totalDefense = self._baseDefense + equipmentBonusTotal
		return totalDefense


class compItem:

	'''
	component that defines the properties of items
	'''

	def __init__(self, weight = 0.0, volume = 0.0, useFunction = None, useValue = None, target = None):

		self._weight = weight
		self._volume = volume
		self._useFunction = useFunction
		self._useValue = useValue
		self._target = target


	# pick up item
	def pickUp(self, actor):

		'''
		Picks up the item
		'''

		if actor.container:
			if actor.container.getVolume() + self._volume > actor.container._maxVolume:
				gameMessage("Not enough room to pick up", constants.COLOR_RED)
			else:
				gameMessage(actor._displayName + " picked up " + self.owner._displayName)
				actor.container._inventory.append(self.owner)
				GAME._currentObjects.remove(self.owner)
				self.currentContainer = actor.container


	# drop item
	def drop(self, newX, newY):

		'''
		Drops the item
		'''

		if self.owner.equipment:
			if self.owner.equipment._equipped:
				gameMessage("Item is equipped, cannot drop", constants.COLOR_RED)
				return

		GAME._currentObjects.append(self.owner)	
		self.currentContainer._inventory.remove(self.owner)
		self.owner._x = newX
		self.owner._y = newY
		gameMessage(self.currentContainer.owner._displayName + " dropped " + self.owner._displayName, constants.COLOR_RED)	


	# use item
	def use(self):

		'''
		Uses the item
		'''

		if self.owner.equipment:
			self.owner.equipment.toggleEquip()
			return

		if self._useFunction:
			result = self._useFunction(useValue = self._useValue, caster = self.owner.item.currentContainer.owner)

			if result is not None:
				gameMessage("Use " + self.owner._displayName + ": " + result, constants.COLOR_RED)
			else:
				gameMessage(self.currentContainer.owner._displayName + " used " + self.owner._displayName, constants.COLOR_RED)
				self.currentContainer._inventory.remove(self.owner)


class compContainer:

	'''

	'''

	def __init__(self, volume = 10.0, inventory = []):
		self._maxVolume = volume
		self._inventory = inventory

	# get names of all items in inventory


	# get volume of all items held in container
	def getVolume(self):
		volume = 0.0
		for obj in self._inventory:
			if obj.item:
				volume += obj.item._volume
		return volume

	@property
	def _equippedItems(self):
		return [obj for obj in self._inventory if (obj.equipment and obj.equipment._equipped)]

	@property
	def _volume(self):
		return 0.0

	@property
	def _weight(self):
		return 0.0


class compEquipment:

	'''

	'''

	def __init__(self, attackBonus = 0, defenseBonus = 0, slot = None):

		self._attackBonus = attackBonus
		self._defenseBonus = defenseBonus
		self._slot = slot
		self._equipped = False

	def toggleEquip(self):
		if self._equipped:
			self.unequip()
		else:
			self.equip()

	def equip(self):
		allEquippedItems = self.owner.item.currentContainer._equippedItems

		if allEquippedItems:
			for item in allEquippedItems:
				if item.equipment._slot and (item.equipment._slot == self._slot):
					gameMessage(self._slot + " slot is occupied", constants.COLOR_RED)
					return

		self._equipped = True
		gameMessage(self.owner._nameObject + " equipped")


	def unequip(self):
		self._equipped = False

		gameMessage(self.owner._nameObject + " unequipped")


#######################################################################################################
#  ___  ___  ___  _____ _____ _____ 
#  |  \/  | / _ \|  __ \_   _/  __ \
#  | .  . |/ /_\ \ |  \/ | | | /  \/
#  | |\/| ||  _  | | __  | | | |    
#  | |  | || | | | |_\ \_| |_| \__/\
#  \_|  |_/\_| |_/\____/\___/ \____/
#
#######################################################################################################


def castHeal(useValue = 5, caster = None, target = None):

	'''
	Item heals the targe when used
	'''

	target = PLAYER
	targetName = target._displayName
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	if (target.creature._health >= target.creature._maxHealth):
		gameMessage(targetName + " is already at full health", constants.COLOR_RED)
		return "cancelled"
	elif caster:
		gameMessage(casterName + " heals " + targetName)
		target.creature.healDamage(useValue)
	return None


def castLightning(useValue = 5, caster = None):

	'''
	Casts a lightning bolt along the specified line
	'''

	spellDamage = useValue
	spellRange = 7
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	# prompt the player for a tile
	targetTile = menuTargetSelect(originCoords = casterLocation, maxRange = spellRange, passWall = False)
	if targetTile == None:
		return "cancelled"

	if casterName:
		gameMessage(casterName + "casts lightning")

	lightningPathList = mapFindLine(casterLocation, targetTile)

	# cycle through the list and damage everything found
	for (x, y) in lightningPathList:
		target = mapCheckForCreature(x, y)
		if target:
			gameMessage(target._displayName + " convulses from the shock", constants.COLOR_BLUE)
			target.creature.takeDamage(spellDamage)

	return None


def castFireball(useValue = 5, caster = None):

	'''

	'''

	spellDamage = useValue
	spellRadius = 1
	spellRange = 5
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	# get target tile
	targetTile = menuTargetSelect(originCoords = casterLocation, maxRange = spellRange,
		passWall = False, passCreature = False, radius = spellRadius)

	if targetTile == None:
		return "cancelled"

	if casterName:
		gameMessage(casterName + " casts fireball")

	# get sequence of tiles
	fireballArea = mapFindRadius(targetTile, spellRadius)

	# damage all creatures in sequence of tiles
	for (x, y) in fireballArea:
		target = mapCheckForCreature(x, y)
		if target:
			if target is not PLAYER:
				gameMessage(target._displayName + "'s flesh sizzles", constants.COLOR_RED)
			target.creature.takeDamage(spellDamage)

	return None


def castConfusion(useValue = 5, caster = None):

	'''

	'''

	spellRange = 8
	spellDuration = useValue
	if caster:
		casterName = caster._displayName
		casterLocation = (caster._x, caster._y)

	# select tile
	targetTile = menuTargetSelect(maxRange = spellRange)

	if targetTile == None:
		return "cancelled"

	# get target from tile
	x, y = targetTile
	target = mapCheckForCreature(x, y)

	# temporarily replace target's ai with confused ai
	if target:
		if casterName:
			gameMessage(casterName + " casts confusion")
		oldAI = target.ai
		target.ai = aiConfused(oldAI = oldAI, duration = spellDuration)
		target.ai.owner = target
		gameMessage(target._displayName + "'s eye glaze over.", constants.COLOR_GREEN)

	return None


def castTerror(caster):

	'''

	'''

	spellRadius = 2
	spellDuration = 3

	for target in GAME._currentObjects:
		if target.creature and (target is not caster) and (target.distanceFrom(caster) <= spellRadius):
			# temporarily replace target's ai with afraid ai
			oldAI = target.ai
			target.ai = aiAfraid(oldAI = oldAI, duration = spellDuration)
			target.ai.owner = target
			gameMessage(target._displayName + " flees in terror", constants.COLOR_BLUE)





#######################################################################################################
#    ___  _____ 
#   / _ \|_   _|
#  / /_\ \ | |  
#  |  _  | | |  
#  | | | |_| |_ 
#  \_| |_/\___/
#
#######################################################################################################

class aiConfused:

	'''
	AI rules for confused creatures
	  act once per turn
	  move randomly
	'''

	def __init__(self, oldAI, duration):
		self.oldAI = oldAI
		self.duration = duration

	def takeTurn(self):
		if self.duration > 0:
			self.owner.creature.move(doryen.random_get_int(0, -1, 1), doryen.random_get_int(0, -1, 1))
			self.duration -= 1
		else:
			self.owner.ai = self.oldAI
			gameMessage(self.owner._displayName + "'s eyes return to normal", constants.COLOR_GREEN)


class aiAfraid:

	'''
	AI rules for confused creatures
	  act once per turn
	  move away from the player
	'''

	def __init__(self, oldAI, duration):
		self.oldAI = oldAI
		self.duration = duration

	def takeTurn(self):
		if self.duration > 0:
			if doryen.map_is_in_fov(LOS_MAP, self.owner._x, self.owner._y):
				self.owner.moveAwayFrom(PLAYER)
			self.duration -= 1
		else:
			self.owner.ai = self.oldAI
			gameMessage(self.owner._displayName + "'s courage returns", constants.COLOR_BLUE)


class aiDefault:

	'''
	Chases and attacks the player
	'''

	def takeTurn(self):

		monster = self.owner

		if doryen.map_is_in_fov(LOS_MAP, monster._x, monster._y):
			monster.moveTowards(PLAYER)


def deathMonster(monster):
	
	'''
	defines what happens when a monster dies (they stop moving and are no longer a creature)
	'''

	gameMessage ((monster._displayName + " is dead!"), constants.COLOR_GRAY)

	monster._nameObject = "corpse of " + monster._displayName
	monster._animation = [monster._animation[0]]
	monster._spriteCounter = 0

	monster.creature = None
	monster.ai = None






#######################################################################################################
#   _      _____ _____   _____ _____  ______ _____ _____ _____ _   _   _ 
#  | |    |  ___|_   _| |_   _|_   _| | ___ \  ___|  __ \_   _| \ | | | |
#  | |    | |__   | |     | |   | |   | |_/ / |__ | |  \/ | | |  \| | | |
#  | |    |  __|  | |     | |   | |   | ___ \  __|| | __  | | | . ` | | |
#  | |____| |___  | |    _| |_  | |   | |_/ / |___| |_\ \_| |_| |\  | |_|
#  \_____/\____/  \_/    \___/  \_/   \____/\____/ \____/\___/\_| \_/ (_)
#
#######################################################################################################

gameInit()
gameMainLoop()






#################################################################
#                                                               #
#  ''''''''''''''''''' @@@@@@@@@@@@@@@@@@@''''''''''''''''''''  #
#  '''''''''''''''''@@@@@@'''''''''''''@@@@@@@''''''''''''''''  #
#  ''''''''''''''@@@@'''''''''''''''''''''''@@@@''''''''''''''  #
#  '''''''''''''@@@'''''''''''''''''''''''''''''@@''''''''''''  #
#  ''''''''''''@@''''''''''''''''''''''''''''''''@@'''''''''''  #
#  '''''''''''@@'''''''''''''''''''''`'''''''''''@@'''''''''''  #
#  ''''''''''@@'''''''''''''''''''''''''''''''''''@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@'@@'''''''''''''''''''''''''''''@@''@''''''''''  #
#  ''''''''''@@''@@''''''''''''''''''''''''''''@@'@@''''''''''  #
#  ''''''''''@@''@@'''''''''''''''''''''''''''@@''@@''''''''''  #
#  '''''''''''@@'@@'''@@@@@@@@'''''@@@@@@@@'''@@'@@'''''''''''  #
#  ''''''''''''@@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@@@'''''''''''  #
#  '''''''''''''@@@'@@@@@@@@@@'''''@@@@@@@@@@'@@@'''''''''''''  #
#  ''''@@@'''''''@@''@@@@@@@@'''''''@@@@@@@@@''@@''''''@@@@'''  #
#  '''@@@@@'''''@@'''@@@@@@@'''@@@'''@@@@@@@'''@@'''''@@@@@@''  #
#  ''@@'''@@''''@@'''''@@@''''@@@@@''''@@@'''''@@''''@@'''@@''  #
#  '@@@''''@@@@''@@''''''''''@@@@@@@''''''''''@@''@@@@''''@@@'  #
#  @@'''''''''@@@@@@@@'''''''@@@'@@@'''''''@@@@@@@@@''''''''@@  #
#  @@@@@@@@@'''''@@@@@@@@''''@@'''@@''''@@@@@@@@''''''@@@@@@@@  #
#  ''@@@@'@@@@@''''''@@@@@''''''''''''''@@@'@@'''''@@@@@@'@@@'  #
#  ''''''''''@@@@@@''@@@''@@'''''''''''@@''@@@''@@@@@@''''''''  #
#  ''''''''''''''@@@@@@'@@'@@@@@@@@@@@'@@'@@@@@@''''''''''''''  #
#  ''''''''''''''''''@@'@@'@'@'@'@'@'@'@'@'@@'''''''''''''''''  #
#  ''''''''''''''''@@@@''@'@'@'@'@'@'@'@'''@@@@@''''''''''''''  #
#  ''''''''''''@@@@@'@@'''@@@@@@@@@@@@@'''@@'@@@@@''''''''''''  #
#  ''''@@@@@@@@@@'''''@@'''''''''''''''''@@''''''@@@@@@@@@''''  #
#  '''@@'''''''''''@@@@@@@'''''''''''''@@@@@@@@''''''''''@@'''  #
#  ''''@@@'''''@@@@@'''''@@@@@@@@@@@@@@@'''''@@@@@'''''@@@''''  #
#  ''''''@@'''@@@'''''''''''@@@@@@@@@'''''''''''@@@'''@@''''''  #
#  ''''''@@''@@'''''''''''''''''''''''''''''''''''@@''@@''''''  #
#  '''''''@@@@'''''''''''''''''''''''''''''''''''''@@@@'''''''  #
#                                                               #
#################################################################
