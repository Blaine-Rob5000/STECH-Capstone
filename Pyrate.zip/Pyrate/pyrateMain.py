"""

Pyrate

	a python roguelike by RG Blaine using pygame and the Doryen library (libtcod)

"""


# module imports
import pygame
import libtcodpy as doryen

# game file imports
import constants

# test statement
print "Hello World"


#######################################################################################################
#   _____   ___  ___  ___ _____
#  |  __ \ / _ \ |  \/  ||  ___|
#  | |  \// /_\ \| .  . || |__ 
#  | | __ |  _  || |\/| ||  __|
#  | |_\ \| | | || |  | || |___
#   \____/\_| |_/\_|  |_/\____/
#
#######################################################################################################

def gameMainLoop():

	'''
	the main game loop
	'''

	# define the player's action
	playerAction = "no-action"

	# flag to exit the game
	gameOver = False

	while not gameOver:
		# get input and process it
		playerAction = handleInput()
		
		if playerAction == "QUIT":
			gameOver = True

		if playerAction != "no-action":
			for obj in GAME_OBJECTS:
				if obj.ai:
					obj.ai.takeTurn()

		# draw game
		drawGame()

	print "Goodbye World"
	pygame.quit()
	exit()


def handleInput():
	# get list of events
	eventList = pygame.event.get()

	# handle those events
	for event in eventList:
		# player clicks the window's X button
		if event.type == pygame.QUIT:
			return "QUIT"

		# player presses an arrow key
		if event.type == pygame.KEYDOWN:
			if event.key == pygame.K_UP:
				PLAYER.move(0, -1)
				return "player-moved-north"

			if event.key == pygame.K_DOWN:
				PLAYER.move(0, 1)
				return "player-moved-south"

			if event.key == pygame.K_LEFT:
				PLAYER.move(-1, 0)
				return "player-moved-west"

			if event.key == pygame.K_RIGHT:
				PLAYER.move(1, 0)
				return "player-moved-east"

	# no action taken
	return "no-action"


def gameInit():

	'''
	initializes the main game window and pygame module
	'''

	# variables
	global SURFACE_MAIN, GAME_MAP, PLAYER, ENEMY, GAME_OBJECTS

	# initialize pygame
	pygame.init()

	# create main surface
	SURFACE_MAIN = pygame.display.set_mode( (constants.DISPLAY_WIDTH,constants.DISPLAY_HEIGHT) )

	GAME_MAP = mapMake()

	creatureComp1 = compCreature("Pauly")
	PLAYER = objActor(1, 1, "python", constants.SPRITE_PLAYER, creature = creatureComp1)

	creatureComp2 = compCreature("Krusty", deathFunction = deathMonster)
	aiComp = aiTest()
	ENEMY  = objActor(15, 15, "crab", constants.SPRITE_ENEMY,
		creature = creatureComp2,
		ai = aiComp)

	GAME_OBJECTS = [PLAYER, ENEMY]



#######################################################################################################
#  ____________  ___  _    _ 
#  |  _  \ ___ \/ _ \| |  | |
#  | | | | |_/ / /_\ \ |  | |
#  | | | |    /|  _  | |/\| |
#  | |/ /| |\ \| | | \  /\  /
#  |___/ \_| \_\_| |_/\/  \/
#
#######################################################################################################

def drawGame():

	'''
	draws the game on the main surface
	'''

	# variables
	global SURFACE_MAIN

	# clear surface
	SURFACE_MAIN.fill(constants.COLOR_BACKGROUND_DEFAULT)

	# draw the map
	drawMap(GAME_MAP)

	# draw all objects
	for obj in GAME_OBJECTS:
		obj.draw()

	# update surface
	pygame.display.flip()


def drawMap(map):

	'''
	draws the map
	'''

	# cycle through map cells and draw a wall or a floor tile
	for y in range(constants.MAP_HEIGHT):
		for x in range(constants.MAP_WIDTH):
			if map[x][y]._impassable == True:
				# draw wall
				SURFACE_MAIN.blit(constants.SPRITE_WALL, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))
			else:
				# draw floor
				SURFACE_MAIN.blit(constants.SPRITE_FLOOR, (x * constants.TILE_WIDTH, y * constants.TILE_HEIGHT))



#######################################################################################################
#  ___  ___  ___  ______ 
#  |  \/  | / _ \ | ___ \
#  | .  . |/ /_\ \| |_/ /
#  | |\/| ||  _  ||  __/
#  | |  | || | | || |   
#  \_|  |_/\_| |_/\_|
#
#######################################################################################################

def mapMake():

	'''
	makes and returns a map as an array
	'''

	# create a blank map
	newMap = [[structTile(False) for y in range(constants.MAP_HEIGHT)] for x in range(constants.MAP_WIDTH)]

	# add 2 wall tiles to map
	newMap[10][10]._impassable = True
	newMap[10][15]._impassable = True

	for x in range(constants.MAP_WIDTH):
		newMap[x][0]._impassable = True
		newMap[x][constants.MAP_HEIGHT - 1]._impassable = True
	for y in range(constants.MAP_HEIGHT):
		newMap[0][y]._impassable = True
		newMap[constants.MAP_WIDTH - 1][y]._impassable = True

	#return map
	return newMap



#######################################################################################################
#   _____ ___________ _   _ _____ _____ _____ 
#  /  ___|_   _| ___ \ | | /  __ \_   _/  ___|
#  \ `--.  | | | |_/ / | | | /  \/ | | \ `--.
#   `--. \ | | |    /| | | | |     | |  `--. \
#  /\__/ / | | | |\ \| |_| | \__/\ | | /\__/ /
#  \____/  \_/ \_| \_|\___/ \____/ \_/ \____/
#
#######################################################################################################

class structTile:

	'''
	map tiles
	'''

	def __init__(self, impassable):
		self._impassable = impassable



#######################################################################################################
#   ___________   ___ _____ _____ _____ _____ 
#  |  _  | ___ \ |_  |  ___/  __ \_   _/  ___|
#  | | | | |_/ /   | | |__ | /  \/ | | \ `--.
#  | | | | ___ \   | |  __|| |     | |  `--. \
#  \ \_/ / |_/ /\__/ / |___| \__/\ | | /\__/ /
#   \___/\____/\____/\____/ \____/ \_/ \____/ 
#
#######################################################################################################

class objActor:

	'''
	any game element that can move/interact with other elements
	'''

	def __init__(self, x, y, nameObject, sprite, creature = None, ai = None):

		# map address
		self._x = x
		self._y = y

		# sprite
		self._sprite = sprite

		# creature
		self.creature = creature
		if creature:
			creature.owner = self

		self.ai = ai
		if ai:
			ai.owner = self

	def draw(self):
		SURFACE_MAIN.blit(self._sprite, (self._x * constants.TILE_WIDTH, self._y * constants.TILE_HEIGHT))

	def move(self, xDiff, yDiff):
		tileIsWall = GAME_MAP[self._x + xDiff][self._y + yDiff]._impassable

		target = None
		for obj in GAME_OBJECTS:
			if ((obj is not self) and
				(obj._x == self._x + xDiff) and
				(obj._y == self._y + yDiff) and
				(obj.creature)):
				target = obj
				break

		if target:
			print self.creature._nameInstance + " attacks " + target.creature._nameInstance + " for 5 damage!"
			target.creature.takeDamage(5)

		if not tileIsWall and target == None:
			self._x += xDiff
			self._y += yDiff



#######################################################################################################
#   _____ ________  _________ _____ _   _  _____ _   _ _____ _____
#  /  __ \  _  |  \/  || ___ \  _  | \ | ||  ___| \ | |_   _/  ___|
#  | /  \/ | | | .  . || |_/ / | | |  \| || |__ |  \| | | | \ `--.
#  | |   | | | | |\/| ||  __/| | | | . ` ||  __|| . ` | | |  `--. \
#  | \__/\ \_/ / |  | || |   \ \_/ / |\  || |___| |\  | | | /\__/ /
#   \____/\___/\_|  |_/\_|    \___/\_| \_/\____/\_| \_/ \_/ \____/
#
#######################################################################################################

class compCreature:

	'''
	have health and can die
	can damage other objects by attacking them
	'''

	def __init__(self, nameInstance, health = 10, deathFunction = None):
		self._nameInstance = nameInstance
		self._maxHealth = health
		self._health = health
		self.deathFunction = deathFunction

	def takeDamage(self, damage):
		self._health -= damage
		print "    " + self._nameInstance + "'s health: " + str(self._health) + "/" + str(self._maxHealth)

		if (self._health <= 0) and (self.deathFunction):
			self.deathFunction(self.owner)

#class compItem:


#class compContainter:



#######################################################################################################
#    ___  _____ 
#   / _ \|_   _|
#  / /_\ \ | |  
#  |  _  | | |  
#  | | | |_| |_ 
#  \_| |_/\___/
#
#######################################################################################################

class aiTest:

	'''
	AI rules for creatures
	act once per turn
	'''

	def takeTurn(self):
		self.owner.move(doryen.random_get_int(0, -1, 1), doryen.random_get_int(0, -1, 1))


def deathMonster(monster):
	
	'''
	defines what happens when a monster dies (they stop moving)
	'''

	print monster.creature._nameInstance + " is dead!"

	monster.creature = None
	monster.ai = None














#######################################################################################################
#   _      _____ _____   _____ _____  ______ _____ _____ _____ _   _
#  | |    |  ___|_   _| |_   _|_   _| | ___ \  ___|  __ \_   _| \ | |
#  | |    | |__   | |     | |   | |   | |_/ / |__ | |  \/ | | |  \| |
#  | |    |  __|  | |     | |   | |   | ___ \  __|| | __  | | | . ` |
#  | |____| |___  | |    _| |_  | |   | |_/ / |___| |_\ \_| |_| |\  |
#  \_____/\____/  \_/    \___/  \_/   \____/\____/ \____/\___/\_| \_/
#
#######################################################################################################

gameInit()
gameMainLoop()