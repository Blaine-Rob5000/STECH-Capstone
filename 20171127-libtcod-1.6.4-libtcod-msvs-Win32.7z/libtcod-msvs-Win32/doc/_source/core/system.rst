************
System layer
************

High precision time functions
=============================

Limit the frames per second
^^^^^^^^^^^^^^^^^^^^^^^^^^^

Get the number of frames rendered during the last second
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Get the duration of the last frame
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Pause the program
^^^^^^^^^^^^^^^^^

Get global timer in milliseconds
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

Get global timer in seconds
^^^^^^^^^^^^^^^^^^^^^^^^^^^

Easy screenshots
================

Filesystem utilities
====================

Draw custom graphics on top of the root console
===============================================

Miscellaneous utilities
=======================

Clipboard integration
=====================

