Noise Generator
===============


